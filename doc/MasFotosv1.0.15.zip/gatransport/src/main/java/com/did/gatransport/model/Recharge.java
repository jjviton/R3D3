package com.did.gatransport.model;

public class Recharge {

    public static final int CARD = 0;
    public static final int PENDING = 1;
    public static final int TOKEN_CARD = 2;

    private long date;

    private int type;

    private int amount;

    private String cardLastDig;

    public Recharge() {
    }

    public Recharge(long date, int type, int amount, String cardLastDig) {
        this.date = date;
        this.type = type;
        this.amount = amount;
        this.cardLastDig = cardLastDig;
    }

    public final long getDate() {
        return date;
    }

    public final void setDate(long date) {
        this.date = date;
    }

    public final int getType() {
        return type;
    }

    public final void setType(int type) {
        this.type = type;
    }

    public final int getAmount() {
        return amount;
    }

    public final void setAmount(int amount) {
        this.amount = amount;
    }

    public final String getCardLastDig() {
        return cardLastDig;
    }

    public final void setCardLastDig(String cardLastDig) {
        this.cardLastDig = cardLastDig;
    }
}
