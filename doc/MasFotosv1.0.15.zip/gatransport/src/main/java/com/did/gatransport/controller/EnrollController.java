package com.did.gatransport.controller;

import android.content.ContextWrapper;
import android.text.TextUtils;
import android.util.Patterns;

import com.did.gacard.core.files.model.GaAppFile;
import com.did.gatransport.R;
import com.did.gatransport.interfaces.RequestListener;
import com.did.gatransport.model.Error;
import com.did.gatransport.model.request.EnrollLockCardRequest;
import com.did.gatransport.model.request.EnrollRequest;
import com.did.gatransport.model.request.FinishEnrollRequest;
import com.did.gatransport.rest.GaRestController;
import com.did.gatransport.rest.model.response.BaseResponse;
import com.did.gatransport.rest.model.response.EnrollResponse;
import com.did.gatransport.rest.model.response.FinishEnrollResponse;
import com.did.gatransport.store.GaStoreManager;
import com.did.gatransport.store.model.User;
import com.did.gatransport.store.realm.model.GaCardRealm;
import com.did.gatransport.store.realm.model.UserRealm;
import com.did.gatransport.util.ErrorFactory;
import com.did.security.core.SecurityHelper;
import com.google.gson.Gson;

import java.security.InvalidParameterException;
import java.util.Calendar;


final class EnrollController {

    private static EnrollController mInstance;

    public static EnrollController getInstance(GaRestController restController, GaStoreManager storeManager) {
        if (mInstance == null)
            mInstance = new EnrollController(restController, storeManager);

        return mInstance;
    }

    private GaRestController restController;
    private GaStoreManager storeManager;

    private boolean allowPetition;

    // Temporal data
    private EnrollRequest enrollRequest;
    private EnrollResponse enrollResponse;

    private EnrollController(GaRestController restController, GaStoreManager storeManager) {
        allowPetition = true;
        this.restController = restController;
        this.storeManager = storeManager;
    }

    private boolean validateType(String type) {
        return type != null && !type.isEmpty() && TextUtils.isDigitsOnly(type);
    }

    private boolean validateEnrollResponse(EnrollResponse enrollResponse) {
        return enrollResponse != null
                && enrollResponse.getId() != null && !enrollResponse.getId().isEmpty()
                && enrollResponse.getTokenId() != null && !enrollResponse.getTokenId().isEmpty();
    }

    private boolean validateFinishEnrollResponse(FinishEnrollResponse finishEnrollResponse) {
        return finishEnrollResponse != null
                && finishEnrollResponse.getSignature() != null && finishEnrollResponse.getSignature().length > 0
                && finishEnrollResponse.getNt() != null && !finishEnrollResponse.getNt().isEmpty()
                && finishEnrollResponse.getPersoFile() != null && finishEnrollResponse.getPersoFile().getFile() != null
                && finishEnrollResponse.getBalance() != null && !finishEnrollResponse.getBalance().isEmpty()
                && finishEnrollResponse.getUserId() != null && !finishEnrollResponse.getUserId().isEmpty()
                && finishEnrollResponse.getPhoneId() != null && !finishEnrollResponse.getPhoneId().isEmpty()
                && finishEnrollResponse.getHwId() != null && !finishEnrollResponse.getHwId().isEmpty()
                && finishEnrollResponse.getPan() != null && !finishEnrollResponse.getPan().isEmpty()
                && finishEnrollResponse.getCardExpiration() != null && !finishEnrollResponse.getCardExpiration().isEmpty()
                && finishEnrollResponse.getProfile() != null && !finishEnrollResponse.getProfile().isEmpty()
                && finishEnrollResponse.getProfileExpiration() != null && !finishEnrollResponse.getProfileExpiration().isEmpty()
                && finishEnrollResponse.getTokenId() != null && !finishEnrollResponse.getTokenId().isEmpty();
    }

    private void cacheData(EnrollResponse enrollResponse, EnrollRequest enrollRequest) {
        this.enrollResponse = enrollResponse;
        this.enrollRequest = enrollRequest;
    }

    void enroll(final ContextWrapper context, final EnrollRequest enrollRequest, final SecurityHelper securityHelper, final RequestListener<Void> listener) {
        if (enrollRequest == null) {
            if (listener != null)
                listener.onFailure(ErrorFactory.getWarnError(context, Error.GENERAL_INVALID_INPUT));
            return;
        }
        if (enrollRequest.getEnrollData() == null || enrollRequest.getEnrollData().isEmpty()) {
            if (listener != null) {
                Error error;
                switch (enrollRequest.getEnrollType()) {
                    case EnrollRequest.ENROLL_TYPE_DNI:
                        error = ErrorFactory.getWarnError(context, Error.GENERAL_INVALID_INPUT,
                                new InvalidParameterException(String.format(context.getString(R.string.EXCEPTION_INVALID_INPUT), "dni")));
                        break;
                    case EnrollRequest.ENROLL_TYPE_PAN:
                        error = ErrorFactory.getWarnError(context, Error.GENERAL_INVALID_INPUT,
                                new InvalidParameterException(String.format(context.getString(R.string.EXCEPTION_INVALID_INPUT), "pan")));
                        break;
                    case EnrollRequest.ENROLL_TYPE_USER:
                        error = ErrorFactory.getWarnError(context, Error.GENERAL_INVALID_INPUT,
                                new InvalidParameterException(String.format(context.getString(R.string.EXCEPTION_INVALID_INPUT), "idUser")));
                        break;
                    case EnrollRequest.ENROLL_TYPE_CLIENT:
                        error = ErrorFactory.getWarnError(context, Error.GENERAL_INVALID_INPUT,
                                new InvalidParameterException(String.format(context.getString(R.string.EXCEPTION_INVALID_INPUT), "numberClient")));
                        break;
                    default:
                        error = ErrorFactory.getWarnError(context, Error.GENERAL_INVALID_INPUT, new InvalidParameterException(String.format(context.getString(R.string.EXCEPTION_INVALID_INPUT), "EnrollmentType")));
                }
                listener.onFailure(error);
            }
            return;
        }
        if (enrollRequest.getPwd() == null || enrollRequest.getPwd().isEmpty()) {
            if (listener != null)
                listener.onFailure(ErrorFactory.getWarnError(context, Error.GENERAL_INVALID_INPUT,
                        new InvalidParameterException(String.format(context.getString(R.string.EXCEPTION_INVALID_INPUT), "pwd"))));
            return;
        }

        if (enrollRequest.getEmail() != null && !enrollRequest.getEmail().isEmpty() && !Patterns.EMAIL_ADDRESS.matcher(enrollRequest.getEmail()).matches()) {
            if (listener != null)
                listener.onFailure(ErrorFactory.getWarnError(context, Error.GENERAL_INVALID_INPUT,
                        new InvalidParameterException(String.format(context.getString(R.string.EXCEPTION_INVALID_INPUT), "email"))));
            return;
        }

        //Just check the format of the phone in case the value is void or well formatted
        if (enrollRequest.getPhone() != null && !enrollRequest.getPhone().isEmpty() && !Patterns.PHONE.matcher(enrollRequest.getPhone()).matches()) {
            if (listener != null)
                listener.onFailure(ErrorFactory.getWarnError(context, Error.GENERAL_INVALID_INPUT,
                        new InvalidParameterException(String.format(context.getString(R.string.EXCEPTION_INVALID_INPUT), "phone"))));
            return;
        }

        if (!validateType(enrollRequest.getCardType())) {
            if (listener != null)
                listener.onFailure(ErrorFactory.getWarnError(context, Error.GENERAL_INVALID_INPUT, new InvalidParameterException(String.format(context.getString(R.string.EXCEPTION_INVALID_INPUT), "cardType"))));
            return;
        }

        if (!validateType(enrollRequest.getProfileType())) {
            if (listener != null)
                listener.onFailure(ErrorFactory.getWarnError(context, Error.GENERAL_INVALID_INPUT, new InvalidParameterException(String.format(context.getString(R.string.EXCEPTION_INVALID_INPUT), "profileType"))));
            return;
        }

        if (!validateType(enrollRequest.getPaySolutionType())) {
            if (listener != null)
                listener.onFailure(ErrorFactory.getWarnError(context, Error.GENERAL_INVALID_INPUT, new InvalidParameterException(String.format(context.getString(R.string.EXCEPTION_INVALID_INPUT), "paySolutionType"))));
            return;
        }

        storeManager.getUser(new RequestListener<User>() {
            @Override
            public void onSuccess(User user) {
                processUserCases(user, null);
            }

            @Override
            public void onFailure(Error error) {
                CoreController.getLogger().logError("EnrollController::enroll", error, "[ERROR] getting user");

                processUserCases(null, error);
            }

            private void processUserCases(User user, Error error) {
                if (user != null) {
//                    ManageCardController.deleteAll(context, storeManager);
                    //noinspection ConstantConditions
                    if (listener != null)
                        listener.onFailure(ErrorFactory.getWarnError(context, Error.ENROLL_USER_ENROLLED));
                } else {
                    if (!verifyState()) {
                        if (listener != null)
                            listener.onFailure(ErrorFactory.getWarnError(context, Error.GENERAL_PROCESS_IS_RUNNING));
                        return;
                    }
                    changeState();

                    switch (enrollRequest.getEnrollType()) {
                        case EnrollRequest.ENROLL_TYPE_DNI:
                            enrollByDni(context, enrollRequest, securityHelper, listener);
                            break;
                        case EnrollRequest.ENROLL_TYPE_PAN:
                            enrollByPan(context, enrollRequest, securityHelper, listener);
                            break;
                        case EnrollRequest.ENROLL_TYPE_USER:
                            enrollByUser(context, enrollRequest, securityHelper, listener);
                            break;
                        case EnrollRequest.ENROLL_TYPE_CLIENT:
                            enrollByClient(context, enrollRequest, securityHelper, listener);
                            break;
                        default:
                            //noinspection ConstantConditions
                            if (listener != null)
                                listener.onFailure(ErrorFactory.getWarnError(context, Error.GENERAL_INVALID_INPUT, new InvalidParameterException(String.format(context.getString(R.string.EXCEPTION_INVALID_INPUT), "enrollmentType"))));
                    }
                }
            }

        });
    }

    private void processDniPanEnrollResponse(ContextWrapper context, EnrollResponse response, EnrollRequest enrollRequest, RequestListener<Void> listener) {
        if (!validateEnrollResponse(response)) {
            changeState();
            if (listener != null)
                listener.onFailure(ErrorFactory.getFatalError(context, Error.ENROLL_BAD_RESPONSE_1));
            return;
        }
        cacheData(response, enrollRequest);
        changeState();
        if (listener != null)
            listener.onSuccess(null);
    }

    private void processFinishEnrollResponse(ContextWrapper context, FinishEnrollResponse finishEnrollResponse, EnrollRequest enrollRequest, final SecurityHelper securityHelper, RequestListener<Void> listener) {
        if (!validateFinishEnrollResponse(finishEnrollResponse)) {
            changeState();
            if (listener != null)
                listener.onFailure(ErrorFactory.getFatalError(context, Error.ENROLL_BAD_RESPONSE_2));
            return;
        }
        processEnrollResponse(context, enrollRequest, finishEnrollResponse, securityHelper, listener);
    }

    private void enrollByDni(final ContextWrapper context, final EnrollRequest enrollRequest, final SecurityHelper securityHelper, final RequestListener<Void> listener) {
        restController.performDNIEnroll(securityHelper.getHardwareIdentifier(),
                enrollRequest.getCardType(), enrollRequest.getProfileType(), enrollRequest.getEnrollData(), new RequestListener<EnrollResponse>() {
                    @Override
                    public void onSuccess(EnrollResponse response) {
                        processDniPanEnrollResponse(context, response, enrollRequest, listener);
                    }

                    @Override
                    public void onFailure(Error error) {
                        changeState();
                        if (listener != null)
                            listener.onFailure(processErrorForCheckUserHasOldCard(context, error));
                    }
                });
    }

    private void enrollByPan(final ContextWrapper context, final EnrollRequest enrollRequest, final SecurityHelper securityHelper, final RequestListener<Void> listener) {
        restController.performPANEnroll(securityHelper.getHardwareIdentifier(),
                enrollRequest.getCardType(), enrollRequest.getProfileType(), enrollRequest.getEnrollData(), new RequestListener<EnrollResponse>() {
                    @Override
                    public void onSuccess(EnrollResponse response) {
                        processDniPanEnrollResponse(context, response, enrollRequest, listener);
                    }

                    @Override
                    public void onFailure(Error error) {
                        changeState();
                        if (listener != null)
                            listener.onFailure(processErrorForCheckUserHasOldCard(context, error));
                    }
                });

    }

    private void enrollByUser(final ContextWrapper context, final EnrollRequest enrollRequest, final SecurityHelper securityHelper, final RequestListener<Void> listener) {
        restController.performUserFinishEnroll(enrollRequest.getPwd(), enrollRequest.getEmail(), enrollRequest.getPhone(), securityHelper.getHardwareIdentifier(),
                enrollRequest.getCardType(), enrollRequest.getProfileType(), getLongDateToString_AAAA_MM_DD(enrollRequest.getProfileExpiration()), enrollRequest.getPaySolutionType(), enrollRequest.getEnrollData(), new RequestListener<FinishEnrollResponse>() {
                    @Override
                    public void onSuccess(final FinishEnrollResponse finishEnrollResponse) {
                        processFinishEnrollResponse(context, finishEnrollResponse, enrollRequest, securityHelper, listener);
                    }

                    @Override
                    public void onFailure(Error error) {
                        changeState();
                        if (listener != null)
                            listener.onFailure(processErrorForCheckUserHasOldCard(context, error));
                    }
                });
    }

    private void enrollByClient(final ContextWrapper context, final EnrollRequest enrollRequest, final SecurityHelper securityHelper, final RequestListener<Void> listener) {
        restController.performClientFinishEnroll(enrollRequest.getPwd(), enrollRequest.getEmail(), enrollRequest.getPhone(), securityHelper.getHardwareIdentifier(),
                enrollRequest.getCardType(), enrollRequest.getProfileType(), getLongDateToString_AAAA_MM_DD(enrollRequest.getProfileExpiration()), enrollRequest.getPaySolutionType(), enrollRequest.getEnrollData(), new RequestListener<FinishEnrollResponse>() {
                    @Override
                    public void onSuccess(final FinishEnrollResponse finishEnrollResponse) {
                        processFinishEnrollResponse(context, finishEnrollResponse, enrollRequest, securityHelper, listener);
                    }

                    @Override
                    public void onFailure(Error error) {
                        changeState();
                        if (listener != null)
                            listener.onFailure(processErrorForCheckUserHasOldCard(context, error));
                    }
                });
    }

    void finishEnroll(final ContextWrapper context, final FinishEnrollRequest finishEnrollRequest, final SecurityHelper securityHelper, final RequestListener<Void> listener) {
        if (enrollRequest == null || enrollResponse == null) {
            if (listener != null)
                listener.onFailure(ErrorFactory.getWarnError(context, Error.ENROLL_NO_DNI_PAN_ENROLLMENT));
            return;
        }

        if (finishEnrollRequest == null) {
            if (listener != null)
                listener.onFailure(ErrorFactory.getWarnError(context, Error.GENERAL_INVALID_INPUT));
            return;
        }

        if (finishEnrollRequest.getOtp() == null || finishEnrollRequest.getOtp().isEmpty()) {
            if (listener != null) {
                listener.onFailure(ErrorFactory.getWarnError(context, Error.GENERAL_INVALID_INPUT,
                        new InvalidParameterException(String.format(context.getString(R.string.EXCEPTION_INVALID_INPUT), "otp"))));
            }
            return;
        }

        if (!verifyState()) {
            if (listener != null)
                listener.onFailure(ErrorFactory.getWarnError(context, Error.GENERAL_PROCESS_IS_RUNNING));
            return;
        }
        changeState();

        finishEnrollByOTP(context, enrollRequest, enrollResponse, finishEnrollRequest, securityHelper, listener);
    }

    private void finishEnrollByOTP(final ContextWrapper context, final EnrollRequest enrollRequest, EnrollResponse enrollResponse, FinishEnrollRequest finishEnrollRequest, final SecurityHelper securityHelper, final RequestListener<Void> listener) {
        restController.performOtpFinishEnroll(enrollRequest.getPwd(), enrollRequest.getEmail(), enrollRequest.getPhone(), securityHelper.getHardwareIdentifier(),
                enrollRequest.getProfileType(), getLongDateToString_AAAA_MM_DD(enrollRequest.getProfileExpiration()), enrollRequest.getPaySolutionType(), enrollResponse.getTokenId(), enrollResponse.getId(), finishEnrollRequest.getOtp(), new RequestListener<FinishEnrollResponse>() {
                    @Override
                    public void onSuccess(final FinishEnrollResponse finishEnrollResponse) {
                        processFinishEnrollResponse(context, finishEnrollResponse, enrollRequest, securityHelper, listener);
                    }

                    @Override
                    public void onFailure(Error error) {
                        changeState();
                        if (listener != null)
                            listener.onFailure(error);
                    }
                });
    }

    private void processEnrollResponse(final ContextWrapper context, EnrollRequest enrollRequest, final FinishEnrollResponse finishEnrollResponse, final SecurityHelper securityHelper, final RequestListener<Void> listener) {
        UserRealm userRealm = new UserRealm();
        userRealm.setName(enrollRequest.getEnrollData());
        userRealm.setPhoneId(finishEnrollResponse.getPhoneId());
        userRealm.setToken(finishEnrollResponse.getTokenId());
        userRealm.setCardId(finishEnrollResponse.getPan());
        userRealm.setUserId(finishEnrollResponse.getUserId());
        userRealm.setCardType(enrollRequest.getCardType());
        userRealm.setProfileType(enrollRequest.getProfileType());
        userRealm.setPaySolutionType(enrollRequest.getPaySolutionType());
        userRealm.setProfileExpiration(finishEnrollResponse.getProfileExpiration());
        storeManager.insert(userRealm, new RequestListener<Void>() {
            @Override
            public void onSuccess(Void response) {
                GaAppFile gaAppFile = finishEnrollResponse.getPersoFile().getFile();
                GaCardRealm gaCardRealm = new GaCardRealm();
                gaCardRealm.setFile(new Gson().toJson(gaAppFile));

                storeManager.insert(gaCardRealm, new RequestListener<Void>() {
                    @Override
                    public void onSuccess(Void response) {
                        Error error = null;
                        try {
                            securityHelper.saveSecret(SecurityHelper.FOUR_BYTES, finishEnrollResponse.getSignature());
                        } catch (Exception e) {
                            error = ErrorFactory.getFatalError(context, Error.GENERAL_UNEXPECTED_EXCEPTION, e);
                        }
                        if (error != null) {
                            changeState();
                            if (listener != null)
                                listener.onFailure(error);
                            return;
                        }

                        restController.confirmEnrollment(finishEnrollResponse.getHwId(), finishEnrollResponse.getPan(), finishEnrollResponse.getTokenId(), finishEnrollResponse.getPhoneId(),
                                new RequestListener<BaseResponse>() {
                                    @Override
                                    public void onSuccess(BaseResponse response) {
                                        // Nothing
                                        CoreController.getLogger().logDebug("EnrollController::processEnrollResponse", "confirmEnrollment OK");
                                    }

                                    @Override
                                    public void onFailure(Error error) {
                                        // Nothing
                                        CoreController.getLogger().logError("EnrollController::processEnrollResponse", error, "confirmEnrollment KO");
                                    }
                                });

                        // Finished
                        changeState();
                        if (listener != null)
                            listener.onSuccess(null);
                    }

                    @Override
                    public void onFailure(Error error) {
                        changeState();
                        if (listener != null)
                            listener.onFailure(error);
                    }
                });
            }

            @Override
            public void onFailure(Error error) {
                changeState();
                if (listener != null)
                    listener.onFailure(error);
            }
        });
    }

    private String getLongDateToString_AAAA_MM_DD(long date) {
        if (date <= 0) return "";
        Calendar calendar = Calendar.getInstance();
        calendar.setTimeInMillis(date);
        int yyyy = calendar.get(Calendar.YEAR);
        int mm = calendar.get(Calendar.MONTH) + 1;
        int dd = calendar.get(Calendar.DAY_OF_MONTH);
        return yyyy + "-" + (mm < 10 ? "0" + mm : mm) + "-" + (dd < 10 ? "0" + dd : dd);
    }

    private boolean verifyState() {
        return this.allowPetition;
    }

    private void changeState() {
        allowPetition = !verifyState();
    }

    private String pan;
    private String tokenId;
    private String hwId;

    private void cacheCardDataForManage(String pan, String tokenId, String hwId) {
        this.pan = pan;
        this.tokenId = tokenId;
        this.hwId = hwId;
    }

    private Error processErrorForCheckUserHasOldCard(ContextWrapper context, Error error) {
        if (error == null) return error;
        String msg = error.getMsg();
        if (msg == null)
            return error;
        // "0001:0084 - UserId con TJ;PAN;TokenId;HwId"
        String[] splitMsg = msg.split(":");
        if (splitMsg.length != 2) return error;
        String status = splitMsg[0];
        if (!"0001".equalsIgnoreCase(status)) return error;
        String strError = splitMsg[1];
        if (strError != null && !strError.isEmpty() && "0084".equalsIgnoreCase(strError.substring(0, 4))) {
            String[] split = strError.split(";");
            if (split.length == 4) {
                return processUserHasOldCardError(context, split[1], split[2], split[3]);
            }
        }
        return error;
    }

    private Error processUserHasOldCardError(ContextWrapper context, String pan, String tokenId, String hwId) {
        cacheCardDataForManage(pan, tokenId, hwId);
        return ErrorFactory.getWarnError(context, Error.ENROLL_USER_HAS_OLD_CARD, new Exception(pan));
    }

    void manageCard(final ContextWrapper context, EnrollLockCardRequest request, final RequestListener<Void> listener) {
        if (request == null) {
            if (listener != null)
                listener.onFailure(ErrorFactory.getWarnError(context, Error.GENERAL_INVALID_INPUT));
            return;
        }
        if (request.getPan() == null || request.getPan().isEmpty() || !request.getPan().equalsIgnoreCase(pan)) {
            if (listener != null)
                listener.onFailure(ErrorFactory.getWarnError(context, Error.GENERAL_INVALID_INPUT, new Exception(String.format(context.getString(R.string.EXCEPTION_INVALID_INPUT), "pan"))));
            return;
        }
//        if (request.getStatus() == null || request.getStatus().isEmpty()) {
//            if (listener != null)
//                listener.onFailure(ErrorFactory.getWarnError(context, Error.GENERAL_INVALID_INPUT, new Exception(String.format(context.getString(R.string.EXCEPTION_INVALID_INPUT), "Status"))));
//            return;
//        }
//        if (EnrollLockCardRequest.STATUS_UNSUBSCRIBE.equalsIgnoreCase(request.getStatus())) {
//            if (request.getIndicator() == null || request.getIndicator().isEmpty()) {
//                if (listener != null)
//                    listener.onFailure(ErrorFactory.getWarnError(context, Error.GENERAL_INVALID_INPUT, new Exception(String.format(context.getString(R.string.EXCEPTION_INVALID_INPUT), "Indicator"))));
//                return;
//            } else if (request.getMethod() == null || request.getMethod().isEmpty()) {
//                if (listener != null)
//                    listener.onFailure(ErrorFactory.getWarnError(context, Error.GENERAL_INVALID_INPUT, new Exception(String.format(context.getString(R.string.EXCEPTION_INVALID_INPUT), "Method"))));
//                return;
//            }
//        }
        if (hwId == null || hwId.isEmpty() || tokenId == null || tokenId.isEmpty()) {
            Error error;
            if (hwId == null || hwId.isEmpty()) {
                error = ErrorFactory.getWarnError(context, Error.GENERAL_INVALID_INPUT,
                        new InvalidParameterException(String.format(context.getString(R.string.EXCEPTION_INVALID_INPUT), "hwId")));
            } else {
                error = ErrorFactory.getWarnError(context, Error.GENERAL_INVALID_INPUT,
                        new InvalidParameterException(String.format(context.getString(R.string.EXCEPTION_INVALID_INPUT), "tokenId")));
            }
            if (listener != null)
                listener.onFailure(error);
            return;
        }
        if (!verifyState()) {
            if (listener != null)
                listener.onFailure(ErrorFactory.getWarnError(context, Error.GENERAL_PROCESS_IS_RUNNING));
            return;
        }
        changeState();

        // String tokenId, String hwId, String pan, String status, String indicator, String method, RequestListener<BaseResponse> listener
        restController.enrollManageCard(tokenId, hwId, pan, new RequestListener<BaseResponse>() {
            @Override
            public void onSuccess(BaseResponse response) {
                ManageCardController.deleteAll(context, storeManager);
                changeState();
                if (listener != null) listener.onSuccess(null);

            }

            @Override
            public void onFailure(Error error) {
                changeState();
                if (listener != null) listener.onFailure(error);
            }
        });
    }
}
