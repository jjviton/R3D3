package com.did.gatransport.ui;

import android.content.Intent;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;

import com.did.gatransport.R;
import com.did.gatransport.controller.CoreController;
import com.did.gatransport.controller.PreferencesController;
import com.did.gatransport.controller.ProcessController;
import com.did.gatransport.model.Error;
import com.did.gatransport.model.request.CardRechargeRequest;
import com.did.gatransport.model.request.TokenCardRechargeRequest;
import com.did.gatransport.util.ErrorFactory;
import com.google.gson.Gson;

import java.security.InvalidParameterException;

public abstract class RechargeActivity extends TimerActivity {

    public static final String INTENT_EXTRA_BUNDLE = "INTENT_EXTRA_BUNDLE";
    public static final String BUNDLE_EXTRA_REQUEST = "BUNDLE_EXTRA_REQUEST";
    public static final String INTENT_EXTRA_ERROR = "error";
    private static final int MAX_TIME_IDLE = 10; // min


    @SuppressWarnings("FieldCanBeLocal")
    private boolean allowBack = false;

    private final RechargeActivityController.RechargeActivityControllerListener controllerListener = new RechargeActivityController.RechargeActivityControllerListener() {
        @Override
        public void onFinishOK() {
            finishOK();
        }

        @Override
        public void onFinishKO(Error error) {
            finishKO(error);
        }
    };

    private RechargeActivityController controller;

    @Override
    protected final void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.gatdefault_layout_activity_recharge);
//        setTitle("");
//
////        Toolbar toolbar = findViewById(R.id.toolbar_top);
////        setSupportActionBar(toolbar);
////        ActionBar actionBar = getSupportActionBar();
////        if (actionBar != null) {
////            actionBar.setDisplayHomeAsUpEnabled(true);
////        }
        Error error = CoreController.getInstance().validateAction(this);
        if (error != null) {
            finishKO(error);
            return;
        }

        if (PreferencesController.getInstance(this).isLockedCard()) {
            finishKO(ErrorFactory.getWarnError(this, Error.CARD_LOCKED_MANUALLY));
            return;
        }

        View fragmentContainer = findViewById(R.id.default_recharge_fragment_container);
        if (!(fragmentContainer instanceof RechargeFrameLayout) || fragmentContainer.getClass() != RechargeFrameLayout.class) {
            finishKOBadResources();
        }

        Intent intent = getIntent();
        if (intent == null) {
            finishKO(ErrorFactory.getWarnError(this, Error.GENERAL_INVALID_INPUT, new InvalidParameterException(String.format(getString(R.string.EXCEPTION_INVALID_INPUT), "intent"))));
            return;
        } else {
            Bundle bundle = intent.getBundleExtra(INTENT_EXTRA_BUNDLE);
            if (bundle == null) {
                finishKO(ErrorFactory.getWarnError(this, Error.GENERAL_INVALID_INPUT, new InvalidParameterException(String.format(getString(R.string.EXCEPTION_INVALID_INPUT), INTENT_EXTRA_BUNDLE))));
                return;
            } else {
                Object request = bundle.getParcelable(BUNDLE_EXTRA_REQUEST);
                if (request instanceof CardRechargeRequest) {
                    controller = new CardRechargeActivityController(this, getSupportFragmentManager(), R.id.default_recharge_fragment_container, (CardRechargeRequest) request, PreferencesController.getInstance(this).getHostUrl(), controllerListener);
                } else if (request instanceof TokenCardRechargeRequest) {
                    controller = new TokenCardRechargeActivityController(this, getSupportFragmentManager(), R.id.default_recharge_fragment_container, (TokenCardRechargeRequest) request, PreferencesController.getInstance(this).getHostUrl(), controllerListener);
                } else {
                    finishKO(ErrorFactory.getWarnError(this, Error.GENERAL_INVALID_INPUT, new InvalidParameterException(String.format(getString(R.string.EXCEPTION_INVALID_INPUT), BUNDLE_EXTRA_REQUEST))));
                    return;
                }
            }
        }

        ProcessController.setRpIsRunning(true);
        if (controller != null)
            controller.startProcess();

        setInactivityTime(MAX_TIME_IDLE);
    }


    @Override
    protected final void onStart() {
        super.onStart();
    }


    @Override
    protected final void onStop() {
        super.onStop();
        ProcessController.setRpIsRunning(false);
    }

    @Override
    protected final void onDestroy() {
        super.onDestroy();
        ProcessController.setRpIsRunning(false);
        if (controller != null)
            controller.destroy();
    }

    @Override
    public final void onBackPressed() {
        // Locked
    }

    @Override
    public final void onUserInactivityEvent() {
        if (controller.isFinishedOK()) {
            finishOK();
        } else if (controller.getConfirmRechargeError() != null) {
            finishKO(controller.getConfirmRechargeError());
        } else {
            finishKO(ErrorFactory.getWarnError(this, Error.RECHARGE_INACTIVE));
        }
    }

    @Override
    public final boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case android.R.id.home:
                if (allowBack) {
                    onBackPressed();
                } else
                    return true;
                break;
        }

        return super.onOptionsItemSelected(item);
    }

    private void finishOK() {
        CoreController.getLogger().logDebug("RechargeActivity::finishOK", "END OK");
        setResult(RESULT_OK);
        ProcessController.setRpIsRunning(false);
        finish();
    }

    private void finishKO(final Error returnError) {
        CoreController.getLogger().logDebug("RechargeActivity::finishKO", "END KO");
        Intent data = new Intent();
        if (returnError != null) {
            data.putExtra(INTENT_EXTRA_ERROR, new Gson().toJson(returnError));
        }
        setResult(RESULT_CANCELED, data);
        ProcessController.setRpIsRunning(false);
        finish();
    }

    private void finishKOBadResources() {
        finishKO(ErrorFactory.getFatalError(this, Error.GENERAL_INVALID_RESOURCES));
    }

}
