package com.did.gatransport.rest.retrofit.request;

import com.google.gson.annotations.SerializedName;

public class BaseFinishEnrollRequest implements FinishEnrollRequest {

    @SerializedName("Password")
    private String pwd;
    @SerializedName("Email")
    private String mail;
    @SerializedName("Phone_Number")
    private String phone;
    @SerializedName("HW_ID")
    private String hwId;
    @SerializedName("Card_Type")
    private String cardType;
    @SerializedName("Profile")
    private String profile;
    @SerializedName("Profile_Exp")
    private String profileExpiration;
    @SerializedName("Pay_Sol")
    private String paySolution;

    public BaseFinishEnrollRequest() {
    }

    @Override
    public String getPwd() {
        return pwd;
    }

    @Override
    public void setPwd(String pwd) {
        this.pwd = pwd;
    }

    @Override
    public String getMail() {
        return mail;
    }

    @Override
    public void setMail(String mail) {
        this.mail = mail;
    }

    @Override
    public String getPhone() {
        return phone;
    }

    @Override
    public void setPhone(String phone) {
        this.phone = phone;
    }

    @Override
    public String getHwId() {
        return hwId;
    }

    @Override
    public void setHwId(String hwId) {
        this.hwId = hwId;
    }

    @Override
    public String getCardType() {
        return cardType;
    }

    @Override
    public void setCardType(String cardType) {
        this.cardType = cardType;
    }

    @Override
    public String getProfile() {
        return profile;
    }

    @Override
    public void setProfile(String profile) {
        this.profile = profile;
    }

    @Override
    public String getProfileExpiration() {
        return profileExpiration;
    }

    @Override
    public void setProfileExpiration(String profileExpiration) {
        this.profileExpiration = profileExpiration;
    }

    @Override
    public String getPaySolution() {
        return paySolution;
    }

    @Override
    public void setPaySolution(String paySolution) {
        this.paySolution = paySolution;
    }
}
