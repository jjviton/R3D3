package com.did.gatransport.model;

import com.did.gatransport.store.realm.model.TripRealm;

public final class Trip {

    public static final String TYPE_DEBIT = TripRealm.TYPE_DEBIT;
    public static final String TYPE_CANCEL = TripRealm.TYPE_CANCEL;

    private long time;

    private int amount;

    private String line;

    private String type;

    public long getTime() {
        return time;
    }

    public void setTime(long time) {
        this.time = time;
    }

    public int getAmount() {
        return amount;
    }

    public void setAmount(int amount) {
        this.amount = amount;
    }

    public String getLine() {
        return line;
    }

    public void setLine(String line) {
        this.line = line;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }
}
