package com.did.gacard.core.protocol;

import com.did.gacard.ecard.util.ByteArray;

import java.util.Random;

import javax.crypto.Cipher;
import javax.crypto.SecretKey;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.IvParameterSpec;

public final class GaSecurityCalculator {
    private static final String TAG = "GaSeCalculator";

    private static final short OFFSET_KD = (short) 0x00;
    private static final short SIZE_KD = (short) 0x08;
    private static final short OFFSET_SK = (short) 0x00;
    private static final short SIZE_SK = (short) 0x08;
    private static final short OFFSET_MAC = (short) 0x00;
    private static final short SIZE_MAC = (short) 0x08;
    private static final short OFFSET_SIGNATURE = (short) 0x00;
    private static final short SIZE_SIGNATURE = (short) 0x08;

    private static final short OFFSET_OUTER = (short) 0x00;
    private static final short SIZE_OUTER = (short) 0x04;
    private static final short OFFSET_INNER = (short) 0x04;
    private static final short SIZE_INNER = (short) 0x04;

    private static final short SIZE_CHALLENGE = (short) 0x04;
    private static final short OFFSET_CHALLENGE = (short) 0x04;

    private byte[] mKd;
    private byte[] mSK;
    private SecretKeyFactory mDesKey;
    private Cipher mDesCipher;

    private byte[] mSignature;
    private byte[] mMAC;

    private boolean canDigest = false;

    private GaSecurityElement gaSecurityElement;

    public GaSecurityCalculator(byte[] kd) {
        this(kd, GaSecurityElement.DEFAULT);
    }

    public GaSecurityCalculator(byte[] kd, GaSecurityElement gaSecurityElement) {
        this.mKd = kd;
        this.gaSecurityElement = gaSecurityElement == null ? GaSecurityElement.DEFAULT : gaSecurityElement;
    }

    private void create() {
        this.canDigest = false;
        this.mSK = new byte[SIZE_SK];
        this.mSignature = new byte[SIZE_SIGNATURE];
        this.mMAC = new byte[SIZE_MAC];

        try {
            this.mDesCipher = Cipher.getInstance("DES/CBC/NoPadding");
        } catch (Exception e) {
            this.mDesCipher = null;
        }
        try {
            this.mDesKey = SecretKeyFactory.getInstance("DES");
        } catch (Exception e) {
            this.mDesKey = null;
        }
    }

    private int macState = 0;

    private byte[] merge(byte[] s) {
        byte[] rand = new byte[2];
        new Random().nextBytes(rand);
        return new byte[]{s[0], s[1], rand[0], rand[1]};
    }

    public byte[] init(byte[] outerKey) {
        byte[] innerKey = merge(gaSecurityElement.getRandom(SIZE_INNER));
        return init(outerKey, innerKey);
    }

    private byte[] init(byte[] outerKey, byte[] innerKey) {
        create();

        if (outerKey.length != SIZE_OUTER) {
            mSK = new byte[SIZE_OUTER];
        } else {
            ByteArray.fillBytes(mSK, OFFSET_OUTER, outerKey);
            ByteArray.fillBytes(mSK, OFFSET_INNER, innerKey);
        }

//        GaCard.getInstance().getLogger().logDebug("GaSecurityCalculator::init", "mKd: " + ByteArray.byteArrayToHexString(mKd));
//        GaCard.getInstance().getLogger().logDebug("GaSecurityCalculator::init", "outerKey||innerKey: " + ByteArray.byteArrayToHexString(mSK));

        byte[] random = ByteArray.getBytes(mSK, OFFSET_INNER, SIZE_INNER);

        if (mDesCipher == null || mDesKey == null)
            return null;

        try {
            SecretKey sKey = mDesKey.generateSecret(new DESKeySpec(mKd, OFFSET_KD));
            IvParameterSpec ivSpec = new IvParameterSpec(new byte[8]);
            mDesCipher.init(Cipher.ENCRYPT_MODE, sKey, ivSpec);
            mSK = mDesCipher.doFinal(mSK);
        } catch (Exception e) {
            return null;
        }

        ByteArray.fillBytes(mMAC, OFFSET_SK, mSK);

//        GaCard.getInstance().getLogger().logDebug("GaSecurityCalculator::init", "mSK: " + ByteArray.byteArrayToHexString(mSK));
//        GaCard.getInstance().getLogger().logDebug("GaSecurityCalculator::init", "mMAC " + macState + " : " + ByteArray.byteArrayToHexString(mMAC));

        canDigest = true;

        return random;
    }

    public byte[] getMAC() {
        return mMAC;
    }

    public void add(byte[] data, short offset, short length) {
        if (!canDigest) return;
//        GaCard.getInstance().getLogger().logDebug("GaSecurityCalculator::add", "add: " + ByteArray.byteArrayToHexString(data));
        // Recorremos los datos a comprimir de 0 a (length-1)
        for (short i = 0; i < length; i++) {
            // Primero calculamos el byte en la posición (mac.length - 1), con mac.length = 8
            mMAC[mMAC.length - 1] ^= data[offset + i];
            // Segundo vamos calculando los bytes del mac desde la posición (mac.length-2) hasta 0
            for (short j = (short) (mMAC.length - 2); j >= 0; j--) {
                mMAC[j] ^= mMAC[j + 1];
            }
        }
        macState++;
//        GaCard.getInstance().getLogger().logDebug("GaSecurityCalculator::add", "mMAC " + macState + " : " + ByteArray.byteArrayToHexString(mMAC));
    }

    public void add(byte[] data) {
        if (data != null)
            add(data, (short) 0, (short) data.length);
    }

    public boolean digest() {
        if (!canDigest) return false;

        if (mDesKey == null || mDesCipher == null) return false;

        try {
            SecretKey sKey = mDesKey.generateSecret(new DESKeySpec(mSK, OFFSET_SK));
            IvParameterSpec ivSpec = new IvParameterSpec(new byte[8]);
            mDesCipher.init(Cipher.ENCRYPT_MODE, sKey, ivSpec);
            mSignature = mDesCipher.doFinal(mMAC);
        } catch (Exception e) {
            return false;
        }

        canDigest = false;

//        GaCard.getInstance().getLogger().logDebug("GaSecurityCalculator::digest", "Digested: " + ByteArray.byteArrayToHexString(mSignature));

        return true;
    }

    private byte[] getCertificateHi() {
        return ByteArray.getBytes(mSignature, OFFSET_CHALLENGE - 4, SIZE_CHALLENGE);
    }

    public byte[] getCertificate() {
        return ByteArray.getBytes(mSignature, OFFSET_CHALLENGE - 4, SIZE_CHALLENGE * 2);
    }

    public byte[] getCertificateLo() {
        return ByteArray.getBytes(mSignature, OFFSET_CHALLENGE, SIZE_CHALLENGE);
    }

    public boolean checkCertificateHi(byte[] certificateHi) {
        return certificateHi.length == 4 && checkCertificateHi(certificateHi[2], certificateHi[3]);

//        byte[] calCertificateHi = getCertificateHi();
//        log(ByteArray.byteArrayToHexString(certificateHi) + "=?" + ByteArray.byteArrayToHexString(calCertificateHi));
//        return certificateHi.length == 4 && Arrays.equals(certificateHi, calCertificateHi);
    }

    private boolean checkCertificateHi(byte s0, byte s1) {
        byte[] calCertificateHi = getCertificateHi();
        return s0 == calCertificateHi[2] && s1 == calCertificateHi[3];
    }

    public void commitCertificateHi(byte[] certificateHi) {
        if (certificateHi != null && checkCertificateHi(certificateHi))
            gaSecurityElement.check(certificateHi);
    }
}
