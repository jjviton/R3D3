package com.did.gatransport.rest.retrofit.request;

public interface EnrollRequest {
    String getHwId();

    void setHwId(String hwId);

    String getCardType();

    void setCardType(String cardType);

    String getProfile();

    void setProfile(String profile);
}
