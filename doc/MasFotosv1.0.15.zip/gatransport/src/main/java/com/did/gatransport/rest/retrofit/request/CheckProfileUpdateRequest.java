package com.did.gatransport.rest.retrofit.request;

import com.google.gson.annotations.SerializedName;

public final class CheckProfileUpdateRequest {

    @SerializedName("Phone_ID")
    private String phoneId;
    @SerializedName("HW_ID")
    private String hwId;
    @SerializedName("PAN")
    private String pan;
    @SerializedName("Pay_Sol")
    private String paySolution;
    @SerializedName("Language")
    private String language;
    @SerializedName("Profile")
    private String profile;
    @SerializedName("Profile_exp")
    private String profileExpiration;

    public CheckProfileUpdateRequest() {

    }

    public String getPhoneId() {
        return phoneId;
    }

    public void setPhoneId(String phoneId) {
        this.phoneId = phoneId;
    }

    public String getHwId() {
        return hwId;
    }

    public void setHwId(String hwId) {
        this.hwId = hwId;
    }

    public String getPan() {
        return pan;
    }

    public void setPan(String pan) {
        this.pan = pan;
    }

    public String getPaySolution() {
        return paySolution;
    }

    public void setPaySolution(String paySolution) {
        this.paySolution = paySolution;
    }

    public String getLanguage() {
        return language;
    }

    public void setLanguage(String language) {
        this.language = language;
    }

    public String getProfile() {
        return profile;
    }

    public void setProfile(String profile) {
        this.profile = profile;
    }

    public String getProfileExpiration() {
        return profileExpiration;
    }

    public void setProfileExpiration(String profileExpiration) {
        this.profileExpiration = profileExpiration;
    }
}
