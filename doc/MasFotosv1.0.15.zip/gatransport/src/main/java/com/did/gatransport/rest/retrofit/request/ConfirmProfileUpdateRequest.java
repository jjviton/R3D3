package com.did.gatransport.rest.retrofit.request;

import com.google.gson.annotations.SerializedName;

public final class ConfirmProfileUpdateRequest {

    @SerializedName("Phone_ID")
    private String phoneId;
    @SerializedName("HW_ID")
    private String hwId;
    @SerializedName("PAN")
    private String pan;
    @SerializedName("Profile")
    private String oldProfile;
    @SerializedName("Profile_Exp")
    private String oldProfileExpiration;
    @SerializedName("Profile_tsmp")
    private String timestamp;
    @SerializedName("Profile_New")
    private String newProfile;
    @SerializedName("Profile_New_Exp")
    private String newProfileExpiration;
    @SerializedName("Pay_Sol")
    private String paySolution;
    @SerializedName("NT")
    private String nt;

    public ConfirmProfileUpdateRequest() {
    }

    public String getPhoneId() {
        return phoneId;
    }

    public void setPhoneId(String phoneId) {
        this.phoneId = phoneId;
    }

    public String getHwId() {
        return hwId;
    }

    public void setHwId(String hwId) {
        this.hwId = hwId;
    }

    public String getPan() {
        return pan;
    }

    public void setPan(String pan) {
        this.pan = pan;
    }

    public String getOldProfile() {
        return oldProfile;
    }

    public void setOldProfile(String oldProfile) {
        this.oldProfile = oldProfile;
    }

    public String getOldProfileExpiration() {
        return oldProfileExpiration;
    }

    public void setOldProfileExpiration(String oldProfileExpiration) {
        this.oldProfileExpiration = oldProfileExpiration;
    }

    public String getTimestamp() {
        return timestamp;
    }

    public void setTimestamp(String timestamp) {
        this.timestamp = timestamp;
    }

    public String getNewProfile() {
        return newProfile;
    }

    public void setNewProfile(String newProfile) {
        this.newProfile = newProfile;
    }

    public String getNewProfileExpiration() {
        return newProfileExpiration;
    }

    public void setNewProfileExpiration(String newProfileExpiration) {
        this.newProfileExpiration = newProfileExpiration;
    }

    public String getPaySolution() {
        return paySolution;
    }

    public void setPaySolution(String paySolution) {
        this.paySolution = paySolution;
    }

    public String getNt() {
        return nt;
    }

    public void setNt(String nt) {
        this.nt = nt;
    }
}
