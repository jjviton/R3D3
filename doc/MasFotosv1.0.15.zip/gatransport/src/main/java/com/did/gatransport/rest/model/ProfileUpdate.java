package com.did.gatransport.rest.model;

import com.google.gson.annotations.SerializedName;

public final class ProfileUpdate {

    @SerializedName("type")
    private String type;

    @SerializedName("profile")
    private String currentProfile;
    @SerializedName("profile_exp")
    private String currentProfileExpiration;
    @SerializedName("profile_desc")
    private String currentProfileDescription;
    @SerializedName("timestamp")
    private String timestamp;

    @SerializedName("profile_new")
    private String newProfile;
    @SerializedName("profile_new_ini")
    private String newProfileInitialization;
    @SerializedName("profile_new_exp")
    private String newProfileExpiration;
    @SerializedName("profile_new_desc")
    private String newProfileDescription;

    public ProfileUpdate() {
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public String getCurrentProfile() {
        return currentProfile;
    }

    public void setCurrentProfile(String currentProfile) {
        this.currentProfile = currentProfile;
    }

    public String getCurrentProfileExpiration() {
        return currentProfileExpiration;
    }

    public void setCurrentProfileExpiration(String currentProfileExpiration) {
        this.currentProfileExpiration = currentProfileExpiration;
    }

    public String getCurrentProfileDescription() {
        return currentProfileDescription;
    }

    public void setCurrentProfileDescription(String currentProfileDescription) {
        this.currentProfileDescription = currentProfileDescription;
    }

    public String getTimestamp() {
        return timestamp;
    }

    public void setTimestamp(String timestamp) {
        this.timestamp = timestamp;
    }

    public String getNewProfile() {
        return newProfile;
    }

    public void setNewProfile(String newProfile) {
        this.newProfile = newProfile;
    }

    public String getNewProfileInitialization() {
        return newProfileInitialization;
    }

    public void setNewProfileInitialization(String newProfileInitialization) {
        this.newProfileInitialization = newProfileInitialization;
    }

    public String getNewProfileExpiration() {
        return newProfileExpiration;
    }

    public void setNewProfileExpiration(String newProfileExpiration) {
        this.newProfileExpiration = newProfileExpiration;
    }

    public String getNewProfileDescription() {
        return newProfileDescription;
    }

    public void setNewProfileDescription(String newProfileDescription) {
        this.newProfileDescription = newProfileDescription;
    }
}
