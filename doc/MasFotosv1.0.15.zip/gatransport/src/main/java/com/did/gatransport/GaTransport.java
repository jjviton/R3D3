package com.did.gatransport;

import android.content.ContextWrapper;
import android.support.annotation.IntRange;
import android.support.annotation.NonNull;

import com.did.gatransport.controller.CoreController;
import com.did.gatransport.interfaces.RequestListener;
import com.did.gatransport.interfaces.SynchronizationListener;
import com.did.gatransport.interfaces.TripListener;
import com.did.gatransport.model.Error;
import com.did.gatransport.model.PendingPayment;
import com.did.gatransport.model.PendingRechargeConfirm;
import com.did.gatransport.model.ProfileUpdate;
import com.did.gatransport.model.Recharge;
import com.did.gatransport.model.SecurityCheck;
import com.did.gatransport.model.TokenCardPayment;
import com.did.gatransport.model.Trip;
import com.did.gatransport.model.request.EnrollLockCardRequest;
import com.did.gatransport.model.request.EnrollRequest;
import com.did.gatransport.model.request.FinishEnrollRequest;
import com.did.gatransport.model.request.LoginRequest;
import com.did.gatransport.model.request.ManageCardRequest;
import com.did.gatransport.model.request.PendingRechargeRequest;
import com.did.gatransport.model.request.ProfileUpdateRequest;
import com.did.gatransport.model.request.RegisterPushChannelRequest;
import com.did.gatransport.model.request.SecurityCheckRequest;

import java.net.URL;
import java.util.List;

public final class GaTransport {
    public static final int NONE = CoreController.NONE;
    public static final int FULL = CoreController.FULL;

    private static GaTransport instance;

    public static GaTransport getInstance() {
        if (instance == null) instance = new GaTransport();
        return instance;
    }

    private GaTransport() {

    }

    public Error initialize(@NonNull ContextWrapper context, @NonNull URL host, @NonNull String syncJobServiceClassName) {
        return CoreController.getInstance().initialize(context, host, null, null, syncJobServiceClassName);
    }

    public Error initialize(@NonNull ContextWrapper context, @NonNull URL host, SynchronizationListener syncListener, TripListener tripListener, @NonNull String syncJobServiceClassName) {
        return CoreController.getInstance().initialize(context, host, syncListener, tripListener, syncJobServiceClassName);
    }

    public Error scheduleSync(@NonNull ContextWrapper context) {
        return CoreController.getInstance().scheduleSync(context);
    }

    public void setLogLevel(@IntRange(from = NONE, to = FULL) int logLevel) {
        CoreController.getInstance().setLogLevel(logLevel);
    }

    public void setSyncListener(SynchronizationListener listener) {
        CoreController.getInstance().setSyncListener(listener);
    }

    public void setTripListener(TripListener listener) {
        CoreController.getInstance().setTripListener(listener);
    }

    public Error setLockedCard(@NonNull ContextWrapper context, boolean lockedCard) {
        return CoreController.getInstance().setLockedCard(context, lockedCard);
    }

    public void isLockedCard(@NonNull ContextWrapper context, RequestListener<Boolean> listener) {
        CoreController.getInstance().isLockedCard(context, listener);
    }

    public Error setVibrateEnabled(@NonNull ContextWrapper context, boolean vibrateEnabled) {
        return CoreController.getInstance().setVibrateEnabled(context, vibrateEnabled);
    }

    public void isVibrateEnabled(@NonNull ContextWrapper context, RequestListener<Boolean> listener) {
        CoreController.getInstance().isVibrateEnabled(context, listener);
    }

    public Error setRingNotificationEnabled(@NonNull ContextWrapper context, boolean ringNotificationEnabled) {
        return CoreController.getInstance().setRingNotificationEnabled(context, ringNotificationEnabled);
    }

    public void isRingNotificationEnabled(@NonNull ContextWrapper context, RequestListener<Boolean> listener) {
        CoreController.getInstance().isRingNotificationEnabled(context, listener);
    }

    public void getBalance(@NonNull ContextWrapper context, @NonNull RequestListener<Integer> listener) {
        CoreController.getInstance().getBalance(context, listener);
    }

    public void getRecharges(@NonNull ContextWrapper context, @NonNull RequestListener<List<Recharge>> listener) {
        CoreController.getInstance().getRecharges(context, listener);
    }

    public void getTrips(@NonNull ContextWrapper context, @NonNull RequestListener<List<Trip>> listener) {
        CoreController.getInstance().getTrips(context, listener);
    }

    public void getPendingPayments(@NonNull ContextWrapper context, @NonNull RequestListener<List<PendingPayment>> listener) {
        CoreController.getInstance().getPendingPayments(context, listener);
    }

    public void getTokenCardPayments(@NonNull ContextWrapper context, @NonNull RequestListener<List<TokenCardPayment>> listener) {
        CoreController.getInstance().getTokenCardPayments(context, listener);
    }

    public void getUser(@NonNull ContextWrapper context, @NonNull RequestListener<com.did.gatransport.model.User> listener) {
        CoreController.getInstance().getUser(context, listener);
    }

    public void getPendingRechargeConfirm(@NonNull final ContextWrapper context, @NonNull final RequestListener<PendingRechargeConfirm> listener) {
        CoreController.getInstance().getPendingRechargeConfirm(context, listener);
    }

    public void doEnroll(@NonNull ContextWrapper context, @NonNull EnrollRequest request, @NonNull RequestListener<Void> listener) {
        CoreController.getInstance().doEnroll(context, request, listener);
    }

    public void doEnrollLockCard(@NonNull ContextWrapper context, @NonNull EnrollLockCardRequest request, @NonNull RequestListener<Void> listener) {
        CoreController.getInstance().doEnrollLockCard(context, request, listener);
    }

    public void doFinishEnroll(@NonNull ContextWrapper context, @NonNull FinishEnrollRequest request, @NonNull RequestListener<Void> listener) {
        CoreController.getInstance().doFinishEnroll(context, request, listener);
    }

    public void getProfileUpdates(@NonNull ContextWrapper context, @NonNull RequestListener<List<ProfileUpdate>> listener) {
        CoreController.getInstance().getProfileUpdates(context, listener);
    }

    public void doProfileUpdate(@NonNull ContextWrapper context, @NonNull ProfileUpdateRequest request, @NonNull RequestListener<Void> listener) {
        CoreController.getInstance().doProfileUpdate(context, request, listener);
    }

    public void isSecure(@NonNull ContextWrapper context, @NonNull SecurityCheckRequest request, @NonNull RequestListener<SecurityCheck> listener) {
        CoreController.getInstance().isSecure(context, request, listener);
    }

    public void doPendingRecharge(@NonNull ContextWrapper context, @NonNull PendingRechargeRequest request, @NonNull RequestListener<Void> listener) {
        CoreController.getInstance().doPendingRecharge(context, request, listener);
    }

    public void doLogin(@NonNull ContextWrapper context, @NonNull LoginRequest request, RequestListener<Void> listener) {
        CoreController.getInstance().doLogin(context, request, listener);
    }

    public Error doLogout(@NonNull ContextWrapper context) {
        return CoreController.getInstance().doLogout(context);
    }

    public void doManageCard(@NonNull ContextWrapper context, @NonNull ManageCardRequest request, @NonNull RequestListener<Void> listener) {
        CoreController.getInstance().doManageCard(context, request, listener);
    }

    public void doRegisterPushChannel(@NonNull ContextWrapper context, @NonNull RegisterPushChannelRequest request, @NonNull RequestListener<Void> listener) {
        CoreController.getInstance().doRegisterPushChannel(context, request, listener);
    }
}
