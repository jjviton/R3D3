package com.did.gacard.core.files.model;

import com.did.gacard.ecard.util.ByteArray;

public final class StructEvent {

    private static final int OFFSET_VERSION_DIRECTION_TRANSACTION = 0;
    private static final int LENGTH_VERSION_DIRECTION_TRANSACTION = 1;
    private static final int OFFSET_OPERATOR = OFFSET_VERSION_DIRECTION_TRANSACTION + LENGTH_VERSION_DIRECTION_TRANSACTION;
    private static final int LENGTH_OPERATOR = 1;
    private static final int OFFSET_TITLE = OFFSET_OPERATOR + LENGTH_OPERATOR;
    private static final int LENGTH_TITLE = 1;
    private static final int OFFSET_LINE = OFFSET_TITLE + LENGTH_TITLE;
    private static final int LENGTH_LINE = 2;
    private static final int OFFSET_MANAGER = OFFSET_LINE + LENGTH_LINE;
    private static final int LENGTH_MANAGER = 2;
    private static final int OFFSET_DATE = OFFSET_MANAGER + LENGTH_MANAGER;
    private static final int LENGTH_DATE = 2;
    private static final int OFFSET_TIME = OFFSET_DATE + LENGTH_DATE;
    private static final int LENGTH_TIME = 2;
    private static final int OFFSET_TRIPS_BONUSTRIPS = OFFSET_TIME + LENGTH_TIME;
    private static final int LENGTH_TRIPS_BONUSTRIPS = 2;
    private static final int OFFSET_CURRENCY_FLATRATE_AREA = OFFSET_TRIPS_BONUSTRIPS + LENGTH_TRIPS_BONUSTRIPS;
    private static final int LENGTH_CURRENCY_FLATRATE_AREA = 1;
    private static final int OFFSET_ORIGIN = OFFSET_CURRENCY_FLATRATE_AREA + LENGTH_CURRENCY_FLATRATE_AREA;
    private static final int LENGTH_ORIGIN = 2;
    private static final int OFFSET_DESTINATION = OFFSET_ORIGIN + LENGTH_ORIGIN;
    private static final int LENGTH_DESTINATION = 2;
    private static final int OFFSET_ORIGTOWNHALL_DESTTOWNHALL = OFFSET_DESTINATION + LENGTH_DESTINATION;
    private static final int LENGTH_ORIGTOWNHALL_DESTTOWNHALL = 3;

    private static final int LENGTH = OFFSET_ORIGTOWNHALL_DESTTOWNHALL + LENGTH_ORIGTOWNHALL_DESTTOWNHALL;

    private byte[] data;

    public StructEvent() {
        this.data = new byte[LENGTH];
    }

    public StructEvent(byte[] data) throws Exception {
        if (data == null) throw new Exception("StructEvent: Cannot be NULL.");
        if (data.length != LENGTH) throw new Exception("StructEvent:Invalid length.");
        this.data = ByteArray.copyOf(data);
    }

    public byte[] getData() {
        return data;
    }

    private byte getVersionDirectionTransaction() {
        return ByteArray.getBytes(data, OFFSET_VERSION_DIRECTION_TRANSACTION, LENGTH_VERSION_DIRECTION_TRANSACTION)[0];
    }

    public byte getVersion() {
        return (byte) ((getVersionDirectionTransaction() & 0xF0) >> 4);
    }

    public byte getDirection() {
        return (byte) ((getVersionDirectionTransaction() & 0x08) >> 3);
    }

    public byte getTransaction() {
        return (byte) (getVersionDirectionTransaction() & 0x07);
    }

    public byte[] getOperator() {
        return ByteArray.getBytes(data, OFFSET_OPERATOR, LENGTH_OPERATOR);
    }

    public byte[] getTitle() {
        return ByteArray.getBytes(data, OFFSET_TITLE, LENGTH_TITLE);
    }

    public byte[] getLine() {
        return ByteArray.getBytes(data, OFFSET_LINE, LENGTH_LINE);
    }

    public byte[] getManager() {
        return ByteArray.getBytes(data, OFFSET_MANAGER, LENGTH_MANAGER);
    }

    public byte[] getDate() {
        return ByteArray.getBytes(data, OFFSET_DATE, LENGTH_DATE);
    }

    public byte[] getTime() {
        return ByteArray.getBytes(data, OFFSET_TIME, LENGTH_TIME);
    }

    private byte[] getTripsBonusTrips() {
        return ByteArray.getBytes(data, OFFSET_TRIPS_BONUSTRIPS, LENGTH_TRIPS_BONUSTRIPS);
    }

    public byte getTrips() {
        return (byte) ((getTripsBonusTrips()[0] & 0xF0) >> 4);
    }

    public byte[] getBonusTrips() {
        return new byte[]{(byte) (getTripsBonusTrips()[0] & 0x0F), getTripsBonusTrips()[1]};
    }

    private byte getCurrencyFlatRateArea() {
        return ByteArray.getBytes(data, OFFSET_CURRENCY_FLATRATE_AREA, LENGTH_CURRENCY_FLATRATE_AREA)[0];
    }

    public byte getCurrency() {
        return (byte) ((getCurrencyFlatRateArea() & 0xC0) >> 6);
    }

    public byte getFlatRate() {
        return (byte) ((getCurrencyFlatRateArea() & 0x20) >> 5);
    }

    public byte getArea() {
        return (byte) (getCurrencyFlatRateArea() & 0x1F);
    }

    public byte[] getOrigin() {
        return ByteArray.getBytes(data, OFFSET_ORIGIN, LENGTH_ORIGIN);
    }

    public byte[] getDestination() {
        return ByteArray.getBytes(data, OFFSET_DESTINATION, LENGTH_DESTINATION);
    }

    private byte[] getOrigTownHallDestTownHall() {
        return ByteArray.getBytes(data, OFFSET_ORIGTOWNHALL_DESTTOWNHALL, LENGTH_ORIGTOWNHALL_DESTTOWNHALL);
    }

    public byte[] getOriginTownHall() {
        return new byte[]{(byte) ((getOrigTownHallDestTownHall()[0] & 0xF0) >> 4), (byte) (((getOrigTownHallDestTownHall()[0] & 0x0F) << 4) | ((getOrigTownHallDestTownHall()[1] & 0xF0) >> 4))};
    }

    public byte[] getDestinationTownHall() {
        return new byte[]{(byte) (getOrigTownHallDestTownHall()[1] & 0x0F), getOrigTownHallDestTownHall()[2]};
    }
}
