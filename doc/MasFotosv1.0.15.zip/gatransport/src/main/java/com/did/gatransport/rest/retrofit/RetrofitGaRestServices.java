package com.did.gatransport.rest.retrofit;

import com.did.gatransport.rest.model.response.BalanceResponse;
import com.did.gatransport.rest.model.response.BaseResponse;
import com.did.gatransport.rest.model.response.EnrollResponse;
import com.did.gatransport.rest.model.response.FinishEnrollResponse;
import com.did.gatransport.rest.model.response.GenericResponse;
import com.did.gatransport.rest.model.response.LoginResponse;
import com.did.gatransport.rest.model.response.PendingPaymentResponse;
import com.did.gatransport.rest.model.response.ProfileUpdateListResponse;
import com.did.gatransport.rest.model.response.ProfileUpdateResponse;
import com.did.gatransport.rest.model.response.RechargeResponse;
import com.did.gatransport.rest.model.response.TokenCardResponse;
import com.did.gatransport.rest.retrofit.request.BalanceRequest;
import com.did.gatransport.rest.retrofit.request.CheckProfileUpdateRequest;
import com.did.gatransport.rest.retrofit.request.ConfirmEnrollRequest;
import com.did.gatransport.rest.retrofit.request.ConfirmProfileUpdateRequest;
import com.did.gatransport.rest.retrofit.request.EnrollManageRequest;
import com.did.gatransport.rest.retrofit.request.EnrollRequest;
import com.did.gatransport.rest.retrofit.request.FinishEnrollRequest;
import com.did.gatransport.rest.retrofit.request.LoginRequest;
import com.did.gatransport.rest.retrofit.request.ManageRequest;
import com.did.gatransport.rest.retrofit.request.PendingPaymentRequest;
import com.did.gatransport.rest.retrofit.request.ProfileUpdateRequest;
import com.did.gatransport.rest.retrofit.request.RechargeRequest;
import com.did.gatransport.rest.retrofit.request.RegisterPushChannelRequest;
import com.did.gatransport.rest.retrofit.request.Request;
import com.did.gatransport.rest.retrofit.request.TokenCardRequest;
import com.did.gatransport.rest.retrofit.request.TransactionRequest;

import retrofit2.Call;
import retrofit2.http.Body;
import retrofit2.http.Header;
import retrofit2.http.POST;

interface RetrofitGaRestServices {

    @POST("recordm/security/auth")
    Call<LoginResponse> performLogin(
            @Header("Cookie") String cookie,
            @Body LoginRequest body);

    @POST("integrationm/action/AbancaEnrollment")
    Call<EnrollResponse> performEnroll(
            @Header("Cookie") String cookie,
            @Body Request<EnrollRequest> body);

    @POST("integrationm/action/AbancaEnrollment")
    Call<FinishEnrollResponse> finishEnroll(
            @Header("Cookie") String cookie,
            @Body Request<FinishEnrollRequest> body);

    @POST("integrationm/action/AbancaEnrollment")
    Call<BaseResponse> confirmEnrollment(
            @Header("Cookie") String cookie,
            @Body Request<ConfirmEnrollRequest> body);

    @POST("integrationm/action/AbancaEnrollment")
    Call<BaseResponse> enrollManageCard(
            @Header("Cookie") String cookie,
            @Body Request<EnrollManageRequest> body);

    @POST("integrationm/action/CardOps")
    Call<ProfileUpdateListResponse> performProfileCheck(
            @Header("Cookie") String cookie,
            @Body Request<CheckProfileUpdateRequest> body);

    @POST("integrationm/action/CardOps")
    Call<ProfileUpdateResponse> performProfileUpdate(
            @Header("Cookie") String cookie,
            @Body Request<ProfileUpdateRequest> body);

    @POST("integrationm/action/CardOps")
    Call<BaseResponse> confirmProfileUpdate(
            @Header("Cookie") String cookie,
            @Body Request<ConfirmProfileUpdateRequest> body);

    @POST("integrationm/action/CardOps")
    Call<RechargeResponse> performCardRecharge(
            @Header("Cookie") String cookie,
            @Body Request<RechargeRequest> body);

    @POST("integrationm/msgs")
    Call<Void> performTokenCardFinishRecharge(
            @Header("Cookie") String cookie,
            @Body Request<RechargeRequest> body);

    @POST("integrationm/action/CardOps")
    Call<RechargeResponse> performPendingRecharge(
            @Header("Cookie") String cookie,
            @Body Request<RechargeRequest> body);

    @POST("integrationm/action/CardOps")
    Call<PendingPaymentResponse> getPendingPayments(
            @Header("Cookie") String cookie,
            @Body Request<PendingPaymentRequest> body);

    @POST("integrationm/action/CardOps")
    Call<TokenCardResponse> getTokenCards(
            @Header("Cookie") String cookie,
            @Body Request<TokenCardRequest> body);

    @POST("integrationm/action/CardOps")
    Call<BalanceResponse> getBalance(
            @Header("Cookie") String cookie,
            @Body Request<BalanceRequest> body);

    @POST("integrationm/action/CardOps")
    Call<GenericResponse> sendTransactions(
            @Header("Cookie") String cookie,
            @Body Request<TransactionRequest> body);

    @POST("integrationm/action/CardOps")
    Call<BaseResponse> manageCard(
            @Header("Cookie") String cookie,
            @Body Request<ManageRequest> body);

    @POST("integrationm/action/CardOps")
    Call<BaseResponse> registerPushChannel(
            @Header("Cookie") String cookie,
            @Body Request<RegisterPushChannelRequest> body);

    // TODO ONLY FOR DEBUG
//    @POST("integrationm/action/CardOps")
//    Call<FakeRechargeResponse> doFakeRecharge(
//            @Header("Cookie") String cookie,
//            @Body Request<FakeRechargeRequest> body);
}
