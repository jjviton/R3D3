package com.did.gatransport.interfaces;

import android.content.ContextWrapper;

import com.did.gatransport.controller.SyncController;
import com.did.gatransport.model.Error;
import com.did.gatransport.rest.GaRestController;
import com.did.gatransport.store.GaStoreManager;
import com.did.gatransport.util.ErrorFactory;
import com.did.security.core.SecurityHelper;

public final class CardHostErrorChainRequestListener<T> extends ChainRequestListener<T> {

    private ContextWrapper mContext;
    private GaStoreManager storeManager;
    private GaRestController restController;
    private SecurityHelper securityHelper;

    public CardHostErrorChainRequestListener(ContextWrapper context, GaStoreManager storeManager, GaRestController restController, SecurityHelper securityHelper, RequestListener<T> listener) {
        super(listener);
        this.mContext = context;
        this.storeManager = storeManager;
        this.restController = restController;
        this.securityHelper = securityHelper;
    }

    @Override
    public void onSuccess(RequestListener<T> interceptedListener, T response) {
        if (interceptedListener != null) interceptedListener.onSuccess(response);
    }

    @Override
    public void onFailure(final RequestListener<T> nextListener, final Error prevError) {
        if (ErrorFactory.isCardLockedUnsubscribedError(prevError)) {
            SyncController.sync(mContext, storeManager, restController, securityHelper, new RequestListener<Void>() {
                @Override
                public void onSuccess(Void response) {
                    if (nextListener != null) nextListener.onFailure(prevError);
                }

                @Override
                public void onFailure(Error error) {
                    if (nextListener != null) nextListener.onFailure(error);
                }
            }, prevError);
        } else {
            if (nextListener != null) nextListener.onFailure(prevError);
        }
    }

}
