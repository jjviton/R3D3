package com.did.gatransport.store.realm.model;

import com.did.gatransport.store.model.Trip;

import io.realm.RealmObject;

public class TripRealm extends RealmObject implements Trip {

    private String line;
    private int amount;
    private long date;
    private String type;

    @Override
    public void setLine(String line) {
        this.line = line;
    }

    @Override
    public String getLine() {
        return this.line;
    }

    @Override
    public void setAmount(int amount) {
        this.amount = amount;
    }

    @Override
    public int getAmount() {
        return this.amount;
    }

    @Override
    public void setDate(long date) {
        this.date = date;
    }

    @Override
    public long getDate() {
        return this.date;
    }

    @Override
    public String getType() {
        return type;
    }

    @Override
    public void setType(String type) {
        this.type = type;
    }
}
