package com.did.gatransport.model;

import android.support.annotation.IntRange;

import com.did.security.core.SecurityHelper;

import java.security.InvalidParameterException;

public final class SecurityCheck {
    public static final int OK = SecurityHelper.OK;
    public static final int IS_ROOT = SecurityHelper.IS_ROOT;
    public static final int DEVICE_NOT_ENCRYPTED = SecurityHelper.DEVICE_NOT_ENCRYPTED;
    public static final int WITHOUT_LOCK = SecurityHelper.WITHOUT_LOCK;
    public static final int SIGN_NOT_VALID = SecurityHelper.SIGN_NOT_VALID;

    private int code;

    public SecurityCheck() {
    }

    public SecurityCheck(@IntRange(from = OK, to = SIGN_NOT_VALID) int code) {
        if (code < OK || code > SIGN_NOT_VALID)
            throw new InvalidParameterException();
        this.code = code;
    }

    public int getCode() {
        return code;
    }

    public void setCode(@IntRange(from = OK, to = SIGN_NOT_VALID) int code) {
        if (code < OK || code > SIGN_NOT_VALID)
            throw new InvalidParameterException();
        this.code = code;
    }
}
