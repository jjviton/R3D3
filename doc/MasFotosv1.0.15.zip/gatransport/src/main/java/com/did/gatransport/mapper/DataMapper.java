package com.did.gatransport.mapper;

public interface DataMapper {

    void uiToStore();

    void storeToUi();

    void restToStore();

    void storeToRest();

    void uiToRest();

    void restToUi();

}
