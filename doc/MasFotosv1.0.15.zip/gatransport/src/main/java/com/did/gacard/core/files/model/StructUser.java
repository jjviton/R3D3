package com.did.gacard.core.files.model;

import com.did.gacard.ecard.util.ByteArray;

public final class StructUser {

    private static final int OFFSET_PROFILE = 0;
    private static final int LENGTH_PROFILE = 1;
    private static final int OFFSET_PROFILE_INITIALIZATION = OFFSET_PROFILE + LENGTH_PROFILE;
    private static final int LENGTH_PROFILE_INITIALIZATION = 2;
    private static final int OFFSET_PROFILE_EXPIRATION = OFFSET_PROFILE_INITIALIZATION + LENGTH_PROFILE_INITIALIZATION;
    private static final int LENGTH_PROFILE_EXPIRATION = 2;
    private static final int OFFSET_ISSUINGTOWNHALL_GROUPCODE_RFU = OFFSET_PROFILE_EXPIRATION + LENGTH_PROFILE_EXPIRATION;
    private static final int LENGTH_ISSUINGTOWNHALL_GROUPCODE_RFU = 7;

    private static final int LENGTH = OFFSET_ISSUINGTOWNHALL_GROUPCODE_RFU + LENGTH_ISSUINGTOWNHALL_GROUPCODE_RFU;

    private byte[] data;

    public StructUser() {
        this.data = new byte[LENGTH];
    }

    public StructUser(byte[] data) throws Exception {
        if (data == null) throw new Exception("StructUser: Cannot be NULL.");
        if (data.length != LENGTH) throw new Exception("StructUser: Invalid length.");
        this.data = data;
    }

    public byte[] getData() {
        return data;
    }

    public byte getProfile() {
        return ByteArray.getBytes(data, OFFSET_PROFILE, LENGTH_PROFILE)[0];
    }

    public void setProfile(byte profile) {
//            throws Exception {
//        if (lastUpdate == null) throw new Exception("Profile: Cannot be NULL.");
//        if (lastUpdate.length != LENGTH_PROFILE)
//            throw new Exception("Profile: Invalid length.");
        ByteArray.fillBytes(data, OFFSET_PROFILE, new byte[]{profile});
    }

    public byte[] getProfileInitialization() {
        return ByteArray.getBytes(data, OFFSET_PROFILE_INITIALIZATION, LENGTH_PROFILE_INITIALIZATION);
    }

    public void setProfileInitialization(byte[] profileInitialization) throws Exception {
        if (profileInitialization == null)
            throw new Exception("ProfileInitialization: Cannot be NULL.");
        if (profileInitialization.length != LENGTH_PROFILE_INITIALIZATION)
            throw new Exception("ProfileInitialization: Invalid length.");
        ByteArray.fillBytes(data, OFFSET_PROFILE_INITIALIZATION, profileInitialization);
    }

    public byte[] getProfileExpiration() {
        return ByteArray.getBytes(data, OFFSET_PROFILE_EXPIRATION, LENGTH_PROFILE_EXPIRATION);
    }

    public void setProfileExpiration(byte[] profileExpiration) throws Exception {
        if (profileExpiration == null)
            throw new Exception("ProfileExpiration: Cannot be NULL.");
        if (profileExpiration.length != LENGTH_PROFILE_EXPIRATION)
            throw new Exception("ProfileExpiration: Invalid length.");
        ByteArray.fillBytes(data, OFFSET_PROFILE_EXPIRATION, profileExpiration);
    }

    private byte[] getIssuingTownHallGroupCodeRfu() {
        return ByteArray.getBytes(data, OFFSET_ISSUINGTOWNHALL_GROUPCODE_RFU, LENGTH_ISSUINGTOWNHALL_GROUPCODE_RFU);
    }

    public byte getIssuingTownHall() { // 6bits
        return (byte) ((getIssuingTownHallGroupCodeRfu()[0] & 0xFC) >> 2);
    }

    public byte getGroupCode() { // 8bits
        return (byte) (((getIssuingTownHallGroupCodeRfu()[0] & 0x03) << 6) | (getIssuingTownHallGroupCodeRfu()[1] & 0x3F));
    }

    public void setGroupCode(byte groupCode) { // 8bits
        // 1º Preparar byte 0 para mantener el primer dato Issuing TownHall y resetear los 2 bits menos significativos a 0
        byte b0 = getIssuingTownHallGroupCodeRfu()[0];
        b0 = (byte) (b0 & 0xFC);
        // 3º Sumar el byte reseteado con el byte entrante con máscara de 2 bits más significativos y desplazado a la derecha 6
        b0 = (byte) (b0 | ((groupCode & 0xC0) >> 6));
        // 4º Preparar byte 1 para mantener el tercer dato rfu y resetear los 6 bits más significativos a 0
        byte b1 = getIssuingTownHallGroupCodeRfu()[1];
        b1 = (byte) (b1 & 0x03);
        // 4º Sumar el byte reseteado con el byte entrante con máscara de 6 bits menos significativos y desplazado a la izq 2
        b1 = (byte) (b1 | ((groupCode & 0x3F) << 2));

        ByteArray.fillBytes(data, OFFSET_ISSUINGTOWNHALL_GROUPCODE_RFU, new byte[]{b0, b1});
    }

}
