package com.did.gatransport.model.request;

public final class EnrollLockCardRequest {

    private String pan;

    public EnrollLockCardRequest() {
    }

    public EnrollLockCardRequest(String pan) {
        this.pan = pan;
    }

    public String getPan() {
        return pan;
    }

    public void setPan(String pan) {
        this.pan = pan;
    }
}
