package com.did.gatransport.model;

public final class ProfileUpdate {
    private String type;

    private String currentProfile;
    private String currentProfileExpiration;
    private String currentProfileDescription;
    private String timestamp;

    private String newProfile;
    private String newProfileInitialization;
    private String newProfileExpiration;
    private String newProfileDescription;

    public ProfileUpdate() {
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public String getCurrentProfile() {
        return currentProfile;
    }

    public void setCurrentProfile(String currentProfile) {
        this.currentProfile = currentProfile;
    }

    public String getCurrentProfileExpiration() {
        return currentProfileExpiration;
    }

    public void setCurrentProfileExpiration(String currentProfileExpiration) {
        this.currentProfileExpiration = currentProfileExpiration;
    }

    public String getCurrentProfileDescription() {
        return currentProfileDescription;
    }

    public void setCurrentProfileDescription(String currentProfileDescription) {
        this.currentProfileDescription = currentProfileDescription;
    }

    public String getTimestamp() {
        return timestamp;
    }

    public void setTimestamp(String timestamp) {
        this.timestamp = timestamp;
    }

    public String getNewProfile() {
        return newProfile;
    }

    public void setNewProfile(String newProfile) {
        this.newProfile = newProfile;
    }

    public String getNewProfileInitialization() {
        return newProfileInitialization;
    }

    public void setNewProfileInitialization(String newProfileInitialization) {
        this.newProfileInitialization = newProfileInitialization;
    }

    public String getNewProfileExpiration() {
        return newProfileExpiration;
    }

    public void setNewProfileExpiration(String newProfileExpiration) {
        this.newProfileExpiration = newProfileExpiration;
    }

    public String getNewProfileDescription() {
        return newProfileDescription;
    }

    public void setNewProfileDescription(String newProfileDescription) {
        this.newProfileDescription = newProfileDescription;
    }
}
