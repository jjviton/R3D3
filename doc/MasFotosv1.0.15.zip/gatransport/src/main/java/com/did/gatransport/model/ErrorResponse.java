package com.did.gatransport.model;

public final class ErrorResponse<T> extends Error {

    private T response;

    public ErrorResponse() {
    }

    public ErrorResponse(int level, int code, String msg, Throwable exception, long time, T response) {
        super(level, code, msg, exception, time);
        this.response = response;
    }

    public ErrorResponse(int level, int code, String msg, Throwable exception, long time) {
        this(level, code, msg, exception, time, null);
    }

    public ErrorResponse(Error error) {
        if (error != null) {
            setLevel(error.getLevel());
            setCode(error.getCode());
            setMsg(error.getMsg());
            setException(error.getException());
            setTime(error.getTime());
            setPreviousError(error.getPreviousError());
        }
    }

    public ErrorResponse(Error error, T response) {
        this(error);
        this.response = response;
    }

    public T getResponse() {
        return response;
    }

    public void setResponse(T response) {
        this.response = response;
    }

    public Error getError() {
        Error error = new Error();
        error.setLevel(getLevel());
        error.setCode(getCode());
        error.setMsg(getMsg());
        error.setException(getException());
        error.setTime(getTime());
        error.setPreviousError(getPreviousError());
        return error;
    }
}
