package com.did.gacard.core.protocol;

import java.util.Random;

public interface GaSecurityElement {

    byte[] getRandom(int size);

    void check(byte[] arr);

    GaSecurityElement DEFAULT = new GaSecurityElement() {
        @Override
        public byte[] getRandom(int size) {
            byte[] rand = new byte[size];
            new Random().nextBytes(rand);

            return rand;
        }

        @Override
        public void check(byte[] arr) {
            // Nothing
        }
    };
}
