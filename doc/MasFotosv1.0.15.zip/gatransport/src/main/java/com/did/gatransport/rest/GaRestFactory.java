package com.did.gatransport.rest;

import android.content.ContextWrapper;
import android.content.res.XmlResourceParser;
import android.support.annotation.NonNull;

import com.did.gatransport.controller.CoreController;
import com.did.gatransport.rest.retrofit.RetrofitGaRestController;

import org.xmlpull.v1.XmlPullParser;

import java.net.URL;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;

import javax.net.ssl.SSLSocketFactory;
import javax.net.ssl.X509TrustManager;

import okhttp3.CertificatePinner;

public final class GaRestFactory {

    private static final String TAG_DOMAIN_CONFIG = "domain-config";
    private static final String TAG_DOMAIN = "domain";
    private static final String TAG_PIN_SET = "pin-set";
    private static final String TAG_PIN = "pin";

    private static Map<String, List<String>> getNetworkSecurityConfiguration(@NonNull ContextWrapper contextWrapper, int networkSecurityConfigurationResourceId) {
        Map<String, List<String>> nscMap = new HashMap<>();
        try {
            XmlResourceParser xpp = contextWrapper.getResources().getXml(networkSecurityConfigurationResourceId);
            if (xpp == null)
                return nscMap;
            String domain = null;
            String pinType = null;
            List<String> pins = null;
            boolean getDomain = false;
            boolean getPin = false;
            int eventType;
            do {
                eventType = xpp.next();
                switch (eventType) {
                    case XmlPullParser.START_DOCUMENT:
                        // Nothing
                        break;
                    case XmlPullParser.END_DOCUMENT:
                        // Nothing
                        break;
                    case XmlPullParser.START_TAG:
                        switch (xpp.getName()) {
                            case TAG_DOMAIN_CONFIG:
                                getDomain = false;
                                getPin = false;
                                domain = null;
                                pinType = null;
                                pins = null;
                                break;
                            case TAG_DOMAIN:
                                getDomain = true;
                                break;
                            case TAG_PIN_SET:
                                pins = new LinkedList<>();
                                break;
                            case TAG_PIN:
                                getPin = true;
                                pinType = xpp.getAttributeValue(null, "digest");
                                if (pinType != null && !pinType.isEmpty()) {
                                    pinType = pinType.toLowerCase().replace("-", "");
                                }
                                break;
                        }
                        break;
                    case XmlPullParser.END_TAG:
                        switch (xpp.getName()) {
                            case TAG_DOMAIN_CONFIG:
                                if (domain != null)
                                    nscMap.put(domain, pins != null ? pins : new ArrayList<String>());
                                break;
                            case TAG_DOMAIN:
                                getDomain = false;
                                break;
                            case TAG_PIN_SET:
                                // Nothing
                                break;
                            case TAG_PIN:
                                // Nothing
                                getPin = false;
                                break;
                        }
                        break;
                    case XmlPullParser.TEXT:
                        String value = xpp.getText();
                        if (getDomain) {
                            domain = value;
                        } else if (getPin) {
                            if (pins != null && pinType != null) {
                                pins.add(pinType.concat("/").concat(value));
                            }
                        }
                        break;
                }
            } while (eventType != XmlPullParser.END_DOCUMENT);
        } catch (Throwable t) {
            CoreController.getLogger().logError("GaRestFactory::getNetworkSecurityConfiguration", "Error reading Network Security Configuration from XML Resource.", t);
        }

        return nscMap;
    }

    private static List<String> getHostPinCertificates(@NonNull ContextWrapper contextWrapper, @NonNull String hostName, int networkSecurityConfigurationResourceId) {
        if (hostName == null || hostName.isEmpty()) return new ArrayList<>();
        Map<String, List<String>> nscMap = getNetworkSecurityConfiguration(contextWrapper, networkSecurityConfigurationResourceId);
        if (nscMap == null || nscMap.isEmpty() || nscMap.get(hostName) == null)
            return new ArrayList<>();
        return nscMap.get(hostName);
    }

    private static CertificatePinner getCertificatePinner(@NonNull ContextWrapper contextWrapper, @NonNull String hostname, int networkSecurityConfigurationResourceId) {
        CertificatePinner.Builder certificatePinnerBuilder = new CertificatePinner.Builder();
        try {
            List<String> hostPinCertificates = getHostPinCertificates(contextWrapper, hostname, networkSecurityConfigurationResourceId);
            for (String pin : hostPinCertificates) {
                certificatePinnerBuilder.add(hostname, pin);
            }
        } catch (Throwable t) {
            CoreController.getLogger().logError("GaRestFactory::getCertificatePinner", "Error getting Certificate Pinner for host: " + hostname + ".", t);
        }
        return certificatePinnerBuilder.build();
    }

    public static GaRestController getRetrofitGaRestControllerWithSSLPinner(@NonNull ContextWrapper context, @NonNull URL hostUrl, int networkSecurityConfigurationResourceId) {
        return new RetrofitGaRestController(hostUrl, getCertificatePinner(context, hostUrl.getHost(), networkSecurityConfigurationResourceId));
    }

    public static GaRestController getRetrofitGaRestControllerWithSSLPinner(@NonNull URL hostUrl, @NonNull SSLSocketFactory sslSocketFactory, @NonNull X509TrustManager trustManager) {
        return new RetrofitGaRestController(hostUrl, sslSocketFactory, trustManager);
    }

    public static GaRestController getRetrofitGaRestController(@NonNull URL hostUrl) {
        return new RetrofitGaRestController(hostUrl);
    }

}
