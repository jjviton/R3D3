package com.did.gatransport.store;

import com.did.gatransport.interfaces.RequestListener;
import com.did.gatransport.model.Error;
import com.did.gatransport.store.model.GaCard;
import com.did.gatransport.store.model.ProfileUpdateConfirmRequest;
import com.did.gatransport.store.model.RechargeConfirmRequest;
import com.did.gatransport.store.model.Transaction;
import com.did.gatransport.store.model.User;

import java.util.List;

public interface GaStoreManager {
    int TABLE_USER = 1;
    int TABLE_CARD = 2;
    int TABLE_TRANSACTIONS = 3;
    int TABLE_TRIP = 4;
    int TABLE_RECHARGE = 5;
    int TABLE_RECHARGE_CONFIRM = 6;
    @Deprecated
    int TABLE_ENROLL_CONFIRM = 7;
    int TABLE_UPDATE_PROFILE_CONFIRM = 8;

    int MAX_TRANSACTION_NOSYNC = 5;

    String getPath();

    Error open();

    void close();

    void reset();

    void insert(Object obj, RequestListener<Void> listener);

    void deleteAll(int tableId, RequestListener<Void> listener);

    void getAll(int tableId, RequestListener<List<Object>> listener);

    void deleteSentTransactions(RequestListener<Void> listener);

    void getPendingTransactions(RequestListener<List<Transaction>> listener);

    void hasPendingTransactions(RequestListener<Boolean> listener);

    void updateTransactionToSent(int lastNtSynchronized, RequestListener<Void> listener);

    @Deprecated
    void updateTransactionToSent(final List<Transaction> list, RequestListener<Void> listener);

    void getLastTransaction(RequestListener<Transaction> listener);

    void getUser(RequestListener<User> listener);

    void updateUserToken(String token, RequestListener<Void> listener);

    void updateUserProfile(String profileType, String profileExpiration, RequestListener<Void> listener);

    void getGaCard(RequestListener<GaCard> listener);

    void getRechargeConfirmRequest(RequestListener<RechargeConfirmRequest> listener);

    void updateRechargeConfirmRequest(String status, RequestListener<Void> listener);

    void updateRechargeConfirmRequestId(String refId, RequestListener<RechargeConfirmRequest> listener);

    void getProfileUpdateConfirmRequest(RequestListener<ProfileUpdateConfirmRequest> listener);

    boolean checkGaCard();

    boolean checkPendingTransactions();

    boolean checkMaxPendingTransactionsReached();

    boolean checkPendingRechargeConfirmRequest();

    boolean checkPendingProfileUpdateConfirmRequest();

    void refreshKey(RequestListener<Void> listener);
}
