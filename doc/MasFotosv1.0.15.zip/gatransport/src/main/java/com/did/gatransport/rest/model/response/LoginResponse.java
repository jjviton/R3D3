package com.did.gatransport.rest.model.response;

import com.google.gson.annotations.SerializedName;

public final class LoginResponse extends BaseResponse {

    @SerializedName("securityToken")
    private String token;

    public LoginResponse() {

    }

    public String getToken() {
        return token;
    }

    public void setToken(String token) {
        this.token = token;
    }
}
