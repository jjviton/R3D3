package com.did.gatransport.store.realm.model;

import com.did.gatransport.store.model.GaCard;

import io.realm.RealmObject;
import io.realm.annotations.PrimaryKey;

public class GaCardRealm extends RealmObject implements GaCard {

    @PrimaryKey
    private long id;

    private String file;

    public GaCardRealm() {
    }

    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    @Override
    public void setFile(String file) {
        this.file = file;
    }

    @Override
    public String getFile() {
        return file;
    }
}
