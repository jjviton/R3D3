package com.did.gatransport.rest.model;

import com.google.gson.annotations.SerializedName;

public final class TransactionLine {

    public static final String TYPE_DEBIT = "C";
    public static final String TYPE_CANCEL = "A";

    @SerializedName("NT")
    private String nt;
    @SerializedName("Balance")
    private String balance;
    @SerializedName("Amount")
    private String amount;
    @SerializedName("Date")
    private String date;
    @SerializedName("Type")
    private String type;

    public TransactionLine() {
    }

    public String getNt() {
        return nt;
    }

    public void setNt(String nt) {
        this.nt = nt;
    }

    public String getBalance() {
        return balance;
    }

    public void setBalance(String balance) {
        this.balance = balance;
    }

    public String getAmount() {
        return amount;
    }

    public void setAmount(String amount) {
        this.amount = amount;
    }

    public String getDate() {
        return date;
    }

    public void setDate(String date) {
        this.date = date;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }
}
