package com.did.gacard.core.files.model;

public final class StructEnvironment {

    private static final int OFFSET_APP_VERSION = 0; // bits
    private static final int LENGTH_APP_VERSION = 6; // bits
    private static final int OFFSET_BITMAP = OFFSET_APP_VERSION + LENGTH_APP_VERSION; // bits
    private static final int LENGTH_BITMAP = 6; // bits
    private static final int OFFSET_NETWORK = OFFSET_BITMAP + LENGTH_BITMAP; // bits
    private static final int LENGTH_NETWORK = 24; // bits
    private static final int OFFSET_APP_ENVIRONMENT = OFFSET_NETWORK + LENGTH_NETWORK; // bits
    private static final int LENGTH_APP_ENVIRONMENT = 8; // bits
    private static final int OFFSET_PAY_METHOD = OFFSET_APP_ENVIRONMENT + LENGTH_APP_ENVIRONMENT; // bits
    private static final int LENGTH_PAY_METHOD = 4; // bits
    private static final int OFFSET_RFU = OFFSET_PAY_METHOD + LENGTH_PAY_METHOD; // bits
    private static final int LENGTH_RFU = 24; // bits

    private static final int BYTE_LENGTH = 8; // bits
    private static final int LENGTH = (OFFSET_RFU + LENGTH_RFU) / BYTE_LENGTH; // bytes

    private byte[] data;

    public StructEnvironment() {
        this.data = new byte[LENGTH];
    }

    public StructEnvironment(byte[] data) throws Exception {
        if (data == null) throw new Exception("StructEnvironment: Cannot be NULL.");
        if (data.length != LENGTH) throw new Exception("StructEnvironment: Invalid length.");
        this.data = data;
    }

    public byte[] getData() {
        return data;
    }

}
