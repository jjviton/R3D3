package com.did.gatransport.controller;

import android.Manifest;
import android.content.ContextWrapper;
import android.content.pm.PackageManager;
import android.os.Build;
import android.support.annotation.IntRange;
import android.support.annotation.NonNull;
import android.support.v4.content.ContextCompat;
import android.util.Log;

import com.did.gacard.ecard.ECard;
import com.did.gacard.GaCard;
import com.did.gacard.ecard.util.ByteArray;
import com.did.gatransport.BuildConfig;
import com.did.gatransport.R;
import com.did.gatransport.interfaces.RequestListener;
import com.did.gatransport.interfaces.SynchronizationListener;
import com.did.gatransport.interfaces.TripListener;
import com.did.gatransport.mapper.RechargeMapper;
import com.did.gatransport.mapper.TripMapper;
import com.did.gatransport.mapper.UserMapper;
import com.did.gatransport.model.Error;
import com.did.gatransport.model.PendingPayment;
import com.did.gatransport.model.PendingRechargeConfirm;
import com.did.gatransport.model.ProfileUpdate;
import com.did.gatransport.model.Recharge;
import com.did.gatransport.model.SecurityCheck;
import com.did.gatransport.model.TokenCardPayment;
import com.did.gatransport.model.Trip;
import com.did.gatransport.model.request.EnrollLockCardRequest;
import com.did.gatransport.model.request.EnrollRequest;
import com.did.gatransport.model.request.FinishEnrollRequest;
import com.did.gatransport.model.request.LoginRequest;
import com.did.gatransport.model.request.ManageCardRequest;
import com.did.gatransport.model.request.PendingRechargeRequest;
import com.did.gatransport.model.request.ProfileUpdateRequest;
import com.did.gatransport.model.request.RegisterPushChannelRequest;
import com.did.gatransport.model.request.SecurityCheckRequest;
import com.did.gatransport.rest.GaRestController;
import com.did.gatransport.rest.GaRestFactory;
import com.did.gatransport.services.GaAppletManagerFactory;
import com.did.gatransport.store.GaStoreFactory;
import com.did.gatransport.store.GaStoreManager;
import com.did.gatransport.store.model.RechargeConfirmRequest;
import com.did.gatransport.store.model.User;
import com.did.gatransport.store.realm.model.RechargeRealm;
import com.did.gatransport.store.realm.model.TripRealm;
import com.did.gatransport.store.realm.model.UserRealm;
import com.did.gatransport.util.ErrorFactory;
import com.did.gatransport.util.Logger;
import com.did.security.core.SecurityHelper;

import java.net.URL;
import java.security.InvalidParameterException;
import java.util.ArrayList;
import java.util.List;

public final class CoreController {

    private static final String DEFAULT_LANGUAGE = "ES";

    public static final int NONE = 0;
    public static final int FULL = 1;

    private final static Logger DEFAULT = new Logger() {
        private static final String TAG = "GaTransport";
        private static final String NO_DESCRIPTION = "No description";

        private int level = BuildConfig.DEBUG ? FULL : NONE;

        private String getInfoHeader() {
            return "<api" + Build.VERSION.SDK_INT + "#v" + BuildConfig.VERSION_NAME + ">";
        }

        @Override
        public void setLevel(@IntRange(from = NONE, to = FULL) int level) {
            if (level < NONE || level > FULL)
                throw new InvalidParameterException();
            this.level = level;
        }

        @Override
        public int getLevel() {
            return level;
        }

        @Override
        public void logDebug(String log) {
            if (level == FULL && BuildConfig.DEBUG)
                Log.e(TAG, getInfoHeader() + "[D] " + log);
        }

        @Override
        public void logError(String log, Throwable tr) {
            if (level == FULL && BuildConfig.DEBUG)
                Log.e(TAG, getInfoHeader() + "[E] " + log, tr);
        }

        @Override
        public void logDebug(String classFunction, String log) {
            logDebug(classFunction + " - " + log);
        }

        @Override
        public void logError(String classFunction, String log, Throwable tr) {
            logError(classFunction + " - " + log, tr);
        }

        @Override
        public void logError(String classFunction, Error error, String defaultLog) {
            logError(classFunction, getLogFromError(error, defaultLog), error == null ? null : error.getException());
            if (error != null && error.getPreviousError() != null) {
                logError(classFunction, error.getPreviousError());
            }
        }

        @Override
        public void logError(String classFunction, Error error) {
            logError(classFunction, error, null);
        }

        private String getLogFromError(Error error, String defaultLog) {
            if (defaultLog == null) defaultLog = NO_DESCRIPTION;
            if (error == null) return defaultLog;
            String log;
            log = "(" + error.getLevel() + ":" + error.getCode() + ") ";
            if (error.getMsg() != null) {
                log += error.getMsg();
            } else {
                log += defaultLog;
            }
            return log;
        }
    };

    private static CoreController instance;

    public static CoreController getInstance() {
        if (instance == null) instance = new CoreController();
        return instance;
    }

    private boolean initialized = false;

    private static TripListener tripListener;
    private static SynchronizationListener syncListener;

    private SecurityHelper securityHelper;
    private GaStoreManager storeManager;
    private GaRestController restController;

    private CoreController() {

    }

    public Error initialize(@NonNull ContextWrapper context, @NonNull URL host, SynchronizationListener synchronizationListener, TripListener tripListener, @NonNull String syncJobServiceClassName) {
        //noinspection ConstantConditions
        if (context == null) {
            return ErrorFactory.getGeneralContextError();
        }
        //noinspection ConstantConditions
        if (host == null || host.getHost() == null || host.getHost().isEmpty()) {
            return ErrorFactory.getWarnError(context, Error.GENERAL_INVALID_INPUT, new InvalidParameterException(String.format(context.getString(R.string.EXCEPTION_INVALID_INPUT), "host")));
        }
        //noinspection ConstantConditions
        if (!SyncController.validateSyncJobServiceClass(syncJobServiceClassName)) {
            return ErrorFactory.getWarnError(context, Error.GENERAL_INVALID_INPUT, new InvalidParameterException(String.format(context.getString(R.string.EXCEPTION_INVALID_INPUT), "syncJobServiceClassName")));
        }

        CoreController.tripListener = tripListener;
        CoreController.syncListener = synchronizationListener;

        PreferencesController.getInstance(context).setHostUrl(host);
        PreferencesController.getInstance(context).setSyncJobServiceClassName(syncJobServiceClassName);

        securityHelper = new SecurityHelper(context);
        storeManager = GaStoreFactory.getRealmGaStoreManager(context, securityHelper);
        restController = GaRestFactory.getRetrofitGaRestController(PreferencesController.getInstance(context).getHostUrl());


        this.initialized = true;

        return null;
    }

    private Error checkPermission(ContextWrapper context, String permissionName) {
        if (ContextCompat.checkSelfPermission(context, permissionName) != PackageManager.PERMISSION_GRANTED) {
            return ErrorFactory.getFatalError(context, Error.GENERAL_NO_PERMISSIONS_GRANTED, new IllegalAccessException("Permission not granted: " + context.getPackageName() + ".did.ACCESS"));
        } else {
            return null;
        }
    }

    private Error checkPermissions(ContextWrapper context) {
        Error didPermissionError = checkPermission(context, context.getPackageName() + ".did.ACCESS");
        if (didPermissionError != null) {
            return didPermissionError;
        } else {
            return checkPermission(context, Manifest.permission.READ_PHONE_STATE);
        }
    }

    public Error validateAction(ContextWrapper context) {
        // Check Context
        if (context == null) {
            return ErrorFactory.getGeneralContextError();
        }
        // Check Initialization
        if (!initialized) {
            return ErrorFactory.getFatalError(context, Error.GENERAL_NEED_INITIALIZE);
        }
        // Check Permissions
        Error permissionsError = checkPermissions(context);
        if (permissionsError != null) {
            return permissionsError;
        }

        // Check CurrentDate
        if (!verifyCurrentDate()) {
            return ErrorFactory.getWarnError(context, Error.SECURITY_BAD_DATE);
        }

        // Check Device Security Status
        int devCode = securityHelper.verifyDevice();
        if (devCode != SecurityHelper.OK) {
            int errorCode;
            switch (devCode) {
                case SecurityHelper.IS_ROOT:
                    errorCode = Error.SECURITY_ROOTED;
                    break;
                case SecurityHelper.DEVICE_NOT_ENCRYPTED:
                    errorCode = Error.SECURITY_NO_SYSTEM_ENCRYPT;
                    break;
                case SecurityHelper.WITHOUT_LOCK:
                    errorCode = Error.SECURITY_NO_LOCK;
                    break;
                default:
                    errorCode = Error.SECURITY_UKN_ERROR;
                    break;
            }
            return ErrorFactory.getFatalError(context, errorCode);
        }
        return null;
    }

    private boolean validateAction(ContextWrapper context, RequestListener listener) {
        Error error = validateAction(context);
        if (error != null) {
            if (listener != null)
                listener.onFailure(error);
            return false;
        }
        return true;
    }

    public static Logger getLogger() {
        return DEFAULT;
    }

    public void setLogLevel(int logLevel) {
        applyLogLevel(logLevel);
    }

    private void applyLogLevel(int logLevel) {
        getLogger().setLevel(logLevel);

        GaCard.getInstance().setLogLevel(logLevel);
        ECard.getInstance().setLogLevel(logLevel);

        SecurityHelper.setLogLevel(NONE);
    }

    public static TripListener getTripListener() {
        return tripListener;
    }

    public void setTripListener(TripListener tripListener) {
        CoreController.tripListener = tripListener;
    }

    public void setSyncListener(SynchronizationListener listener) {
        CoreController.syncListener = listener;
    }

    public static SynchronizationListener getSyncListener() {
        return syncListener;
    }

    private boolean verifyCurrentDate() {
        boolean verify = true;
        try {
            verify = securityHelper.isSecretValid(SecurityHelper.DATE, String.valueOf(System.currentTimeMillis()));
        } catch (Exception e) {
            getLogger().logError("CoreController::verifyCurrentDate", "Exception", e);
        }
        return verify;
    }


    public Error scheduleSync(@NonNull ContextWrapper context) {
        SyncController.scheduleSync(context);
        return null;
    }

    public Error setLockedCard(@NonNull ContextWrapper context, boolean lockedCard) {
        Error error = validateAction(context);
        if (error != null)
            return error;
        PreferencesController.getInstance(context).setLockedCard(lockedCard);
        return null;
    }

    public void isLockedCard(@NonNull ContextWrapper context, RequestListener<Boolean> listener) {
        if (!validateAction(context, listener)) return;
        if (listener != null)
            listener.onSuccess(PreferencesController.getInstance(context).isLockedCard());
    }

    public Error setVibrateEnabled(@NonNull ContextWrapper context, boolean vibrateEnabled) {
        Error error = validateAction(context);
        if (error != null)
            return error;
        PreferencesController.getInstance(context).setVibrateEnabled(vibrateEnabled);
        return null;
    }

    public void isVibrateEnabled(@NonNull ContextWrapper context, RequestListener<Boolean> listener) {
        if (!validateAction(context, listener)) return;
        if (listener != null)
            listener.onSuccess(PreferencesController.getInstance(context).isVibrateEnabled());
    }

    public Error setRingNotificationEnabled(@NonNull ContextWrapper context, boolean ringNotificationEnabled) {
        Error error = validateAction(context);
        if (error != null)
            return error;
        PreferencesController.getInstance(context).setRingNotificationEnabled(ringNotificationEnabled);
        return null;
    }

    public void isRingNotificationEnabled(@NonNull ContextWrapper context, RequestListener<Boolean> listener) {
        if (!validateAction(context, listener)) return;
        if (listener != null)
            listener.onSuccess(PreferencesController.getInstance(context).isRingNotificationEnabled());
    }

    public void getBalance(@NonNull ContextWrapper context, @NonNull final RequestListener<Integer> listener) {
        if (!validateAction(context, listener)) return;
        if (!storeManager.checkGaCard()) {
            listener.onSuccess(0);
        }
        int balance = -1;
        Exception e = null;
        try {
            balance = ByteArray.arrayByteToInt(GaAppletManagerFactory.getGaCardManager(context).getBalance());
        } catch (Exception ex) {
            e = ex;
        }

        if (e != null) {
            listener.onFailure(ErrorFactory.getFatalError(context, Error.GENERAL_UNEXPECTED_EXCEPTION, e));
        } else {
            listener.onSuccess(balance);
        }
    }

    public void getRecharges(@NonNull ContextWrapper context, @NonNull final RequestListener<List<Recharge>> listener) {
        if (!validateAction(context, listener)) return;
        storeManager.getAll(GaStoreManager.TABLE_RECHARGE, new RequestListener<List<Object>>() {
            @Override
            public void onSuccess(List<Object> response) {
                List<Recharge> recharges = new ArrayList<>();
                if (response != null)
                    //noinspection unchecked
                    recharges = new RechargeMapper().listStoreToUi((List<RechargeRealm>) (Object) response);
                listener.onSuccess(recharges);
            }

            @Override
            public void onFailure(Error error) {
                listener.onFailure(error);
            }
        });
    }


    public void getTrips(@NonNull ContextWrapper context, @NonNull final RequestListener<List<Trip>> listener) {
        if (!validateAction(context, listener)) return;
        storeManager.getAll(GaStoreManager.TABLE_TRIP, new RequestListener<List<Object>>() {
            @Override
            public void onSuccess(List<Object> response) {
                List<Trip> trips = new ArrayList<>();
                if (response != null)
                    //noinspection unchecked
                    trips = new TripMapper().listStoreToUi((List<TripRealm>) (Object) response);
                listener.onSuccess(trips);
            }

            @Override
            public void onFailure(Error error) {
                listener.onFailure(error);
            }
        });
    }


    public void getPendingPayments(@NonNull final ContextWrapper context, @NonNull final RequestListener<List<PendingPayment>> listener) {
        if (!validateAction(context, listener)) return;
        RechargeController.getPendingPayments(context, getLanguage(context), storeManager, restController, securityHelper, listener);
    }

    public void getTokenCardPayments(@NonNull final ContextWrapper context, @NonNull final RequestListener<List<TokenCardPayment>> listener) {
        if (!validateAction(context, listener)) return;
        RechargeController.getTokenCardPayments(context, storeManager, restController, securityHelper, listener);
    }

    @NonNull
    private String getHardwareIdentifier() {
        return securityHelper.getHardwareIdentifier();
    }

    @NonNull
    private String getLanguage(ContextWrapper context) {
        return context == null ? DEFAULT_LANGUAGE : context.getResources().getString(R.string.GATDEFAULT_LANGUAGE);
    }

    public void getUser(@NonNull final ContextWrapper context, @NonNull final RequestListener<com.did.gatransport.model.User> listener) {
        if (!validateAction(context, listener)) return;
        storeManager.getUser(new RequestListener<User>() {
            @Override
            public void onSuccess(User response) {
                if (response != null)
                    listener.onSuccess(new UserMapper().storeToUi((UserRealm) response));
                else
                    listener.onFailure(ErrorFactory.getWarnError(context, Error.GENERAL_USER_NOT_EXISTS));
            }

            @Override
            public void onFailure(Error error) {
                listener.onFailure(error);
            }
        });
    }

    public void getPendingRechargeConfirm(@NonNull final ContextWrapper context, @NonNull final RequestListener<PendingRechargeConfirm> listener) {
        if (!validateAction(context, listener)) return;
        storeManager.getRechargeConfirmRequest(new RequestListener<RechargeConfirmRequest>() {
            @Override
            public void onSuccess(RechargeConfirmRequest response) {
                if (response != null)
                    listener.onSuccess(new RechargeMapper().fromRechargeConfirmRequestRealm(response));
                else
                    listener.onFailure(ErrorFactory.getWarnError(context, Error.GENERAL_PENDING_RECHARGE_CONFIRM_NOT_EXISTS));
            }

            @Override
            public void onFailure(Error error) {
                listener.onFailure(error);
            }
        });
    }

    public void doEnroll(@NonNull ContextWrapper context, @NonNull EnrollRequest request, @NonNull RequestListener<Void> listener) {
        if (!validateAction(context, listener)) return;
        EnrollController.getInstance(restController, storeManager).enroll(context, request, securityHelper, listener);
    }

    public void doEnrollLockCard(@NonNull ContextWrapper context, @NonNull EnrollLockCardRequest request, @NonNull RequestListener<Void> listener) {
        if (!validateAction(context, listener)) return;
        EnrollController.getInstance(restController, storeManager).manageCard(context, request, listener);
    }

    public void doFinishEnroll(@NonNull ContextWrapper context, @NonNull FinishEnrollRequest request, @NonNull RequestListener<Void> listener) {
        if (!validateAction(context, listener)) return;
        EnrollController.getInstance(restController, storeManager).finishEnroll(context, request, securityHelper, listener);
    }

    public void getProfileUpdates(@NonNull ContextWrapper context, @NonNull RequestListener<List<ProfileUpdate>> listener) {
        if (!validateAction(context, listener)) return;
        ProfileUpdateController.getProfileUpdates(context, getLanguage(context), storeManager, restController, securityHelper, listener);
    }

    public void doProfileUpdate(@NonNull ContextWrapper context, @NonNull ProfileUpdateRequest request, @NonNull RequestListener<Void> listener) {
        if (!validateAction(context, listener)) return;
        ProfileUpdateController.performProfileUpdate(context, request, storeManager, restController, securityHelper, listener);
    }

    public void isSecure(@NonNull ContextWrapper context, @NonNull SecurityCheckRequest request, @NonNull RequestListener<SecurityCheck> listener) {
        if (!initialized) {
            //noinspection ConstantConditions
            if (listener != null)
                listener.onFailure(ErrorFactory.getFatalError(context, Error.GENERAL_NEED_INITIALIZE));
            return;
        }

        SecurityCheck result = null;
        int devCode = securityHelper.verifyDevice();
        if (devCode != SecurityHelper.OK) {
            result = new SecurityCheck(devCode);
        }

        int appCode = securityHelper.verifyApk(request.getAppSignatureList());
        if (appCode != SecurityHelper.OK) {
            result = new SecurityCheck(appCode);
        }

        if (result == null) {
            result = new SecurityCheck(SecurityHelper.OK);
        }
        listener.onSuccess(result);
    }

    public void doPendingRecharge(@NonNull final ContextWrapper context, @NonNull final PendingRechargeRequest request, @NonNull final RequestListener<Void> listener) {
        if (!validateAction(context, listener)) return;
        if (PreferencesController.getInstance(context).isLockedCard()) {
            listener.onFailure(ErrorFactory.getWarnError(context, Error.CARD_LOCKED_MANUALLY));
            return;
        }
        CoreController.getLogger().logDebug("CoreController::doPendingRecharge", "PendingRechargeConfirm Process START");
        CoreController.getLogger().logDebug("CoreController::doPendingRecharge", "First, doLogin+doSync for Authorization/Sync refresh.");
        ProcessController.setRpIsRunning(true);
        RechargeController.doLogin(context, storeManager, restController, securityHelper, request.getPwd(), new RequestListener<Void>() {
            @Override
            public void onSuccess(Void response) {
                CoreController.getLogger().logDebug("CoreController::doPendingRecharge", "Second, REST_Send PendingRechargeRequest.");
                RechargeController.doPendingRecharge(context, storeManager, restController, securityHelper, request.getPayment(), new RequestListener<Void>() {
                    @Override
                    public void onSuccess(Void response) {
                        CoreController.getLogger().logDebug("CoreController::doPendingRecharge", "Third(Last), REST_Send RechargeConfirm.");
                        RechargeController.doConfirmRecharge(context, storeManager, restController, securityHelper, new RequestListener<Void>() {
                            @Override
                            public void onSuccess(Void response) {
                                CoreController.getLogger().logDebug("CoreController::doPendingRecharge", "PendingRechargeConfirm Process OK END");
                                ProcessController.setRpIsRunning(false);
                                listener.onSuccess(null);
                            }

                            @Override
                            public void onFailure(final Error error) {
                                CoreController.getLogger().logDebug("CoreController::doPendingRecharge", "PendingRechargeConfirm Process KO END");
                                CoreController.getLogger().logError("CoreController::doPendingRecharge", error, "PendingRechargeConfirm Process KO END");
                                ProcessController.setRpIsRunning(false);
                                listener.onFailure(error);
                            }
                        });
                    }

                    @Override
                    public void onFailure(Error error) {
                        CoreController.getLogger().logDebug("CoreController::doPendingRecharge", "PendingRechargeConfirm Process KO END");
                        CoreController.getLogger().logError("CoreController::doPendingRecharge", error, "PendingRechargeConfirm Process KO END");
                        ProcessController.setRpIsRunning(false);
                        listener.onFailure(error);
                    }
                });
            }

            @Override
            public void onFailure(Error error) {
                CoreController.getLogger().logDebug("CoreController::doPendingRecharge", "PendingRechargeConfirm Process KO END");
                CoreController.getLogger().logError("CoreController::doPendingRecharge", error, "PendingRechargeConfirm Process KO END");
                ProcessController.setRpIsRunning(false);
                listener.onFailure(error);
            }
        });
    }

    public void doLogin(@NonNull final ContextWrapper context, @NonNull LoginRequest request, final RequestListener<Void> listener) {
        if (!validateAction(context, listener)) return;
        LoginController.login(context, storeManager, restController, request.getUser(), request.getPwd(), new RequestListener<Void>() {
            @Override
            public void onSuccess(Void response) {
                SyncController.scheduleSync(context);
                if (listener != null) {
                    listener.onSuccess(response);
                }
            }

            @Override
            public void onFailure(Error error) {
                if (listener != null) {
                    listener.onFailure(error);
                }
            }
        });
    }

    public Error doLogout(@NonNull ContextWrapper context) {
        //noinspection ConstantConditions
        if (context == null) {
            return ErrorFactory.getGeneralContextError();
        }
        LoginController.logout(context);
        return null;
    }

    public void doManageCard(@NonNull ContextWrapper context, @NonNull ManageCardRequest request, @NonNull RequestListener<Void> listener) {
        if (!validateAction(context, listener)) return;
        ManageCardController.manageCard(context, request, getHardwareIdentifier(), storeManager, restController, securityHelper, listener);
    }

    public void doRegisterPushChannel(@NonNull final ContextWrapper context, @NonNull final RegisterPushChannelRequest request, @NonNull final RequestListener<Void> listener) {
        if (!validateAction(context, listener)) return;
        ManageCardController.doRegisterPushChannel(context, request, getHardwareIdentifier(), storeManager, restController, securityHelper, listener);
    }

    // TODO ONLY FOR DEBUG
//    public void doFakeRecharge(final ContextWrapper context, final int nt, final int amount, final int balance, final RequestListener<Void> listener) throws IllegalAccessException {
//        if (!BuildConfig.DEBUG) {
//            throw new IllegalAccessException("No no no...");
//        }
//        storeManager.getUser(new RequestListener<User>() {
//            @Override
//            public void onSuccess(User response) {
//                String userToken = response.getToken();
//                String user = response.getName();
//                String phoneId = response.getPhoneId();
//                String hwId = securityHelper.getHardwareIdentifier();
//                restController.doFakeRecharge(userToken, user, phoneId, hwId, String.valueOf(nt), AmountConverter.getDecimalAmountString(amount), AmountConverter.getDecimalAmountString(balance), new RequestListener<FakeRechargeResponse>() {
//                    @Override
//                    public void onSuccess(FakeRechargeResponse response) {
//                        try {
//                            // Update Card
//                            GaAppletManager gaAppletManager = GaAppletManagerFactory.getGaCardManager(context);
//                            gaAppletManager.resetState();
//                            gaAppletManager.rechargeBalance(nt, balance, amount);
//
//                            // Update Signature
//                            byte[] signature = response.getSignature();
//                            new SecurityHelper(context).saveSecret(SecurityHelper.FOUR_BYTES, signature);
//
//                            // Generate Recharge Store
//                            RechargeRealm rechargeRealm = new RechargeRealm();
//                            rechargeRealm.setAmount(amount);
//                            rechargeRealm.setDate(System.currentTimeMillis());
//                            rechargeRealm.setType(3);
//                            rechargeRealm.setCardLastDig("");
//                            storeManager.insert(rechargeRealm, new RequestListener<Void>() {
//                                @Override
//                                public void onSuccess(Void response) {
//                                    CoreController.getLogger().log("rk start!");
//                                    storeManager.refreshKey(new RequestListener<Void>() {
//                                        @Override
//                                        public void onSuccess(Void response) {
//                                            CoreController.getLogger().log("rk ok!");
//                                            if (listener != null)
//                                                listener.onSuccess(null);
//                                        }
//
//                                        @Override
//                                        public void onFailure(Error error) {
//                                            CoreController.getLogger().log("rk ko: " + error.getMsg(), error.getException());
//                                            if (listener != null)
//                                                listener.onSuccess(null);
//                                        }
//                                    });
//                                }
//
//                                @Override
//                                public void onFailure(Error error) {
//                                    if (listener != null) listener.onFailure(error);
//                                }
//                            });
//                        } catch (Exception e) {
//                            Error error = ErrorFactory.getWarnError(context, Error.RECHARGE_CARD_SOMETHING_WRONG, e);
//                            Error error2 = ErrorFactory.getWarnError(context, Error.RECHARGE_CANNOT_CONFIRM);
//                            error2.setPreviousError(error);
//                            CoreController.getLogger().log(error.getMsg(), e);
//                            if (listener != null) listener.onFailure(error2);
//                        }
//                    }
//
//                    @Override
//                    public void onFailure(Error error) {
//                        if (listener != null) listener.onFailure(error);
//                    }
//                });
//            }
//
//            @Override
//            public void onFailure(Error error) {
//                if (listener != null) listener.onFailure(error);
//            }
//        });
//    }
}
