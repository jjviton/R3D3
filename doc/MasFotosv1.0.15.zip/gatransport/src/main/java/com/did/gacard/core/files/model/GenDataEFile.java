package com.did.gacard.core.files.model;

import com.did.gacard.ecard.core.iso7816.files.EFile;
import com.did.gacard.ecard.util.ByteArray;
import com.google.gson.annotations.SerializedName;

public final class GenDataEFile extends EFile {

    @SerializedName("struct_environment")
    private byte[] structEnvironment;
    @SerializedName("struct_user")
    private byte[] structUser;

    public GenDataEFile() {
        super();
    }

    public GenDataEFile(GenDataEFile other) {
        super(other);
        if (other == null) return;
        this.structEnvironment = ByteArray.copyOf(other.structEnvironment);
        this.structUser = ByteArray.copyOf(other.structUser);
    }

    public byte[] getStructEnvironment() {
        return structEnvironment;
    }

    public void setStructEnvironment(byte[] structEnvironment) {
        this.structEnvironment = structEnvironment;
    }

    public byte[] getStructUser() {
        return structUser;
    }

    public void setStructUser(byte[] structUser) {
        this.structUser = structUser;
    }
}
