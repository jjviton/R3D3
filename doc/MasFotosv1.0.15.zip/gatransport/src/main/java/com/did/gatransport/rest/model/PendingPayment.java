package com.did.gatransport.rest.model;

import com.google.gson.annotations.SerializedName;

public final class PendingPayment {

    @SerializedName("type")
    private String type;
    @SerializedName("key")
    private String key;
    @SerializedName("amount")
    private String amount;
    @SerializedName("msg")
    private String msg;
    @SerializedName("fec_cad")
    private String expDate;
    @SerializedName("pan")
    private String pan;
    @SerializedName("rec_type")
    private String rec_type;

    public PendingPayment() {
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public String getKey() {
        return key;
    }

    public void setKey(String key) {
        this.key = key;
    }

    public String getAmount() {
        return amount;
    }

    public void setAmount(String amount) {
        this.amount = amount;
    }

    public String getMsg() {
        return msg;
    }

    public void setMsg(String msg) {
        this.msg = msg;
    }

    public String getExpDate() {
        return expDate;
    }

    public void setExpDate(String expDate) {
        this.expDate = expDate;
    }

    public String getPan() {
        return pan;
    }

    public void setPan(String pan) {
        this.pan = pan;
    }

    public String getRec_type() {
        return rec_type;
    }

    public void setRec_type(String rec_type) {
        this.rec_type = rec_type;
    }
}
