package com.did.gatransport.store;

import android.content.ContextWrapper;

import com.did.gatransport.store.realm.RealmGaStoreManager;
import com.did.security.core.SecurityHelper;

public final class GaStoreFactory {
    public static GaStoreManager getRealmGaStoreManager(ContextWrapper context, SecurityHelper securityHelper) {
        return new RealmGaStoreManager(context, new ImplGaStoreSecurityElement(context, securityHelper));
    }
}
