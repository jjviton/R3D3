package com.did.gatransport.store;

import com.did.gatransport.interfaces.RequestListener;

public interface GaStoreSecurityElement {

    byte[] getEncryptionKey() throws Exception;

    boolean isValidHash(String storeFilePath);

    boolean isValidDate(String storeFilePath);

    void updateHash(String storeFilePath);

    String getHash(String storeFilePath);

    void refreshEncryptionKey(RequestListener<Void> listener);

}
