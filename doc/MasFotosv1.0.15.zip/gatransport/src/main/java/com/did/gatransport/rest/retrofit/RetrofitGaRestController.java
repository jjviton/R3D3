package com.did.gatransport.rest.retrofit;

import android.support.annotation.NonNull;

import com.did.gatransport.BuildConfig;
import com.did.gatransport.controller.CoreController;
import com.did.gatransport.interfaces.CustomRequestListener;
import com.did.gatransport.interfaces.RequestListener;
import com.did.gatransport.model.Error;
import com.did.gatransport.model.ErrorResponse;
import com.did.gatransport.rest.GaRestController;
import com.did.gatransport.rest.model.TransactionLine;
import com.did.gatransport.rest.model.response.BalanceResponse;
import com.did.gatransport.rest.model.response.BaseResponse;
import com.did.gatransport.rest.model.response.EnrollResponse;
import com.did.gatransport.rest.model.response.FinishEnrollResponse;
import com.did.gatransport.rest.model.response.GenericResponse;
import com.did.gatransport.rest.model.response.LoginResponse;
import com.did.gatransport.rest.model.response.PendingPaymentResponse;
import com.did.gatransport.rest.model.response.ProfileUpdateListResponse;
import com.did.gatransport.rest.model.response.ProfileUpdateResponse;
import com.did.gatransport.rest.model.response.RechargeResponse;
import com.did.gatransport.rest.model.response.TokenCardResponse;
import com.did.gatransport.rest.retrofit.request.BalanceRequest;
import com.did.gatransport.rest.retrofit.request.CardRechargeRequest;
import com.did.gatransport.rest.retrofit.request.CheckProfileUpdateRequest;
import com.did.gatransport.rest.retrofit.request.ClientFinishEnrollRequest;
import com.did.gatransport.rest.retrofit.request.ConfirmEnrollRequest;
import com.did.gatransport.rest.retrofit.request.ConfirmProfileUpdateRequest;
import com.did.gatransport.rest.retrofit.request.DNIEnrollRequest;
import com.did.gatransport.rest.retrofit.request.EnrollManageRequest;
import com.did.gatransport.rest.retrofit.request.EnrollRequest;
import com.did.gatransport.rest.retrofit.request.FinishEnrollRequest;
import com.did.gatransport.rest.retrofit.request.LoginRequest;
import com.did.gatransport.rest.retrofit.request.ManageRequest;
import com.did.gatransport.rest.retrofit.request.OTPFinishEnrollRequest;
import com.did.gatransport.rest.retrofit.request.PANEnrollRequest;
import com.did.gatransport.rest.retrofit.request.PendingPaymentRequest;
import com.did.gatransport.rest.retrofit.request.PendingRechargeRequest;
import com.did.gatransport.rest.retrofit.request.ProfileUpdateRequest;
import com.did.gatransport.rest.retrofit.request.RegisterPushChannelRequest;
import com.did.gatransport.rest.retrofit.request.Request;
import com.did.gatransport.rest.retrofit.request.TokenCardRequest;
import com.did.gatransport.rest.retrofit.request.TransactionRequest;
import com.did.gatransport.rest.retrofit.request.UserFinishEnrollRequest;
import com.did.gatransport.util.ErrorFactory;
import com.did.gatransport.util.Logger;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.stream.MalformedJsonException;

import java.io.IOException;
import java.net.URL;
import java.security.InvalidParameterException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Locale;
import java.util.concurrent.TimeUnit;

import javax.net.ssl.SSLSocketFactory;
import javax.net.ssl.X509TrustManager;

import okhttp3.CertificatePinner;
import okhttp3.OkHttpClient;
import okhttp3.logging.HttpLoggingInterceptor;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;
import retrofit2.converter.scalars.ScalarsConverterFactory;

public final class RetrofitGaRestController implements GaRestController {
    private static final String HEADER_COOKIE = "cobtoken=";
    private static final String VALUE_COOKIE = "x9VeKvZCpqkuY0fZJHX+I9P2YT7I+MTXkeRFVGzw+19yxd1wODgNtQxa8W+mQbWiQeNZus4nGzUVoWKmW7iRyOHUDjgnuKK+RaHpAnnxdEwdvf2gIwbDP7Ec8FKZlXTBt8puGnTzVjnZWlRZe5fZHA==";

    private static final String COOKIE = HEADER_COOKIE + VALUE_COOKIE;

    private final class RequestCallback<T> implements Callback<T> {

        private final RequestListener<T> listener;
        private boolean nullable;

        private RequestCallback(RequestListener<T> listener) {
            super();
            this.listener = listener;
            this.nullable = false;
        }

        private RequestCallback(RequestListener<T> listener, boolean nullable) {
            super();
            this.listener = listener;
            this.nullable = nullable;
        }

        @Override
        public void onResponse(@NonNull Call<T> call, @NonNull Response<T> response) {
            // First check response is 200 OK
            // Second check if can be Null then body can not be BaseResponse
            // Third check if can not be Null then body can not be Null
            // Fourth check if can not be Null then body can be No BaseResponse OR if is BaseResponse then can not be No OK
            if (response.isSuccessful()
                    && ((nullable && !(response.body() instanceof BaseResponse)) || (!nullable && response.body() != null && (!(response.body() instanceof BaseResponse) || ((BaseResponse) response.body()).isOk())))) {
                if (listener != null) listener.onSuccess(response.body());
            } else {
                handleError(response, listener);
            }
        }

        @Override
        public void onFailure(@NonNull Call<T> call, @NonNull Throwable t) {
            handleFailure(call, t, listener);
        }
    }

    private final class RequestCallback2<T> implements Callback<T> {

        private final CustomRequestListener<T, ErrorResponse<T>> listener;
        private boolean nullable;

        private RequestCallback2(CustomRequestListener<T, ErrorResponse<T>> listener) {
            super();
            this.listener = listener;
            this.nullable = false;
        }

        private RequestCallback2(CustomRequestListener<T, ErrorResponse<T>> listener, boolean nullable) {
            super();
            this.listener = listener;
            this.nullable = nullable;
        }

        @Override
        public void onResponse(@NonNull Call<T> call, @NonNull Response<T> response) {
            // First check response is 200 OK
            // Second check if can be Null then body can not be BaseResponse
            // Third check if can not be Null then body can not be Null
            // Fourth check if can not be Null then body can be No BaseResponse OR if is BaseResponse then can not be No OK
            if (response.isSuccessful()
                    && ((nullable && !(response.body() instanceof BaseResponse)) || (!nullable && response.body() != null && (!(response.body() instanceof BaseResponse) || ((BaseResponse) response.body()).isOk())))) {
                if (listener != null) listener.onSuccess(response.body());
            } else {
                ErrorResponse<T> errorResponse = new ErrorResponse<>(getError(response, null), response.body());
                if (listener != null) listener.onFailure(errorResponse);
            }
        }

        @Override
        public void onFailure(@NonNull Call<T> call, @NonNull Throwable t) {
            ErrorResponse<T> errorResponse = new ErrorResponse<>(getError(t));
            if (listener != null) listener.onFailure(errorResponse);
        }
    }

    private void handleFailure(@NonNull Call call, @NonNull Throwable t, RequestListener listener) {
        Error e = getError(t);
        if (listener != null) listener.onFailure(e);
    }

    private Error getError(@NonNull Throwable t) {
        Error e;
        if (t instanceof IOException && !(t instanceof MalformedJsonException)) {
            e = ErrorFactory.getRestConnectionError(t);
        } else {
            e = ErrorFactory.getRestThrowableError(t);
        }
        return e;
    }

    private void handleError(@NonNull Response response, Exception e, RequestListener listener) {
        Error error = getError(response, e);
        if (listener != null) listener.onFailure(error);
    }

    private Error getError(@NonNull Response response, Exception e) {
        String msg = "";
        int code = response.code();
        if (response.errorBody() != null) {
            try {
                msg = response.errorBody().string();
            } catch (Exception ex) {
                if (mLogger != null)
                    mLogger.logError("RetrofitGaRestController::getWarnError", "Something went wrong", ex);
            }
        }
        Error error = null;
        switch (code) {
            case 200:
                error = ErrorFactory.getRestResponseError(response.body(), e);
                break;
            case 403:
                error = ErrorFactory.getRestSessionError(code);
                break;

            default:
                break;
        }

        if (error == null) {
            error = ErrorFactory.getRestServerError(code, msg);
        }
        return error;
    }

    private void handleError(@NonNull Response response, RequestListener listener) {
        handleError(response, null, listener);
    }

    private Logger mLogger;
    private RetrofitGaRestServices retrofitGaRestServices;

    private void create(@NonNull URL host, CertificatePinner certificatePinner, SSLSocketFactory sslSocketFactory, X509TrustManager trustManager, Logger logger) {
        if (host == null)
            throw new InvalidParameterException("Bad URL host. Cannot be null.");
        this.mLogger = logger;

        HttpLoggingInterceptor loggingInterceptor = new HttpLoggingInterceptor();
        if (CoreController.getLogger() != null && CoreController.getLogger().getLevel() == CoreController.FULL && BuildConfig.DEBUG)
            loggingInterceptor.setLevel(HttpLoggingInterceptor.Level.BODY);
        else
            loggingInterceptor.setLevel(HttpLoggingInterceptor.Level.NONE);


        OkHttpClient.Builder clientBuilder = new OkHttpClient.Builder();

        if (certificatePinner != null)
            clientBuilder.certificatePinner(certificatePinner);
        else if (sslSocketFactory != null && trustManager != null)
            clientBuilder.sslSocketFactory(sslSocketFactory, trustManager);

        clientBuilder.addInterceptor(loggingInterceptor)
                .connectTimeout(2, TimeUnit.MINUTES)
                .readTimeout(2, TimeUnit.MINUTES)
                .writeTimeout(2, TimeUnit.MINUTES);

        OkHttpClient client = clientBuilder.build();

        Gson gson = new GsonBuilder()
                .setLenient()
                .create();

        String hostUrl = host.toString();
        if (!hostUrl.isEmpty() && hostUrl.charAt(hostUrl.length() - 1) != '/')
            hostUrl = hostUrl.concat("/");

        Retrofit retrofit = new Retrofit.Builder()
                .addConverterFactory(ScalarsConverterFactory.create())
                .baseUrl(hostUrl)
                .client(client)
                .addConverterFactory(GsonConverterFactory.create(gson))
                .build();

        retrofitGaRestServices = retrofit.create(RetrofitGaRestServices.class);
    }

    public RetrofitGaRestController(@NonNull URL host, Logger logger) {
        create(host, null, null, null, logger);
    }

    public RetrofitGaRestController(@NonNull URL host, @NonNull CertificatePinner certificatePinner, Logger logger) {
        if (certificatePinner == null)
            throw new InvalidParameterException("Bad CertificatePinner. Cannot be null.");
        create(host, certificatePinner, null, null, logger);
    }

    public RetrofitGaRestController(@NonNull URL host, @NonNull SSLSocketFactory sslSocketFactory, @NonNull X509TrustManager trustManager, Logger logger) {
        if (sslSocketFactory == null)
            throw new InvalidParameterException("Bad SSLSocketFactory. Cannot be null.");
        if (trustManager == null)
            throw new InvalidParameterException("Bad X509TrustManager. Cannot be null.");
        create(host, null, sslSocketFactory, trustManager, logger);
    }

    public RetrofitGaRestController(@NonNull URL host, @NonNull CertificatePinner certificatePinner) {
        this(host, certificatePinner, CoreController.getLogger());
    }

    public RetrofitGaRestController(@NonNull URL host, @NonNull SSLSocketFactory sslSocketFactory, @NonNull X509TrustManager trustManager) {
        this(host, sslSocketFactory, trustManager, CoreController.getLogger());
    }

    public RetrofitGaRestController(@NonNull URL host) {
        this(host, CoreController.getLogger());
    }

    private String wrapUserCobToken(String token) {
        return HEADER_COOKIE + token;
    }

    @Override
    public void performLogin(String userToken, String user, String pwd, RequestListener<LoginResponse> listener) {
        LoginRequest request = new LoginRequest();
        request.setUser(user);
        request.setPwd(pwd);
        retrofitGaRestServices.performLogin(wrapUserCobToken(userToken), request).enqueue(new RequestCallback<>(listener));
    }

    @Override
    public void performDNIEnroll(String hwId, String cardType, String profile, String dni, RequestListener<EnrollResponse> listener) {
        DNIEnrollRequest request = new DNIEnrollRequest();
        request.setDni(dni);
        request.setHwId(hwId);
        request.setCardType(cardType);
        request.setProfile(profile);

        performEnroll(RetroRequestFactory.dniEnrollRequest(request), listener);
    }

    @Override
    public void performPANEnroll(String hwId, String cardType, String profile, String pan, RequestListener<EnrollResponse> listener) {
        PANEnrollRequest request = new PANEnrollRequest();
        request.setPan(pan);
        request.setHwId(hwId);
        request.setCardType(cardType);
        request.setProfile(profile);

        performEnroll(RetroRequestFactory.panEnrollRequest(request), listener);
    }

    private void performEnroll(Request<EnrollRequest> request, RequestListener<EnrollResponse> listener) {
        retrofitGaRestServices.performEnroll(COOKIE, request).enqueue(new RequestCallback<>(listener));
    }

    @Override
    public void performOtpFinishEnroll(String pwd, String mail, String phone, String hwId, String profile, String profileExpiration, String paySolution, String tokenId, String requestId, String otp, RequestListener<FinishEnrollResponse> listener) {
        OTPFinishEnrollRequest request = new OTPFinishEnrollRequest();

        request.setPwd(pwd);
        request.setMail(mail);
        request.setPhone(phone);
        request.setHwId(hwId);
        request.setProfile(profile);
        request.setProfileExpiration(profileExpiration);
        request.setPaySolution(paySolution);

        request.setTokenId(tokenId);
        request.setRequestId(requestId);
        request.setOtp(otp);

        retrofitGaRestServices.finishEnroll(COOKIE, RetroRequestFactory.otpFinishEnrollRequest(request)).enqueue(new RequestCallback<>(listener));
    }

    @Override
    public void performUserFinishEnroll(String pwd, String mail, String phone, String hwId, String cardType, String profile, String profileExpiration, String paySolution, String userId, RequestListener<FinishEnrollResponse> listener) {
        UserFinishEnrollRequest request = new UserFinishEnrollRequest();

        request.setPwd(pwd);
        request.setMail(mail);
        request.setPhone(phone);
        request.setHwId(hwId);
        request.setCardType(cardType);
        request.setProfile(profile);
        request.setProfileExpiration(profileExpiration);
        request.setPaySolution(paySolution);

        request.setUserId(userId);

        finishEnroll(RetroRequestFactory.userFinishEnrollRequest(request), listener);
    }

    @Override
    public void performClientFinishEnroll(String pwd, String mail, String phone, String hwId, String cardType, String profile, String profileExpiration, String paySolution, String clientId, RequestListener<FinishEnrollResponse> listener) {
        ClientFinishEnrollRequest request = new ClientFinishEnrollRequest();

        request.setPwd(pwd);
        request.setMail(mail);
        request.setPhone(phone);
        request.setHwId(hwId);
        request.setCardType(cardType);
        request.setProfile(profile);
        request.setProfileExpiration(profileExpiration);
        request.setPaySolution(paySolution);

        request.setClientId(clientId);

        finishEnroll(RetroRequestFactory.userFinishEnrollRequest(request), listener);
    }

    private void finishEnroll(Request<FinishEnrollRequest> request, RequestListener<FinishEnrollResponse> listener) {
        retrofitGaRestServices.finishEnroll(COOKIE, request).enqueue(new RequestCallback<>(listener));
    }

    @Override
    public void confirmEnrollment(String hwId, String pan, String tokenId, String phoneId, RequestListener<BaseResponse> listener) {
        ConfirmEnrollRequest request = new ConfirmEnrollRequest();
        request.setHwId(hwId);
        request.setPan(pan);
        request.setTokenId(tokenId);
        request.setPhoneId(phoneId);

        retrofitGaRestServices.confirmEnrollment(COOKIE, RetroRequestFactory.confirmEnrollRequestRequest(request)).enqueue(new RequestCallback<>(listener));
    }

    @Override
    public void getProfileUpdates(String userToken, String user, String hwId, String pan, String phoneId, String profile, String profileExpiration, String paySolution, String language, RequestListener<ProfileUpdateListResponse> listener) {
        CheckProfileUpdateRequest request = new CheckProfileUpdateRequest();
        request.setHwId(hwId);
        request.setPan(pan);
        request.setPhoneId(phoneId);
        request.setProfile(profile);
        request.setProfileExpiration(profileExpiration);
        request.setPaySolution(paySolution);
        request.setLanguage(language);

        retrofitGaRestServices.performProfileCheck(wrapUserCobToken(userToken), RetroRequestFactory.checkProfileUpdateRequest(user, request)).enqueue(new RequestCallback<>(listener));
    }

    @Override
    public void performProfileUpdate(String userToken, String user, String hwId, String pan, String phoneId, String type, String profileTimestamp, String paySolution, String nt, String lastEvent, String structEnvironmentUser, String balance, RequestListener<ProfileUpdateResponse> listener) {
        ProfileUpdateRequest request = new ProfileUpdateRequest();
        request.setHwId(hwId);
        request.setPan(pan);
        request.setPhoneId(phoneId);
        request.setProfileTimestamp(profileTimestamp);
        request.setType(type);
        request.setPaySolution(paySolution);
        request.setNt(nt);
        request.setLastEvent(lastEvent);
        request.setStructEnvironmentUser(structEnvironmentUser);
        request.setBalance(balance);

        retrofitGaRestServices.performProfileUpdate(wrapUserCobToken(userToken), RetroRequestFactory.profileUpdateRequest(user, request)).enqueue(new RequestCallback<>(listener));
    }

    @Override
    public void confirmProfileUpdate(String userToken, String user, String hwId, String pan, String phoneId, String oldProfile, String oldProfileExpiration, String timestamp, String newProfile, String newProfileExpiration, String paySolution, String nt, RequestListener<BaseResponse> listener) {
        ConfirmProfileUpdateRequest request = new ConfirmProfileUpdateRequest();
        request.setHwId(hwId);
        request.setPan(pan);
        request.setPhoneId(phoneId);
        request.setOldProfile(oldProfile);
        request.setOldProfileExpiration(oldProfileExpiration);
        request.setTimestamp(timestamp);
        request.setNewProfile(newProfile);
        request.setNewProfileExpiration(newProfileExpiration);
        request.setPaySolution(paySolution);
        request.setNt(nt);

        retrofitGaRestServices.confirmProfileUpdate(wrapUserCobToken(userToken), RetroRequestFactory.confirmProfileUpdateRequest(user, request)).enqueue(new RequestCallback<>(listener));
    }

    @Override
    public void performCardRecharge(String userToken, String user, String userId, String phoneId, String hwId, String amount, String bin, String lastDig, String cardType, final RequestListener<RechargeResponse> listener) {
        final CardRechargeRequest request = new CardRechargeRequest();
        request.setPhoneId(phoneId);
        request.setHwId(hwId);
        request.setAmount(amount);
        request.setDate(new SimpleDateFormat("dd/MM/yyyy HH:mm:ss.SSS", Locale.getDefault()).format(new Date()));
        request.setBin(bin);
        request.setLastDig(lastDig);
        request.setCardType(cardType);
        request.setUserId(userId);

        retrofitGaRestServices.performCardRecharge(wrapUserCobToken(userToken), RetroRequestFactory.cardRechargeRequest(user, request)).enqueue(new RequestCallback<>(listener));
    }

    @Override
    public void performTokenCardRecharge(String userToken, String user, String userId, String phoneId, String hwId, String amount, String bin, String lastDig, String cardType, String cardId, final RequestListener<RechargeResponse> listener) {
        final CardRechargeRequest request = new CardRechargeRequest();
        request.setPhoneId(phoneId);
        request.setHwId(hwId);
        request.setAmount(amount);
        request.setDate(new SimpleDateFormat("dd/MM/yyyy HH:mm:ss.SSS", Locale.getDefault()).format(new Date()));
        request.setBin(bin);
        request.setLastDig(lastDig);
        request.setCardType(cardType);
        request.setUserId(userId);
        request.setCardId(cardId);

        retrofitGaRestServices.performCardRecharge(wrapUserCobToken(userToken), RetroRequestFactory.cardRechargeRequest(user, request)).enqueue(new RequestCallback<>(listener));
    }

    @Override
    public void performTokenCardFinishRecharge(String userToken, String user, String userId, String phoneId, String hwId, String amount, String bin, String lastDig, String cardType, String cardId, String refundId, String fee, final RequestListener<Void> listener) {
        final CardRechargeRequest request = new CardRechargeRequest();
        request.setPhoneId(phoneId);
        request.setHwId(hwId);
        request.setAmount(amount);
        request.setDate(new SimpleDateFormat("dd/MM/yyyy HH:mm:ss.SSS", Locale.getDefault()).format(new Date()));
        request.setBin(bin);
        request.setLastDig(lastDig);
        request.setCardType(cardType);
        request.setUserId(userId);
        request.setCardId(cardId);
        request.setRefundId(refundId);
        request.setFee(fee);

        // :40380
        retrofitGaRestServices.performTokenCardFinishRecharge(wrapUserCobToken(userToken), RetroRequestFactory.tokenCardFinishRechargeRequest(user, request)).enqueue(new RequestCallback<>(listener, true));
    }

    @Override
    public void performPendingRecharge(String userToken, String user, String phoneId, String hwId, String amount, String refKey, String refType, RequestListener<RechargeResponse> listener) {
        PendingRechargeRequest request = new PendingRechargeRequest();
        request.setPhoneId(phoneId);
        request.setHwId(hwId);
        request.setAmount(amount);
        request.setDate(new SimpleDateFormat("dd/MM/yyyy HH:mm:ss.SSS", Locale.getDefault()).format(new Date()));
        request.setRefKey(refKey);
        request.setRefType(refType);

        retrofitGaRestServices.performPendingRecharge(wrapUserCobToken(userToken), RetroRequestFactory.pendingRechargeRequestRequest(user, request)).enqueue(new RequestCallback<>(listener));
    }

    @Override
    public void getPendingPayments(String userToken, String user, String phoneId, String hwId, String language, RequestListener<PendingPaymentResponse> listener) {
        PendingPaymentRequest request = new PendingPaymentRequest();
        request.setPhoneId(phoneId);
        request.setHwId(hwId);
        request.setLanguage(language);

        retrofitGaRestServices.getPendingPayments(wrapUserCobToken(userToken), RetroRequestFactory.pendingPaymentRequest(user, request)).enqueue(new RequestCallback<>(listener));
    }

    @Override
    public void getCardRechargeBalance(String userToken, String user, String phoneId, String hwId, String amount, String balance, String signature, String nt, String date, String refId, String status, CustomRequestListener<BalanceResponse, ErrorResponse<BalanceResponse>> listener) {
        BalanceRequest request = new BalanceRequest();
        request.setPhoneId(phoneId);
        request.setHwId(hwId);
        request.setAmount(amount);
        request.setBalance(balance);
        request.setSignature(signature);
        request.setNt(nt);
        request.setDate(date);
        request.setRefType(BalanceRequest.FINANCIAL);
        request.setRefId(refId);
        request.setRefStatus(status);

        getBalance(userToken, RetroRequestFactory.balanceRequest(user, request), listener);
    }

    @Override
    public void getTokenCardRechargeBalance(String userToken, String user, String phoneId, String hwId, String amount, String balance, String signature, String nt, String date, String refId, CustomRequestListener<BalanceResponse, ErrorResponse<BalanceResponse>> listener) {
        BalanceRequest request = new BalanceRequest();
        request.setPhoneId(phoneId);
        request.setHwId(hwId);
        request.setAmount(amount);
        request.setBalance(balance);
        request.setSignature(signature);
        request.setNt(nt);
        request.setDate(date);
        request.setRefType(BalanceRequest.FINANCIAL);
        request.setRefId(refId);
        request.setRefStatus(BalanceRequest.OK);

        getBalance(userToken, RetroRequestFactory.balanceRequest(user, request), listener);
    }

    @Override
    public void getPendingRechargeBalance(String userToken, String user, String phoneId, String hwId, String amount, String balance, String signature, String nt, String date, String refId, CustomRequestListener<BalanceResponse, ErrorResponse<BalanceResponse>> listener) {
        BalanceRequest request = new BalanceRequest();
        request.setPhoneId(phoneId);
        request.setHwId(hwId);
        request.setAmount(amount);
        request.setBalance(balance);
        request.setSignature(signature);
        request.setNt(nt);
        request.setDate(date);
        request.setRefType(BalanceRequest.PENDING);
        request.setRefId(refId);
        request.setRefStatus(BalanceRequest.OK);

        getBalance(userToken, user, request, listener);
    }

    private void getBalance(String userToken, String user, BalanceRequest request, CustomRequestListener<BalanceResponse, ErrorResponse<BalanceResponse>> listener) {
        getBalance(userToken, RetroRequestFactory.balanceRequest(user, request), listener);
    }

    private void getBalance(String userToken, Request<BalanceRequest> request, CustomRequestListener<BalanceResponse, ErrorResponse<BalanceResponse>> listener) {
        retrofitGaRestServices.getBalance(wrapUserCobToken(userToken), request).enqueue(new RequestCallback2<>(listener));
    }

    @Override
    public void sendTransactions(String userToken, String user, String phoneId, String hwId, String signature, List<TransactionLine> transactions, CustomRequestListener<GenericResponse, ErrorResponse<GenericResponse>> listener) {
        TransactionRequest request = new TransactionRequest();
        request.setPhoneId(phoneId);
        request.setHwId(hwId);
        request.setSignature(signature);
        request.setData(new ArrayList<>(transactions));

        retrofitGaRestServices.sendTransactions(wrapUserCobToken(userToken), RetroRequestFactory.transactionRequest(user, request)).enqueue(new RequestCallback2<>(listener));
    }

    @Override
    public void getTokenCards(String userToken, String user, String userId, String phoneId, String hwId, RequestListener<TokenCardResponse> listener) {
        TokenCardRequest request = new TokenCardRequest();
        request.setUserId(userId);
        request.setPhoneId(phoneId);
        request.setHwId(hwId);

        retrofitGaRestServices.getTokenCards(wrapUserCobToken(userToken), RetroRequestFactory.tokenCardRequest(user, request)).enqueue(new RequestCallback<>(listener));
    }

    @Override
    public void manageCard(String userToken, String user, String phoneId, String hwId, String status, String cause, String indicator, String method, RequestListener<BaseResponse> listener) {
        ManageRequest request = new ManageRequest();
        request.setPhoneId(phoneId);
        request.setHwId(hwId);
        request.setStatus(status);
        request.setCause(cause);
        request.setIndicator(indicator);
        request.setMethod(method);

        retrofitGaRestServices.manageCard(wrapUserCobToken(userToken), RetroRequestFactory.manageRequest(user, request)).enqueue(new RequestCallback<>(listener));
    }

    @Override
    public void enrollManageCard(String tokenId, String hwId, String pan, String status, String indicator, String method, RequestListener<BaseResponse> listener) {
        EnrollManageRequest request = new EnrollManageRequest();
        request.setTokenId(tokenId);
        request.setHwId(hwId);
        request.setPan(pan);
        request.setStatus(status);
        request.setIndicator(indicator);
        request.setMethod(method);

        retrofitGaRestServices.enrollManageCard(COOKIE, RetroRequestFactory.enrollManageCardRequest(request)).enqueue(new RequestCallback<>(listener));
    }

    @Override
    public void enrollManageCard(String tokenId, String hwId, String pan, RequestListener<BaseResponse> listener) {
        enrollManageCard(tokenId, hwId, pan, EnrollManageRequest.STATUS_LOCK, "", "", listener);
    }

    @Override
    public void registerPushChannel(String userToken, String user, String phoneId, String hwId, String pan, String deviceId, String connector, String osVersion, String appVersion, RequestListener<BaseResponse> listener) {
        RegisterPushChannelRequest request = new RegisterPushChannelRequest();
        request.setHwId(hwId);
        request.setPhoneId(phoneId);
        request.setPan(pan);
        request.setDeviceId(deviceId);
        request.setConnector(connector);
        request.setOsVersion(osVersion);
        request.setAppVersion(appVersion);

        retrofitGaRestServices.registerPushChannel(wrapUserCobToken(userToken), RetroRequestFactory.registerPushChannelRequest(user, request)).enqueue(new RequestCallback<>(listener));
    }

    // TODO ONLY FOR DEBUG
//    @Override
//    public void doFakeRecharge(String userToken, String user, String phoneId, String hwId, String nt, String amount, String balance, RequestListener<FakeRechargeResponse> listener) {
//        FakeRechargeRequest request = new FakeRechargeRequest();
//        request.setHwId(hwId);
//        request.setPhoneId(phoneId);
//        request.setNt(nt);
//        request.setAmount(amount);
//        request.setBalance(balance);
//
//        retrofitGaRestServices.doFakeRecharge(wrapUserCobToken(userToken), RetroRequestFactory.fakeRechargeRequestRequest(user, request)).enqueue(new RequestCallback<>(listener));
//    }
}
