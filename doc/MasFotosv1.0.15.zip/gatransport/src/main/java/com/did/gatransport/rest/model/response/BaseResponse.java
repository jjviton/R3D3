package com.did.gatransport.rest.model.response;

import com.google.gson.annotations.SerializedName;

import java.util.Map;

public class BaseResponse {
    private transient static final String KEY_STATUS = "Status";
    private transient static final String KEY_ERROR = "Error";

    @SerializedName(KEY_STATUS)
    private String status;
    @SerializedName(KEY_ERROR)
    private String error;

    public BaseResponse() {
    }

    public BaseResponse(Map<String, String> map) {
        if (map != null) {
            this.status = map.get(KEY_STATUS);
            this.error = map.get(KEY_ERROR);
        }
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getError() {
        return error;
    }

    public void setError(String error) {
        this.error = error;
    }

    public boolean isOk() {
        return status == null || status.isEmpty() || Integer.parseInt(status) == 0;
    }

    public static String[] getKeys() {
        return new String[]{KEY_STATUS, KEY_ERROR};
    }
}
