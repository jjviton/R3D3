package com.did.gacard.core.files.model;

import com.did.gacard.ecard.core.iso7816.files.EFile;
import com.google.gson.annotations.SerializedName;

import java.util.LinkedList;

public final class ContractsEFile extends EFile {

    @SerializedName("contracts")
    private LinkedList<ContractEFile> contracts = new LinkedList<>();

    public ContractsEFile() {
        super();
    }

    public ContractsEFile(ContractsEFile other) {
        super(other);
        if (other == null) return;
        for (ContractEFile contractEFile : other.contracts) {
            this.contracts.add(new ContractEFile(contractEFile));
        }
    }

    public ContractsEFile(LinkedList<ContractEFile> contracts) {
        this.contracts = contracts;
    }

    public LinkedList<ContractEFile> getContracts() {
        return contracts;
    }

    public void setContracts(LinkedList<ContractEFile> contracts) {
        this.contracts = contracts;
    }
}
