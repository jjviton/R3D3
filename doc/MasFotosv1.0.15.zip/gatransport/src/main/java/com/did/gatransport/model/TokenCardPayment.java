package com.did.gatransport.model;

import android.os.Parcel;
import android.os.Parcelable;

public final class TokenCardPayment extends Payment implements Parcelable {

    private String id;

    private String bin;

    private String last;

    private String expiration;

    public TokenCardPayment() {
    }

    public TokenCardPayment(Parcel in) {
        super(in);
        this.id = in.readString();
        this.bin = in.readString();
        this.last = in.readString();
        this.expiration = in.readString();
    }

    @Override
    public int describeContents() {
        return super.describeContents();
    }

    @Override
    public void writeToParcel(Parcel out, int flags) {
        super.writeToParcel(out, flags);
        out.writeString(id);
        out.writeString(bin);
        out.writeString(last);
        out.writeString(expiration);
    }

    public static final Creator<TokenCardPayment> CREATOR
            = new Creator<TokenCardPayment>() {
        public TokenCardPayment createFromParcel(Parcel in) {
            return new TokenCardPayment(in);
        }

        public TokenCardPayment[] newArray(int size) {
            return new TokenCardPayment[size];
        }
    };

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getBin() {
        return bin;
    }

    public void setBin(String bin) {
        this.bin = bin;
    }

    public String getLast() {
        return last;
    }

    public void setLast(String last) {
        this.last = last;
    }

    public String getExpiration() {
        return expiration;
    }

    public void setExpiration(String expiration) {
        this.expiration = expiration;
    }
}
