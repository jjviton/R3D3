package com.did.gatransport.mapper;

import com.did.gatransport.model.User;
import com.did.gatransport.store.realm.model.UserRealm;

public final class UserMapper extends Mapper<User, UserRealm, Void> {

    @Override
    public User storeToUi(UserRealm obj) {
        User user = new User();
        user.setName(obj.getName());
        user.setCardPan(obj.getCardId());
        user.setCardType(obj.getCardType());
        user.setProfileType(obj.getProfileType());
        user.setPaySolutionType(obj.getPaySolutionType());

        return user;
    }
}
