package com.did.gacard.core.files;

import com.did.gacard.GaCard;
import com.did.gacard.core.files.model.ContractEFile;
import com.did.gacard.core.files.model.EventEFile;
import com.did.gacard.core.files.model.GaAppFile;
import com.did.gacard.core.files.model.GenDataEFile;
import com.did.gacard.core.files.model.StructContract;
import com.did.gacard.core.files.model.StructContractUpdate;
import com.did.gacard.core.protocol.GaCommandFactory;
import com.did.gacard.ecard.util.ByteArray;
import com.did.gacard.ecard.util.DateParser;
import com.did.gacard.util.GaCardException;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;

import java.util.Calendar;
import java.util.Collections;
import java.util.Comparator;
import java.util.LinkedList;

public final class GaAppFileManager {

    private GaAppFileLoader gaAppFileLoader;
    private GaAppFile gaAppFile;
    private GaAppFile temp;

    public GaAppFileManager(GaAppFileLoader gaAppFileLoader) throws GaCardException {
        this.gaAppFileLoader = gaAppFileLoader;
        load();
    }

    private class AscEventComparator implements Comparator<EventEFile> {
        public int compare(EventEFile e1, EventEFile e2) {
            Integer a = ByteArray.arrayByteToInt(e1.getNt());
            Integer b = ByteArray.arrayByteToInt(e2.getNt());
            return a.compareTo(b);
        }
    }

    private class DescEventComparator implements Comparator<EventEFile> {
        public int compare(EventEFile e1, EventEFile e2) {
            Integer a = ByteArray.arrayByteToInt(e1.getNt());
            Integer b = ByteArray.arrayByteToInt(e2.getNt());
            return b.compareTo(a);
        }
    }

    public String getFormattedStringData() {
        String s = new GsonBuilder().setPrettyPrinting().create().toJson(gaAppFile);
        GaCard.getInstance().getLogger().logDebug("GaAppFileManager::getFormattedStringData", s);
        return s;
    }

    public String getStringData() {
        String s = new Gson().toJson(gaAppFile);
        GaCard.getInstance().getLogger().logDebug("GaAppFileManager::getStringData", s);
        return s;
    }

    public String getStringAid() {
        return gaAppFile.getAid();
    }

    public byte[] getAid() {
        return ByteArray.hexStringToByteArray(getStringAid());
    }

    public byte[] getNt() {
        return ByteArray.copyOf(gaAppFile.getEfNT().getNt());
    }

    public byte[] getDebitKey() {
        return gaAppFile.getEfKey().getDebitKey();
    }

    public byte[] getSerialApp() {
        return gaAppFile.getEfInfo().getSerialApp();
    }

    public LinkedList<ContractEFile> getContracts() {
        return gaAppFile.getEfContract().getContracts();
    }

    public ContractEFile getContract(int contractNumber) {
        return getContract(getContracts(), contractNumber);
    }

    private ContractEFile getContract(LinkedList<ContractEFile> contracts, int contractNumber) {
        int index = contractNumber - 1;
        if (index < 0 || index >= contracts.size())
            return null;

        return contracts.get(index);
    }

    private ContractEFile setContract(LinkedList<ContractEFile> contracts, int contractNumber, ContractEFile contract) {
        int index = contractNumber - 1;
        if (index < 0 || index >= contracts.size())
            return null;

        return contracts.set(index, contract);
    }

    public GenDataEFile getGenDataEFile() {
        return gaAppFile.getEfGenData();
    }

    public LinkedList<EventEFile> getEventsOrderedByNtAsc() {
        if (gaAppFile == null || gaAppFile.getEfEvent() == null)
            return new LinkedList<>();

        LinkedList<EventEFile> events = gaAppFile.getEfEvent().getEvents();
        Collections.sort(events, new AscEventComparator());
        return events;
    }

    public LinkedList<EventEFile> getEventsOrderedByNtDesc() {
        if (gaAppFile == null || gaAppFile.getEfEvent() == null)
            return new LinkedList<>();

        LinkedList<EventEFile> events = gaAppFile.getEfEvent().getEvents();
        Collections.sort(events, new DescEventComparator());
        return events;
    }

    public EventEFile getLastEvent() {
        LinkedList<EventEFile> events = getEventsOrderedByNtDesc();
        if (events.isEmpty())
            return null;

        return events.get(0);
    }

    public byte[] getLastEventBytesNoBitRatificationNoRfu() {
        EventEFile lastEvent = getLastEvent();
        if (lastEvent == null) return new byte[0];
        return lastEvent.getBytesNoBitRatificationNoRfu();
    }

    public EventEFile getEvent(int eventNumber) {
        LinkedList<EventEFile> events = getEventsOrderedByNtDesc();
        if (eventNumber < 0 || eventNumber >= events.size())
            return null;

        return events.get(eventNumber);
    }

    public byte[] getStructEnvironment() {
        return gaAppFile.getEfGenData().getStructEnvironment();
    }

    public byte[] getStructUser() {
        return gaAppFile.getEfGenData().getStructUser();
    }

    public byte[] getBalance() {
        return ByteArray.copyOf(gaAppFile.getEfBal().getBalance());
    }

    private void load() throws GaCardException {
        gaAppFile = recover();
        if (gaAppFile == null) throw new GaCardException("No card file.");

        checkEventListSize(gaAppFile.getEfEvent().getEvents());
        temp = null;
        GaCard.getInstance().getLogger().logDebug(new Gson().toJson(gaAppFile));
    }

    public GaAppFileManager edit() {
        if (temp == null)
            temp = new GaAppFile(gaAppFile);
        if (temp == null)
            temp = new GaAppFile();
        return this;
    }

    public GaAppFileManager rollBack() {
        temp = null;
        return edit();
    }

    public void commit() {
        if (temp == null) return;
        gaAppFile = temp;
        temp = null;
        save(gaAppFile);
    }

    private void save(GaAppFile gaAppFile) {
        if (gaAppFileLoader != null) gaAppFileLoader.save(gaAppFile);
    }

    private GaAppFile recover() {
        return gaAppFileLoader != null ? gaAppFileLoader.recover() : null;
    }

    public GaAppFileManager setNt(byte[] nt) {
        edit();
        temp.getEfNT().setNt(ByteArray.fillWithZeros(nt, 2));
        return this;
    }

    public GaAppFileManager incrementNt() {
        edit();
        byte nt[] = temp.getEfNT().getNt();
        ByteArray.increment(nt);
        temp.getEfNT().setNt(ByteArray.fillWithZeros(nt, 2));
        return this;
    }

    public GaAppFileManager add(EventEFile event) {
        edit();

        LinkedList<EventEFile> events = temp.getEfEvent().getEvents();
        // First add
        events.addLast(event);
        // Second Check Size 10
        checkEventListSize(events);

        return this;
    }

    private void checkEventListSize(LinkedList<EventEFile> events) {
        if (events == null) return;
        Collections.sort(events, new DescEventComparator());
        while (events.size() > 10) {
            events.removeLast();
        }
        while (events.size() < 10) {
            events.addLast(getEmptyEvent());
        }
    }

    private EventEFile getEmptyEvent() {
        EventEFile eventEFile = new EventEFile();
        eventEFile.setNt(ByteArray.hexStringToByteArray("00 00"));
        eventEFile.setImpEvent(ByteArray.hexStringToByteArray("00 00"));
        eventEFile.setBalEvent(ByteArray.hexStringToByteArray("00 00 00"));
        eventEFile.setTransEvent((byte) 0x00);
        eventEFile.setStructEvent(ByteArray.hexStringToByteArray("00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00"));
        eventEFile.setBitRatification((byte) 0x00);
        eventEFile.setRfu(ByteArray.hexStringToByteArray("0000"));
        return eventEFile;
    }

    public GaAppFileManager decrementUnits(byte[] decValue) {
        edit();
        byte[] balance = temp.getEfBal().getBalance();
        int iNewBalance = ByteArray.arrayByteToInt(balance) - ByteArray.arrayByteToInt(decValue);
        byte[] arNewBalance = ByteArray.fillWithZeros(ByteArray.toIntArrayByte(iNewBalance), 3);

        temp.getEfBal().setBalance(arNewBalance);
        return this;
    }

    public GaAppFileManager incrementUnits(byte[] incValue) {
        edit();
        byte[] balance = temp.getEfBal().getBalance();
        int iNewBalance = ByteArray.arrayByteToInt(balance) + ByteArray.arrayByteToInt(incValue);
        byte[] arNewBalance = ByteArray.fillWithZeros(ByteArray.toIntArrayByte(iNewBalance), 3);

        temp.getEfBal().setBalance(arNewBalance);
        return this;
    }

    public GaAppFileManager decrementContract(int contractNumber, byte[] decValue) {
        edit();
        ContractEFile contract = getContract(temp.getEfContract().getContracts(), contractNumber);
        if (contract == null) return null;

        byte counter[] = contract.getCounterContract();
        int iNewCounter = ByteArray.arrayByteToInt(counter) - ByteArray.arrayByteToInt(decValue);
        byte[] arNewCounter = ByteArray.fillWithZeros(ByteArray.toIntArrayByte(iNewCounter), 3);
        contract.setCounterContract(arNewCounter);
        return this;
    }

    public GaAppFileManager incrementContract(int contractNumber, byte[] incValue) {
        edit();
        ContractEFile contract = getContract(temp.getEfContract().getContracts(), contractNumber);
        if (contract == null) return null;

        byte counter[] = contract.getCounterContract();
        int iNewCounter = ByteArray.arrayByteToInt(counter) + ByteArray.arrayByteToInt(incValue);
        byte[] arNewCounter = ByteArray.fillWithZeros(ByteArray.toIntArrayByte(iNewCounter), 3);
        contract.setCounterContract(arNewCounter);
        return this;
    }

    public GaAppFileManager clearRatification() {
        edit();
        temp.getEfBal().setBitRatification(GaCommandFactory.RATIFICATION_DONE);
        return this;
    }

    private byte[] compressDateOnByteArray() {
        long time = System.currentTimeMillis();  // time in ms since epoch
        Calendar calendar = Calendar.getInstance();
        calendar.setTimeInMillis(time);
        int day = calendar.get(Calendar.DAY_OF_MONTH);
        int month = calendar.get(Calendar.MONTH) + 1;
        int year = calendar.get(Calendar.YEAR);
        byte[] date = DateParser.compressDateOnByteArray(calendar.get(Calendar.DAY_OF_MONTH), (calendar.get(Calendar.MONTH) + 1), calendar.get(Calendar.YEAR));
        GaCard.getInstance().getLogger().logDebug("GaAppFileManager::compressDateOnByteArray", "date: " + day + "-" + month + "-" + (year % 100) + " bytes: " + ByteArray.byteArrayToHexString(date));
        return date;
    }

    public GaAppFileManager updateContract(int contractNumber, byte[] newNt, byte[] newBalance, byte[] recharge) {
        // Usaremos los mismos códigos de terminal y entidad punto de recarga que en anteriores operaciones o dado en la perso
        ContractEFile contract = getContract(temp.getEfContract().getContracts(), contractNumber);
        if (contract == null) return null;
        try {
            // Estructura de Contrato
            StructContract structContract = new StructContract(contract.getStructContract());
            // Última actualización
            StructContractUpdate lastUpdate = new StructContractUpdate(structContract.getLastUpdate());

            byte[] terminalCode = lastUpdate.getTerminal();
            byte[] entityCode = lastUpdate.getEntity();

            // Generamos la fecha con el time stamp del momento de recarga.
            byte[] date = compressDateOnByteArray();

            return updateContract(contractNumber, newNt, newBalance, recharge, terminalCode, date, entityCode);
        } catch (Exception e) {
            GaCard.getInstance().getLogger().logError("GaAppFileManager::updateContract", "Bad Contract", e);
        }

        return null;
    }

    public GaAppFileManager updateContract(int contractNumber, byte[] newNt, byte[] newBalance, byte[] recharge, byte[] terminalCode, byte[] date, byte[] entityCode) {
        edit();
        ContractEFile contract = getContract(temp.getEfContract().getContracts(), contractNumber);

        newNt = ByteArray.fillWithZeros(newNt, 2);
        newBalance = ByteArray.fillWithZeros(newBalance, 3);
        recharge = ByteArray.fillWithZeros(recharge, 2);

        GaCard.getInstance().getLogger().logDebug("GaAppFileManager::updateContract", "Recharging: "
                + " nt: " + ByteArray.byteArrayToHexString(gaAppFile.getEfNT().getNt())
                + " newNt: " + ByteArray.byteArrayToHexString(newNt)
                + " newBalance: " + ByteArray.arrayByteToInt(newBalance) + " ( " + ByteArray.byteArrayToHexString(newBalance) + " )"
                + " recharge: " + ByteArray.arrayByteToInt(recharge) + " ( " + ByteArray.byteArrayToHexString(recharge) + " )"
                + " terminalCode: " + ByteArray.byteArrayToHexString(terminalCode)
                + " date: " + ByteArray.byteArrayToHexString(date)
                + " entityCode: " + ByteArray.byteArrayToHexString(entityCode));

        try {
            StructContract structContract = new StructContract(contract.getStructContract());
            GaCard.getInstance().getLogger().logDebug("GaAppFileManager::updateContract", "Contract Before: "
                    + "\nstruct: " + ByteArray.byteArrayToHexString(structContract.getData())
                    + "\n\tstruct.general: " + ByteArray.byteArrayToHexString(structContract.getGeneralData())
                    + "\n\tstruct.lastRecharge: " + ByteArray.byteArrayToHexString(structContract.getLastUpdate())
                    + "\n\tstruct.beforeLastRecharge: " + ByteArray.byteArrayToHexString(structContract.getBeforeLastUpdate())
                    + "\ncounter: " + ByteArray.byteArrayToHexString(contract.getCounterContract()));

            updateContract(contract, newNt, newBalance, recharge, terminalCode, date, entityCode);

            structContract = new StructContract(contract.getStructContract());
            GaCard.getInstance().getLogger().logDebug("GaAppFileManager::updateContract", "Contract After: "
                    + "\nstruct: " + ByteArray.byteArrayToHexString(structContract.getData())
                    + "\n\tstruct.general: " + ByteArray.byteArrayToHexString(structContract.getGeneralData())
                    + "\n\tstruct.lastRecharge: " + ByteArray.byteArrayToHexString(structContract.getLastUpdate())
                    + "\n\tstruct.beforeLastRecharge: " + ByteArray.byteArrayToHexString(structContract.getBeforeLastUpdate())
                    + "\ncounter: " + ByteArray.byteArrayToHexString(contract.getCounterContract()));

            return this;
        } catch (Exception e) {
            GaCard.getInstance().getLogger().logError("GaAppFileManager::updateContract", "Bad Contract", e);
        }

        return null;
    }

    private boolean updateContract(ContractEFile contract, byte[] newNt, byte[] newBalance, byte[] recharge, byte[] terminalCode, byte[] date, byte[] entityCode) {
        if (contract == null) return false;

        // Estructura de Contrato
        StructContract structContract = null;
        try {
            structContract = new StructContract(contract.getStructContract());
        } catch (Exception e) {
            GaCard.getInstance().getLogger().logError("GaAppFileManager::updateContract", "Bad Contract", e);
        }
        if (structContract == null) return false;

        // Datos generales: (11 bytes)
        // Versión de estructura de contrato    1	1 byte	01
        // Código de título	Perfil	1 byte	01
        // Indicador unidades de saldo	111 3 btis	0
        // RFU (reservado usos futuros)	No se gestiona	5 bits	0
        // Fecha inicio validez título	Fecha inicio perfil	2 bytes	00000
        // Fecha límite validez título	Fecha cad. perfil		00000
        // Zonas validez título 	*RFU- Xunta	1 byte	00
        // RFU (Reservado Futuros Usos)	No se gestiona	3 byte	000000

        // Datos última carga: (9 bytes)
        StructContractUpdate lastUpdate = null;
        try {
            lastUpdate = structContract.getStructLastUpdate();
        } catch (Exception e) {
            GaCard.getInstance().getLogger().logError("GaAppFileManager::updateContract", "Bad Contract Update", e);
        }
        if (lastUpdate == null) {
            lastUpdate = new StructContractUpdate();
        }

        // Datos nueva última carga: (9b bytes)
        StructContractUpdate newLastUpdate = new StructContractUpdate();
        try {
            // Valor cargado		2 bytes	0000
            newLastUpdate.setValue(recharge);

            // Código terminal recarga		2 bytes	0494
            newLastUpdate.setTerminal(terminalCode);

            // Fecha Adquisición		2 bytes	0000
            newLastUpdate.setDate(date);

            // Código entidad punto de recarga		1 byte	FF
            newLastUpdate.setEntity(entityCode);

            // NT última carga		2 bytes	0000
            newLastUpdate.setNT(newNt);
        } catch (Exception e) {
            GaCard.getInstance().getLogger().logError("GaAppFileManager::updateContract", "Bad Contract Update", e);
            return false;
        }

        // Guardamos la nueva última recarga.
        try {
            structContract.setLastUpdate(newLastUpdate);

            // Guardamos la antigua última recarga como la nueva penúltima.
            //        try {
            structContract.setBeforeLastUpdate(lastUpdate);
        } catch (Exception e) {
            GaCard.getInstance().getLogger().logError("GaAppFileManager::updateContract", "Bad Contract", e);
            return false;
        }

        // Guardamos la nueva estructura generada
        contract.setStructContract(structContract.getData());

        // Contador de contrato
        // Saldo	Saldo tarjeta	3 bytes	000000
        contract.setCounterContract(newBalance);

        return true;
    }

    public GaAppFileManager updateCounterContract(int contractNumber, byte[] newCounter) {
        edit();

        newCounter = ByteArray.fillWithZeros(newCounter, 3);

        ContractEFile contract = getContract(temp.getEfContract().getContracts(), contractNumber);
        if (contract == null) return null;
        // Contador de contrato
        // Saldo	Saldo tarjeta	3 bytes	000000
        contract.setCounterContract(newCounter);

        return this;
    }

    public GaAppFileManager updateGenData(byte[] structEnvironment, byte[] structUser) {
        edit();

        if (temp.getEfGenData() == null)
            return null;
        temp.getEfGenData().setStructEnvironment(structEnvironment);
        temp.getEfGenData().setStructUser(structUser);

        return this;
    }

    public GaAppFileManager updateGenDataWithEvent(byte[] structEnvironment, byte[] structUser, byte[] newEvent) {
        edit();

        if (temp.getEfGenData() == null)
            return null;
        temp.getEfGenData().setStructEnvironment(structEnvironment);
        temp.getEfGenData().setStructUser(structUser);
        temp.getEfEvent().getEvents().addFirst(new EventEFile(newEvent));

        return this;
    }

    // TODO ONLY FOR DEBUG
//    public GaAppFileManager resetState() {
//        edit();
//
//        temp.getEfNT().setNt(ByteArray.hexStringToByteArray("00 00"));
//        temp.getEfEvent().setEvents(new LinkedList<EventEFile>());
//        checkEventListSize(temp.getEfEvent().getEvents());
//
//        return this;
//    }

}
