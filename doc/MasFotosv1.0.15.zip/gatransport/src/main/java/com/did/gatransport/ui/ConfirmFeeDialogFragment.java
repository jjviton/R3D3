package com.did.gatransport.ui;

import android.app.Dialog;
import android.graphics.Typeface;
import android.os.Bundle;
import android.support.v4.app.DialogFragment;
import android.text.SpannableString;
import android.text.style.RelativeSizeSpan;
import android.text.style.StyleSpan;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import com.did.gatransport.R;

public final class ConfirmFeeDialogFragment extends DialogFragment {

    public static ConfirmFeeDialogFragment create(RechargeActivityController.BadResourcesListener badResourcesListener, String fee, MyListener listener) {
        if (badResourcesListener == null)
            return null;

        ConfirmFeeDialogFragment fragment = new ConfirmFeeDialogFragment();
        fragment.fee = fee == null ? "" : fee;
        fragment.listener = listener;
        fragment.badResourcesListener = badResourcesListener;

        return fragment;
    }

    public interface MyListener {
        void onConfirm();

        void onCancel();
    }

    private String fee;
    private MyListener listener;

    private RechargeActivityController.BadResourcesListener badResourcesListener;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setStyle(DialogFragment.STYLE_NORMAL, R.style.gatdefault_full_dialog);
    }

    @Override
    public void onStart() {
        super.onStart();
        Dialog d = getDialog();
        if (d != null) {
            if (d.getWindow() != null)
                d.getWindow().setLayout(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT);
            d.setCancelable(false);
            d.setCanceledOnTouchOutside(false);
        }
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View rootView = inflater.inflate(R.layout.gatdefault_layout_confirm_fee, container,
                false);
        if (rootView == null) {
            if (badResourcesListener != null)
                badResourcesListener.onBadResources();
            return null;
        }

        View cancelButton = rootView.findViewById(R.id.gatdefault_cancel_button);
        if (cancelButton != null) {
            cancelButton.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    if (listener != null) listener.onCancel();
                    dismiss();
                }
            });
        } else {
            if (badResourcesListener != null)
                badResourcesListener.onBadResources();
            return null;
        }

        View acceptButton = rootView.findViewById(R.id.gatdefault_accept_button);
        if (acceptButton != null) {
            acceptButton.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    if (listener != null) listener.onConfirm();
                    dismiss();
                }
            });
        } else {
            if (badResourcesListener != null)
                badResourcesListener.onBadResources();
            return null;
        }

        TextView message = rootView.findViewById(R.id.gatdefault_message_textview);
        if (message != null) {

            int feeLength = fee.length();
            String feeTextString = getString(R.string.gatdefault_fee_message_label);
            int startSpannable = feeTextString.split("%1")[0].length();

            fee = String.format(feeTextString, fee);

            SpannableString sp = new SpannableString(fee);
            sp.setSpan(new RelativeSizeSpan(2f), startSpannable, startSpannable + feeLength, 0);
            sp.setSpan(new StyleSpan(Typeface.BOLD), startSpannable, startSpannable + feeLength, 0);
            setText(message, sp);
        } else {
            if (badResourcesListener != null)
                badResourcesListener.onBadResources();
            return null;
        }

        return rootView;
    }

    private void setText(TextView t, CharSequence text) {
        if (t != null) t.setText(text != null ? text : "");
    }

}
