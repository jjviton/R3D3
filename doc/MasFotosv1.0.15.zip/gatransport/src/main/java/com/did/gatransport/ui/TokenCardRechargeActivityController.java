package com.did.gatransport.ui;

import android.content.ContextWrapper;
import android.support.annotation.NonNull;
import android.support.v4.app.DialogFragment;
import android.support.v4.app.FragmentManager;

import com.did.gatransport.R;
import com.did.gatransport.controller.CoreController;
import com.did.gatransport.controller.RechargeController;
import com.did.gatransport.interfaces.RequestListener;
import com.did.gatransport.model.Error;
import com.did.gatransport.model.TokenCardPayment;
import com.did.gatransport.model.request.TokenCardRechargeRequest;
import com.did.gatransport.model.response.TokenCardRechargeResponse;
import com.did.gatransport.rest.GaRestController;
import com.did.gatransport.rest.GaRestFactory;
import com.did.gatransport.store.GaStoreFactory;
import com.did.gatransport.store.GaStoreManager;
import com.did.gatransport.util.AmountConverter;
import com.did.gatransport.util.ErrorFactory;
import com.did.security.core.SecurityHelper;

import java.net.URL;
import java.security.InvalidParameterException;

final class TokenCardRechargeActivityController implements RechargeActivityController {

    private final int FRAG_ID_GATEWAY = 0;

    private ContextWrapper mContext;
    private FragmentManager mFragmentManager;

    private int containerViewId;

    private LoadDialogFragment loadingDialogFragment;

    private TokenCardRechargeRequest request;
    private URL host;

    private SecurityHelper securityHelper;
    private GaStoreManager storeManager;
    private GaRestController restController;

    private RechargeActivityControllerListener listener;
    private final BadResourcesListener badResourcesListener = new BadResourcesListener() {
        @Override
        public void onBadResources() {
            finishKOBadResources();
        }
    };


    private Error confirmRechargeError = null;

    private boolean finishedOK = false;

    TokenCardRechargeActivityController(@NonNull ContextWrapper context, @NonNull FragmentManager fragmentManager, int containerViewId, TokenCardRechargeRequest request, URL host, @NonNull RechargeActivityControllerListener listener) {
        this.mContext = context;
        this.mFragmentManager = fragmentManager;
        this.containerViewId = containerViewId;

        this.request = request;
        this.host = host;

        this.listener = listener;
    }

    @Override
    public boolean isFinishedOK() {
        return finishedOK;
    }

    @Override
    public Error getConfirmRechargeError() {
        return confirmRechargeError;
    }

    @Override
    public void destroy() {
        if (storeManager != null)
            storeManager.close();
    }

    private void finishOK() {
        CoreController.getLogger().logDebug("TokenCardRechargeActivityController::finishOK", "Recharge process ended OK.");
        if (listener != null) listener.onFinishOK();
    }

    private void finishKO(Error error) {
        CoreController.getLogger().logDebug("TokenCardRechargeActivityController::finishKO", "Recharge process ended KO.");
        CoreController.getLogger().logError("TokenCardRechargeActivityController::finishKO", error, "Recharge process ended KO.");
        if (listener != null) listener.onFinishKO(error);
    }

    private void finishKOBadResources() {
        finishKO(ErrorFactory.getFatalError(mContext, Error.GENERAL_INVALID_RESOURCES));
    }

    private boolean isDialogFragmentShowing(DialogFragment dialogFragment) {
        return dialogFragment != null && dialogFragment.getDialog() != null && dialogFragment.getDialog().isShowing();
    }

    private void showLoading(int idResource) {
        if (!isDialogFragmentShowing(loadingDialogFragment))
            loadingDialogFragment.show(mFragmentManager, "loginDialog");
        loadingDialogFragment.start(mContext.getString(idResource), null, false);
    }

    private void updateLoadingOK(String title, LoadDialogFragment.MyListener listener) {
        loadingDialogFragment.setListener(listener);
        loadingDialogFragment.finishOK(title, "", true);
    }

    private void updateLoadingKO(String title, Error error, boolean disableDismiss, LoadDialogFragment.MyListener listener) {
        loadingDialogFragment.setListener(listener);
        loadingDialogFragment.finishKO(title, error == null ? null : error.getMsg(), disableDismiss);
    }

    private Error validate() {
        CoreController.getLogger().logDebug("TokenCardRechargeActivityController::validate", "Validating request data.");
        if (mContext == null)
            return ErrorFactory.getGeneralContextError();
        if (mFragmentManager == null)
            return ErrorFactory.getGeneralContextError();
        if (containerViewId <= 0)
            return ErrorFactory.getFatalError(mContext, Error.GENERAL_INVALID_RESOURCES);
        if (host == null)
            return ErrorFactory.getWarnError(mContext, Error.GENERAL_INVALID_INPUT, new InvalidParameterException(String.format(mContext.getString(R.string.EXCEPTION_INVALID_INPUT), "host")));

        if (request == null)
            return ErrorFactory.getWarnError(mContext, Error.GENERAL_INVALID_INPUT, new InvalidParameterException(String.format(mContext.getString(R.string.EXCEPTION_INVALID_INPUT), "request")));

        String pwd = request.getPwd();
        int amount = -1;
        String tokeCardId = null;
        if (request.getPayment() != null) {
            amount = request.getPayment().getAmount();
            tokeCardId = request.getPayment().getId();
        }

        if (pwd == null || pwd.isEmpty()) {
            return ErrorFactory.getWarnError(mContext, Error.GENERAL_INVALID_INPUT, new InvalidParameterException(String.format(mContext.getString(R.string.EXCEPTION_INVALID_INPUT), "pwd")));
        } else if (!RechargeController.validateMinAmount(amount)) {
            return ErrorFactory.getWarnError(mContext, Error.GENERAL_INVALID_INPUT, new InvalidParameterException(mContext.getString(R.string.EXCEPTION_BAD_AMOUNT_MIN)));
        } else if (!RechargeController.validateTokenCardId(tokeCardId)) {
            return ErrorFactory.getWarnError(mContext, Error.GENERAL_INVALID_INPUT, new InvalidParameterException(String.format(mContext.getString(R.string.EXCEPTION_INVALID_INPUT), "tokeCardId")));
        } else {
            return null;
        }
    }

    @Override
    public void startProcess() {
        CoreController.getLogger().logDebug("TokenCardRechargeActivityController::startProcess", "Recharge process starting...");
        Error error = validate();
        if (error != null) {
            finishKO(error);
            return;
        }

        securityHelper = new SecurityHelper(mContext);
        storeManager = GaStoreFactory.getRealmGaStoreManager(mContext, securityHelper);
        restController = GaRestFactory.getRetrofitGaRestController(host);

        loadingDialogFragment = LoadDialogFragment.create(badResourcesListener, null);
        if (loadingDialogFragment == null) {
            finishKOBadResources();
            return;
        }

        showLoading(R.string.gatdefault_sending_request);
        CoreController.getLogger().logDebug("TokenCardRechargeActivityController::sendRequest", "First, doLogin+doSync for Authorization/Sync refresh.");
        RechargeController.doLogin(mContext, storeManager, restController, securityHelper, request.getPwd(), new RequestListener<Void>() {
            @Override
            public void onSuccess(Void response) {
                sendRequest(request.getPayment());
            }

            @Override
            public void onFailure(final Error error) {
                updateLoadingKO(mContext.getString(R.string.gatdefault_something_wrong), error, true, new LoadDialogFragment.MyListener() {
                    @Override
                    public void onConfirm(DialogFragment dialogFragment) {
                        finishKO(error);
                    }
                });
            }
        });
    }

    private void sendRequest(TokenCardPayment request) {
        showLoading(R.string.gatdefault_sending_request);
        CoreController.getLogger().logDebug("TokenCardRechargeActivityController::sendRequest", "Second, REST_Send TokenCardRechargeRequest");
        // final Context mContext, String userToken, String user, String phoneId, String hwId, final CardRechargeRequest request, final RequestListener<Bundle> listener
        RechargeController.doTokenCardRecharge(mContext, storeManager, restController, securityHelper, request, new RequestListener<TokenCardRechargeResponse>() {
            @Override
            public void onSuccess(final TokenCardRechargeResponse response) {
                final String fee = AmountConverter.getDecimalAmountString(response.getFee());
                final boolean showConfirm = response.getFee() > 0;
                if (showConfirm) {
                    CoreController.getLogger().logDebug("TokenCardRechargeActivityController::sendRequest", "Showing ConfirmDialog");
                    ConfirmFeeDialogFragment confirmDialog = ConfirmFeeDialogFragment.create(badResourcesListener, fee, new ConfirmFeeDialogFragment.MyListener() {
                        @Override
                        public void onConfirm() {
                            sendTokenCardPaymentConfirmation(response);
                        }

                        @Override
                        public void onCancel() {
                            RechargeController.doDiscardRechargeConfirmRequest(mContext, new RequestListener<Void>() {
                                @Override
                                public void onSuccess(Void response) {
                                    finishKO(ErrorFactory.getWarnError(mContext, Error.RECHARGE_CANCELED));
                                }

                                @Override
                                public void onFailure(Error error) {
                                    finishKO(error);
                                }
                            });
                        }
                    });
                    if (confirmDialog == null) {
                        RechargeController.doDiscardRechargeConfirmRequest(mContext, new RequestListener<Void>() {
                            @Override
                            public void onSuccess(Void response) {
                                finishKOBadResources();
                            }

                            @Override
                            public void onFailure(Error error) {
                                finishKO(error);
                            }
                        });
                    } else {
                        confirmDialog.show(mFragmentManager, "confirmDialog");
                    }
                } else
                    sendTokenCardPaymentConfirmation(response);
            }

            @Override
            public void onFailure(final Error error) {
                updateLoadingKO(mContext.getString(R.string.gatdefault_something_wrong), error, true, new LoadDialogFragment.MyListener() {
                    @Override
                    public void onConfirm(DialogFragment dialogFragment) {
                        finishKO(error);
                    }
                });
            }
        });
    }

    private void sendTokenCardPaymentConfirmation(TokenCardRechargeResponse request) {
        showLoading(R.string.gatdefault_gateway_confirm_recharge);
        CoreController.getLogger().logDebug("TokenCardRechargeActivityController::sendTokenCardPaymentConfirmation", "Third, REST_Send TokenCardRechargeFinishRequest.");
        RechargeController.doTokenCardFinishRecharge(mContext, storeManager, restController, securityHelper, request, new RequestListener<Void>() {
            @Override
            public void onSuccess(Void response) {
                confirmRechargeError = ErrorFactory.getFatalError(mContext, Error.RECHARGE_CANNOT_CONFIRM);
                sendConfirmation();
            }

            @Override
            public void onFailure(final Error error) {
                // Canceled Operation
                updateLoadingKO(mContext.getString(R.string.gatdefault_something_wrong), error, true, new LoadDialogFragment.MyListener() {
                    @Override
                    public void onConfirm(DialogFragment dialogFragment) {
                        finishKO(error);
                    }
                });
            }
        });
    }

    private final int MAX_CONFIRM_TRY = 3;
    private int confirmRechargeTry = 0;

    private void sendConfirmation() {
        confirmRechargeTry = 0;
        doConfirmRecharge();
    }

    private void doConfirmRecharge() {
        CoreController.getLogger().logDebug("TokenCardRechargeActivityController::doConfirmRecharge", "Fifth(Last), REST_Send PendingRechargeConfirm. Try: " + confirmRechargeTry + "/" + MAX_CONFIRM_TRY);
        confirmRechargeError = null;
        RechargeController.doConfirmRecharge(mContext, storeManager, restController, securityHelper, new RequestListener<Void>() {
            @Override
            public void onSuccess(Void response) {
                finishedOK = true;
                updateLoadingOK(mContext.getString(R.string.gatdefault_gateway_confirm_recharge_ok), new LoadDialogFragment.MyListener() {
                    @Override
                    public void onConfirm(DialogFragment dialogFragment) {
                        finishOK();
                    }
                });
            }

            @Override
            public void onFailure(Error error) {
                confirmRechargeError = error;
                if (ErrorFactory.isRechargeCannotConfirmError(confirmRechargeError)) {
                    confirmRechargeTry++;
                    updateLoadingKO(String.format(mContext.getString(R.string.gatdefault_retry_request), String.valueOf(MAX_CONFIRM_TRY - confirmRechargeTry)), confirmRechargeError, true, new LoadDialogFragment.MyListener() {
                        @Override
                        public void onConfirm(DialogFragment dialogFragment) {
                            if (confirmRechargeTry < MAX_CONFIRM_TRY) {
                                doConfirmRecharge();
                            } else {
                                finishKO(confirmRechargeError);
                            }
                        }
                    });
                } else {
                    // Canceled Operation
                    updateLoadingKO(mContext.getString(R.string.gatdefault_gateway_confirm_recharge_ko), confirmRechargeError, true, new LoadDialogFragment.MyListener() {
                        @Override
                        public void onConfirm(DialogFragment dialogFragment) {
                            finishKO(confirmRechargeError);
                        }
                    });
                }
            }
        });
    }
}
