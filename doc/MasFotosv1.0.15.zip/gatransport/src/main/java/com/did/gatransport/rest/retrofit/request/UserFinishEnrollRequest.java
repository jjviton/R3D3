package com.did.gatransport.rest.retrofit.request;

import com.google.gson.annotations.SerializedName;

public final class UserFinishEnrollRequest extends BaseFinishEnrollRequest implements FinishEnrollRequest {

    @SerializedName("User_ID")
    private String userId;

    public UserFinishEnrollRequest() {
    }

    public String getUserId() {
        return userId;
    }

    public void setUserId(String userId) {
        this.userId = userId;
    }

}
