package com.did.gatransport.store;

import android.content.ContextWrapper;
import android.os.Handler;
import android.util.Base64;

import com.did.gatransport.R;
import com.did.gatransport.controller.CoreController;
import com.did.gatransport.controller.PreferencesController;
import com.did.gatransport.controller.ProcessController;
import com.did.gatransport.interfaces.RequestListener;
import com.did.gatransport.model.Error;
import com.did.gatransport.util.ErrorFactory;
import com.did.security.core.SecurityHelper;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.util.Objects;
import java.util.UUID;

final class ImplGaStoreSecurityElement implements GaStoreSecurityElement {

    private ContextWrapper mContext;
    private SecurityHelper securityHelper;
    private final Handler mHandler;

    ImplGaStoreSecurityElement(ContextWrapper context, SecurityHelper securityHelper) {
        this.mContext = context;
        this.securityHelper = securityHelper;
        this.mHandler = new Handler(context.getMainLooper());
    }

    private String recoverDBAlias() throws Exception {
        String dbAlias;
        int tries = 3;
        do {
            dbAlias = securityHelper.getDBKey();
            tries--;
        } while (dbAlias == null && tries >= 0);
        if (dbAlias == null) {
            CoreController.getLogger().logDebug("ImplGaStoreSecurityElement::recoverDBAlias", "Impossible retrieve dbAlias.");
            throw new Exception("Impossible retrieve dbAlias.");
        }
        return dbAlias;
    }

    private byte[] getRealmKeyEncrypted(String DBKeyAlias, byte[] realmKey) throws Exception {
        byte[] realmKeyEncrypted = null;
        Exception ex = null;
        int tries = 3;
        do {
            try {
                realmKeyEncrypted = securityHelper.encrypt(DBKeyAlias, realmKey);
            } catch (Exception e) {
                ex = e;
            }
            tries--;
        } while (realmKeyEncrypted == null && tries >= 0);
        if (realmKeyEncrypted == null)
            CoreController.getLogger().logError("ImplGaStoreSecurityElement::getRealmKeyEncrypted", "Error saving dbKey.", ex);
        if (ex != null) throw ex;
        return realmKeyEncrypted;
    }

    private byte[] getDecryptRealmKey(String DBKeyAlias, String cRealmKey) throws Exception {
        byte[] decryptRealmKey = null;
        Exception ex = null;
        int tries = 3;
        do {
            try {
                decryptRealmKey = securityHelper.decrypt(DBKeyAlias, Base64.decode(cRealmKey, Base64.DEFAULT));
            } catch (Exception e) {
                ex = e;
            }
            tries--;
        } while (decryptRealmKey == null && tries >= 0);
        if (decryptRealmKey == null)
            CoreController.getLogger().logError("ImplGaStoreSecurityElement::getDecryptRealmKey", "Error recovering dbKey.", ex);
        if (ex != null) throw ex;
        return decryptRealmKey;
    }

    @Override
    public byte[] getEncryptionKey() throws Exception {
        String DBKeyAlias = recoverDBAlias();
        if (DBKeyAlias == null) {
            return null;
        }

        byte[] realmKey = null;
        String cRealmKey = PreferencesController.getInstance(mContext).getRealmKey();
        if (cRealmKey == null) {
            String sRealmKey = (UUID.randomUUID().toString() + UUID.randomUUID().toString()).substring(0, 64);
            realmKey = sRealmKey.getBytes();

            byte[] realmKeyEncrypted = getRealmKeyEncrypted(DBKeyAlias, realmKey);
            if (realmKeyEncrypted != null)
                PreferencesController.getInstance(mContext).setRealmKey(Base64.encodeToString(realmKeyEncrypted, Base64.DEFAULT));

        } else {
            byte[] decryptRealmKey = getDecryptRealmKey(DBKeyAlias, cRealmKey);
            if (decryptRealmKey != null) {
                String sRealmKey = new String(decryptRealmKey, StandardCharsets.UTF_8);
                realmKey = sRealmKey.getBytes();
            }
        }
        return realmKey;
    }

    @Override
    public boolean isValidHash(String storeFilePath) {
        try {
            return securityHelper.isSecretValid(SecurityHelper.TEXT, Objects.requireNonNull(getHash(storeFilePath)));
        } catch (Exception e) {
            CoreController.getLogger().logError("ImplGaStoreSecurityElement::isValidHash", "Realm not secure.", e);
        }
        return false;
    }

    @Override
    public boolean isValidDate(String storeFilePath) {
        try {
            return securityHelper.isSecretValid(SecurityHelper.DATE, String.valueOf(System.currentTimeMillis()));
        } catch (Exception e) {
            CoreController.getLogger().logError("ImplGaStoreSecurityElement::isValidDate", "Realm not secure.", e);
        }
        return false;
    }

    @Override
    public void updateHash(String storeFilePath) {
        try {
            securityHelper.saveSecret(SecurityHelper.TEXT, Objects.requireNonNull(getHash(storeFilePath)));
            securityHelper.saveSecret(SecurityHelper.DATE, String.valueOf(System.currentTimeMillis()));
        } catch (Exception e) {
            CoreController.getLogger().logError("ImplGaStoreSecurityElement::updateHash", "Realm not secure.", e);
        }
    }

    @Override
    public String getHash(String storeFilePath) {
        if (storeFilePath == null)
            return "";

        File f = new File(storeFilePath);
        int size = (int) f.length();
        byte[] buff = new byte[size];
        byte[] tmpBuff = new byte[size];
        FileInputStream fis = null;

        try {

            fis = new FileInputStream(f);
            int read = fis.read(buff, 0, size);
            if (read < size && read >= 0) {
                int remain = size - read;
                while (remain > 0) {
                    read = fis.read(tmpBuff, 0, remain);
                    System.arraycopy(tmpBuff, 0, buff, size - remain, read);
                    remain -= read;
                }
            }

        } catch (Exception ex) {
            CoreController.getLogger().logError("ImplGaStoreSecurityElement::getHash", "Error reading internal file.", ex);
            buff = new byte[0];
        } finally {
            try {
                if (fis != null)
                    fis.close();

            } catch (IOException e) {
                CoreController.getLogger().logError("ImplGaStoreSecurityElement::getHash", "Error closing internal file while reading.", e);
            }
        }

        return securityHelper.getMD5EncryptedString(buff);
    }

    @Override
    public void refreshEncryptionKey(final RequestListener<Void> listener) {
        Thread t = new Thread(new Runnable() {
            @Override
            public void run() {
                if (ProcessController.setRkIsRunning(true)) {
                    Exception ex = null;
                    String alias = null;
                    try {
                        alias = recoverDBAlias();
                    } catch (Exception e) {
                        ex = e;
                    }
                    final String realmKeyAlias = alias;
                    if (realmKeyAlias == null) {
                        CoreController.getLogger().logDebug("ImplGaStoreSecurityElement::refreshEncryptionKey", "Error recovering dbAlias.");
                        finishRK(listener, ErrorFactory.getNonFatalError(mContext, Error.STORE_REFRESHING_KEYS, ex));
                        return;
                    }

                    String realmKey = PreferencesController.getInstance(mContext).getRealmKey();
                    try {
                        byte[] decryptedRealmKey = securityHelper.decrypt(realmKeyAlias, Base64.decode(realmKey, Base64.DEFAULT));
                        final String sDecryptedRealmKey = new String(decryptedRealmKey, StandardCharsets.UTF_8);

                        securityHelper.refreshDBKey(new SecurityHelper.DBKeyRefreshListener() {

                            private Error errorRefreshing;

                            @Override
                            public void onKeyRefreshed(String alias) {
                                if (alias.equals(realmKeyAlias)) {
                                    try {
                                        byte[] realmKeyEncrypted = securityHelper.encrypt(realmKeyAlias, sDecryptedRealmKey.getBytes());
                                        PreferencesController.getInstance(mContext).setRealmKey(Base64.encodeToString(realmKeyEncrypted, Base64.DEFAULT));
                                    } catch (Exception e) {
                                        CoreController.getLogger().logError("ImplGaStoreSecurityElement::refreshEncryptionKey", "Error saving dbKey.", e);
                                        errorRefreshing = ErrorFactory.getFatalError(mContext, Error.STORE_REFRESHING_KEYS, e);
                                    }
                                }
                            }

                            @Override
                            public void onFinished() {
                                finishRK(listener, errorRefreshing);
                            }
                        });
                    } catch (Exception e) {
                        CoreController.getLogger().logError("ImplGaStoreSecurityElement::refreshEncryptionKey", "Error recovering dbKey.", e);
                        finishRK(listener, ErrorFactory.getFatalError(mContext, Error.STORE_REFRESHING_KEYS, e));
                    }
                } else {
                    CoreController.getLogger().logDebug("ImplGaStoreSecurityElement::refreshEncryptionKey", "RT Service Error: Its running.");
                    finishRK(listener, ErrorFactory.getNonFatalError(mContext, Error.GENERAL_PROCESS_IS_RUNNING, new IllegalStateException(mContext.getString(R.string.EXCEPTION_RT_SERVICE_RUNNING))));
                }
            }
        });
        t.setPriority(Thread.MAX_PRIORITY);
        t.start();
    }

    private void finishRK(final RequestListener<Void> listener, final Error error) {
        ProcessController.setRkIsRunning(false);
        mHandler.post(new Runnable() {
            @Override
            public void run() {
                if (listener != null) {
                    if (error == null) {
                        listener.onSuccess(null);
                    } else {
                        listener.onFailure(error);
                    }
                }
            }
        });
    }
}
