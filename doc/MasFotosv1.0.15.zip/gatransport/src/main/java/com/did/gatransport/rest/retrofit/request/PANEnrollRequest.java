package com.did.gatransport.rest.retrofit.request;

import com.google.gson.annotations.SerializedName;

public final class PANEnrollRequest extends BaseEnrollRequest implements EnrollRequest {

    @SerializedName("PAN")
    private String pan;

    public PANEnrollRequest() {
    }

    public String getPan() {
        return pan;
    }

    public void setPan(String pan) {
        this.pan = pan;
    }
}
