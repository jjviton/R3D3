package com.did.gatransport.services;

import android.content.ContextWrapper;

import com.did.gacard.services.GaAppletManager;

public final class GaAppletManagerFactory {
    public static GaAppletManager getGaCardManager(ContextWrapper context) {
        return new GaCardManager(context);
    }
}
