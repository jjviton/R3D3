package com.did.gatransport.rest.retrofit.request;

import com.did.gatransport.rest.model.TransactionLine;
import com.google.gson.annotations.SerializedName;

import java.util.ArrayList;

public final class TransactionRequest {

    @SerializedName("Phone_ID")
    private String phoneId;
    @SerializedName("HW_ID")
    private String hwId;
    @SerializedName("Signature")
    private String signature;
    @SerializedName("data")
    private ArrayList<TransactionLine> data;

    public TransactionRequest() {
    }

    public String getPhoneId() {
        return phoneId;
    }

    public void setPhoneId(String phoneId) {
        this.phoneId = phoneId;
    }

    public String getHwId() {
        return hwId;
    }

    public void setHwId(String hwId) {
        this.hwId = hwId;
    }

    public String getSignature() {
        return signature;
    }

    public void setSignature(String signature) {
        this.signature = signature;
    }

    public ArrayList<TransactionLine> getData() {
        return data;
    }

    public void setData(ArrayList<TransactionLine> data) {
        this.data = data;
    }
}
