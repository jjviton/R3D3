package com.did.gatransport.services;

import android.content.ContextWrapper;
import android.media.Ringtone;
import android.media.RingtoneManager;
import android.net.Uri;

import com.did.gacard.core.GaApplet;
import com.did.gacard.core.GaAppletEvent;
import com.did.gacard.core.files.GaAppFileManager;
import com.did.gacard.core.files.model.GaAppFile;
import com.did.gacard.core.protocol.GaSecurityCalculator;
import com.did.gacard.ecard.util.ByteArray;
import com.did.gacard.services.GaAppletManagerImpl;
import com.did.gatransport.controller.CoreController;
import com.did.gatransport.controller.PreferencesController;
import com.did.gatransport.controller.SyncController;
import com.did.gatransport.interfaces.RequestListener;
import com.did.gatransport.interfaces.TripListener;
import com.did.gatransport.mapper.TripMapper;
import com.did.gatransport.model.Error;
import com.did.gatransport.store.GaStoreFactory;
import com.did.gatransport.store.GaStoreManager;
import com.did.gatransport.store.model.GaCard;
import com.did.gatransport.store.model.Transaction;
import com.did.gatransport.store.realm.model.GaCardRealm;
import com.did.gatransport.store.realm.model.TransactionRealm;
import com.did.gatransport.store.realm.model.TripRealm;
import com.did.gatransport.util.ErrorFactory;
import com.did.security.core.SecurityHelper;
import com.google.gson.Gson;

final class GaCardManager extends GaAppletManagerImpl {

    private final Gson GSON = new Gson();

    private GaAppFile file = null;
    private final Object lock = new Object();
    private boolean ready = false;

    private ContextWrapper mContext;
    private SecurityHelper securityHelper;
    private GaStoreManager gaStoreManager;
    private TripListener tripListener;

    GaCardManager(ContextWrapper context, TripListener tripListener) {
        this.mContext = context;
        this.securityHelper = new SecurityHelper(mContext);
        this.gaStoreManager = GaStoreFactory.getRealmGaStoreManager(mContext, securityHelper);
        this.tripListener = tripListener;
    }

    GaCardManager(ContextWrapper context) {
        this(context, null);
    }

    private void checkPermission(Class... expectedCallerClasses) {
//        getStackTrace()[0] would be the call to getStackTrace itself.
//        getStackTrace()[1] would be the call to checkPermission.
//        getStackTrace()[2] would be the call to stop.
//        getStackTrace()[3] would be the method that called stop. This is what we are interested in.

//        StackTraceElement callerTrace = Thread.currentThread().getStackTrace()[3];
//        for (Class expectedClass : expectedCallerClasses) {
//            if (callerTrace.getClassName().equals(expectedClass.getName())) {
//                return;
//            }
//        }
//        throw new RuntimeException("Bad caller.");
    }

    @Override
    public void save(GaAppFile gaAppFile) {
        checkPermission(GaAppFileManager.class);
        GaCardRealm gaCardRealm = new GaCardRealm();
        gaCardRealm.setFile(GSON.toJson(gaAppFile));
        Error error = openStoreManager();
        if (error != null) {
            CoreController.getLogger().logError("GaCardManager::save", error, "[ERROR] GaCard on StorageController");
            return;
        }
        ready = false;
        gaStoreManager.insert(gaCardRealm, new RequestListener<Void>() {
            @Override
            public void onSuccess(Void response) {
                synchronized (lock) {
                    ready = true;
                    lock.notifyAll();
                }
            }

            @Override
            public void onFailure(Error error) {
                CoreController.getLogger().logError("GaCardManager::save", error, "[ERROR] GaCard on StorageController");
                synchronized (lock) {
                    ready = true;
                    lock.notifyAll();
                }
            }
        });
        synchronized (lock) {
            while (!ready) {
                try {
                    lock.wait();
                } catch (Exception e) {
                    CoreController.getLogger().logError("GaCardManager::save", "[ERROR] GaCard on save", e);
                }
            }
        }
        closeStoreManager();
    }

    @Override
    public GaAppFile recover() {
        checkPermission(GaAppFileManager.class);
        file = null;
        Error error = openStoreManager();
        if (error != null) {
            CoreController.getLogger().logError("GaCardManager::recover", error, "[ERROR] GaCard on recover");
            return file;
        }
        gaStoreManager.getGaCard(new RequestListener<GaCard>() {
            @Override
            public void onSuccess(GaCard response) {
                if (response != null) {
                    file = GSON.fromJson(response.getFile(), GaAppFile.class);
                } else {
                    CoreController.getLogger().logError("GaCardManager::recover", ErrorFactory.getWarnError(mContext, Error.CARD_LOCKED_NO_DATA), "[ERROR] GaCard on recover");
                }
                synchronized (lock) {
                    ready = true;
                    lock.notifyAll();
                }
            }

            @Override
            public void onFailure(Error error) {
                CoreController.getLogger().logError("GaCardManager::recover", error, "[ERROR] GaCard on recover");
                synchronized (lock) {
                    ready = true;
                    lock.notifyAll();
                }
            }
        });
        synchronized (lock) {
            while (!ready) {
                try {
                    lock.wait();
                } catch (Exception e) {
                    CoreController.getLogger().logError("GaCardManager::recover", "[ERROR] GaCard on recover.", e);
                }
            }
        }
        closeStoreManager();
        return file;
    }

    @Override
    public byte[] getRandom(int size) {
        checkPermission(GaSecurityCalculator.class);
        byte[] random = securityHelper.getSecretBytes(size);
        CoreController.getLogger().logDebug("GaCardManager::getRandom", "SIG rnd: " + ByteArray.byteArrayToHexString(random));
        return random;
    }

    @Override
    public void check(byte[] arr) {
        checkPermission(GaSecurityCalculator.class);
        CoreController.getLogger().logDebug("GaCardManager::check", "SIG arr: " + ByteArray.byteArrayToHexString(arr));
        try {
            securityHelper.saveSecret(SecurityHelper.FOUR_BYTES, arr);
        } catch (Exception e) {
            CoreController.getLogger().logError("GaCardManager::check", "[ERROR] GaCard on SecurityHelper", e);
        }
    }

    @Override
    public void onEvent(GaAppletEvent event) {
        checkPermission(GaApplet.class);
        if (event == null) return;

        int amount = event.getValue() * (event.isDebit() ? 1 : -1);

        TransactionRealm transactionRealm = new TransactionRealm();
        transactionRealm.setNt(event.getNt());
        transactionRealm.setBalance(event.getPosBalance());
        transactionRealm.setAmount(amount);
        transactionRealm.setDate(event.getDate());
        transactionRealm.setState(Transaction.STATE_PENDING);
        transactionRealm.setType(event.isDebit() ? TransactionRealm.TYPE_DEBIT : TransactionRealm.TYPE_CANCEL);

        final TripRealm tripRealm = new TripRealm();
        tripRealm.setAmount(amount);
        tripRealm.setDate(event.getDate());
        tripRealm.setLine(String.valueOf(event.getLine()));
        tripRealm.setType(event.isDebit() ? TripRealm.TYPE_DEBIT : TripRealm.TYPE_CANCEL);

        Error error = openStoreManager();
        if (error != null) {
            if (tripListener != null)
                tripListener.onFailure(error);
        }
        gaStoreManager.insert(transactionRealm, new RequestListener<Void>() {
            @Override
            public void onSuccess(Void response) {
                gaStoreManager.insert(tripRealm, new RequestListener<Void>() {
                    @Override
                    public void onSuccess(Void response) {
                        closeStoreManager();
                        if (tripListener != null)
                            tripListener.onSuccess(new TripMapper().storeToUi(tripRealm));
                        ringNotify();
                    }

                    @Override
                    public void onFailure(Error error) {
                        closeStoreManager();
                        if (tripListener != null)
                            tripListener.onFailure(error);
                    }
                });
            }

            @Override
            public void onFailure(Error error) {
                closeStoreManager();
                if (tripListener != null)
                    tripListener.onFailure(error);
            }
        });
    }

    @Override
    public void onSelected(byte[] aid) {
        TripListener listener = CoreController.getTripListener();
        if (listener != null)
            listener.onSelected();
    }

    @Override
    public void onDestroy(boolean hasOperated) {
        if (hasOperated) {
            final long start = System.currentTimeMillis();
            CoreController.getLogger().logDebug("GaCardManager::onEvent", "rk start!");
            gaStoreManager.refreshKey(new RequestListener<Void>() {
                @Override
                public void onSuccess(Void response) {
                    gaStoreManager.close();
                    CoreController.getLogger().logDebug("GaCardManager::onEvent", "rk ok! " + (System.currentTimeMillis() - start) + "ms");
                    SyncController.scheduleSyncDelayed(mContext);
                }

                @Override
                public void onFailure(Error error) {
                    gaStoreManager.close();
                    CoreController.getLogger().logDebug("GaCardManager::onEvent", "rk ko! " + (System.currentTimeMillis() - start) + "ms");
                    SyncController.scheduleSyncDelayed(mContext);
                }
            });
        }
    }

    private Error openStoreManager() {
        return gaStoreManager.open();
    }

    private void closeStoreManager() {
        gaStoreManager.close();
    }

    private void ringNotify() {
        if (mContext == null) return;
        if (!PreferencesController.getInstance(mContext).isRingNotificationEnabled()) return;
        try {
            Uri notification = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION);
            Ringtone r = RingtoneManager.getRingtone(mContext, notification);
            r.play();
        } catch (Exception e) {
            CoreController.getLogger().logError("GaCardManager::ringNotify", "", e);
        }
    }
}
