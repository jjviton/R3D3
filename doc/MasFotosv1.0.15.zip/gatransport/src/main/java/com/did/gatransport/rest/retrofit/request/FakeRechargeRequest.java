package com.did.gatransport.rest.retrofit.request;

import com.google.gson.annotations.SerializedName;

// TODO ONLY FOR DEBUG
public final class FakeRechargeRequest {

    @SerializedName("Phone_ID")
    private String phoneId;
    @SerializedName("HW_ID")
    private String hwId;
    @SerializedName("NT")
    private String nt;
    @SerializedName("Amount")
    private String amount;
    @SerializedName("Balance")
    private String balance;

    public String getPhoneId() {
        return phoneId;
    }

    public void setPhoneId(String phoneId) {
        this.phoneId = phoneId;
    }

    public String getHwId() {
        return hwId;
    }

    public void setHwId(String hwId) {
        this.hwId = hwId;
    }

    public String getNt() {
        return nt;
    }

    public void setNt(String nt) {
        this.nt = nt;
    }

    public String getAmount() {
        return amount;
    }

    public void setAmount(String amount) {
        this.amount = amount;
    }

    public String getBalance() {
        return balance;
    }

    public void setBalance(String balance) {
        this.balance = balance;
    }
}
