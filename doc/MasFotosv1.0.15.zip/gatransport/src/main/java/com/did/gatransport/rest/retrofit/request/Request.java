package com.did.gatransport.rest.retrofit.request;

import com.google.gson.annotations.SerializedName;

public final class Request<T> {

    @SerializedName("product")
    private String product;
    @SerializedName("type")
    private String type;
    @SerializedName("user")
    private String user;
    @SerializedName("action")
    private String action;
    @SerializedName("values")
    private T value;

    public Request() {
    }

    public Request(T value) {
        this.value = value;
    }

    public String getProduct() {
        return product;
    }

    public void setProduct(String product) {
        this.product = product;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public String getUser() {
        return user;
    }

    public void setUser(String user) {
        this.user = user;
    }

    public String getAction() {
        return action;
    }

    public void setAction(String action) {
        this.action = action;
    }

    public T getValue() {
        return value;
    }

    public void setValue(T value) {
        this.value = value;
    }
}
