package com.did.gatransport.model.request;

public final class LoginRequest {

    private String user;
    private String pwd;

    public String getUser() {
        return user;
    }

    public LoginRequest() {
    }

    public LoginRequest(String user, String pwd) {
        this.user = user;
        this.pwd = pwd;
    }

    public void setUser(String user) {
        this.user = user;
    }

    public String getPwd() {
        return pwd;
    }

    public void setPwd(String pwd) {
        this.pwd = pwd;
    }
}
