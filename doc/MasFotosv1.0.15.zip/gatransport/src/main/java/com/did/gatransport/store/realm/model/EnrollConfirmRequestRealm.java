package com.did.gatransport.store.realm.model;

import com.did.gatransport.store.model.EnrollConfirmRequest;

import io.realm.annotations.PrimaryKey;

@Deprecated
public class EnrollConfirmRequestRealm implements EnrollConfirmRequest {

    @PrimaryKey
    private long id;

    private String hwId;

    private String cardId;

    private String tokenId;

    private String phoneId;

    public EnrollConfirmRequestRealm() {
    }

    public EnrollConfirmRequestRealm(String hwId, String cardId, String tokenId, String phoneId) {
        this.hwId = hwId;
        this.cardId = cardId;
        this.tokenId = tokenId;
        this.phoneId = phoneId;
    }

    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    @Override
    public String getHwId() {
        return hwId;
    }

    @Override
    public void setHwId(String hwId) {
        this.hwId = hwId;
    }

    @Override
    public String getCardId() {
        return cardId;
    }

    @Override
    public void setCardId(String cardId) {
        this.cardId = cardId;
    }

    @Override
    public String getTokenId() {
        return tokenId;
    }

    @Override
    public void setTokenId(String tokenId) {
        this.tokenId = tokenId;
    }

    @Override
    public String getPhoneId() {
        return phoneId;
    }

    @Override
    public void setPhoneId(String phoneId) {
        this.phoneId = phoneId;
    }
}
