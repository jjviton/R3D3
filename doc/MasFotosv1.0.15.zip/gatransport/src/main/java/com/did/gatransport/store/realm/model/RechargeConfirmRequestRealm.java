package com.did.gatransport.store.realm.model;

import com.did.gatransport.store.model.RechargeConfirmRequest;

import io.realm.RealmObject;
import io.realm.annotations.PrimaryKey;

public class RechargeConfirmRequestRealm extends RealmObject implements RechargeConfirmRequest {

    @PrimaryKey
    private long id;

    private int type;
    private long date;
    private String refId;
    private int amount;
    private String lastDig;
    private String status;

    public RechargeConfirmRequestRealm() {
    }

    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    @Override
    public int getType() {
        return type;
    }

    @Override
    public void setType(int type) {
        this.type = type;
    }

    @Override
    public long getDate() {
        return date;
    }

    @Override
    public void setDate(long date) {
        this.date = date;
    }

    @Override
    public String getRefId() {
        return refId;
    }

    @Override
    public void setRefId(String refId) {
        this.refId = refId;
    }

    @Override
    public int getAmount() {
        return amount;
    }

    @Override
    public void setAmount(int amount) {
        this.amount = amount;
    }

    @Override
    public String getLastDig() {
        return lastDig;
    }

    @Override
    public void setLastDig(String lastDig) {
        this.lastDig = lastDig;
    }

    @Override
    public String getStatus() {
        return status;
    }

    @Override
    public void setStatus(String status) {
        this.status = status;
    }
}

