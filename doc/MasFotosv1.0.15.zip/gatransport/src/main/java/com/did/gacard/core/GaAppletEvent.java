package com.did.gacard.core;

public final class GaAppletEvent {

    private int nt;
    private int value;
    private int preBalance;
    private int posBalance;
    private int type;
    private int contract;
    private int direction;
    private int transaction;
    private int operator;
    private int title;
    private int line;
    private int manager;
    private long date;
    private int trips;
    private int bonusTrips;
    private int currency;
    private int flatRate;
    private int area;
    private int origin;
    private int destination;
    private int originTownHall;
    private int destinationTownHall;

    public GaAppletEvent() {
    }

    public int getNt() {
        return nt;
    }

    public void setNt(int nt) {
        this.nt = nt;
    }

    public int getValue() {
        return value;
    }

    public void setValue(int amount) {
        this.value = amount;
    }

    public int getPreBalance() {
        return preBalance;
    }

    public void setPreBalance(int preBalance) {
        this.preBalance = preBalance;
    }

    public int getPosBalance() {
        return posBalance;
    }

    public void setPosBalance(int posBalance) {
        this.posBalance = posBalance;
    }

    public int getType() {
        return type;
    }

    public void setType(int type) {
        this.type = type;
    }

    public int getContract() {
        return contract;
    }

    public void setContract(int contract) {
        this.contract = contract;
    }

    public int getDirection() {
        return direction;
    }

    public void setDirection(int direction) {
        this.direction = direction;
    }

    public int getTransaction() {
        return transaction;
    }

    public void setTransaction(int transaction) {
        this.transaction = transaction;
    }

    public int getOperator() {
        return operator;
    }

    public void setOperator(int operator) {
        this.operator = operator;
    }

    public int getTitle() {
        return title;
    }

    public void setTitle(int title) {
        this.title = title;
    }

    public int getLine() {
        return line;
    }

    public void setLine(int line) {
        this.line = line;
    }

    public int getManager() {
        return manager;
    }

    public void setManager(int manager) {
        this.manager = manager;
    }

    public long getDate() {
        return date;
    }

    public void setDate(long date) {
        this.date = date;
    }

    public int getTrips() {
        return trips;
    }

    public void setTrips(int trips) {
        this.trips = trips;
    }

    public int getBonusTrips() {
        return bonusTrips;
    }

    public void setBonusTrips(int bonusTrips) {
        this.bonusTrips = bonusTrips;
    }

    public int getCurrency() {
        return currency;
    }

    public void setCurrency(int currency) {
        this.currency = currency;
    }

    public int getFlatRate() {
        return flatRate;
    }

    public void setFlatRate(int flatRate) {
        this.flatRate = flatRate;
    }

    public int getArea() {
        return area;
    }

    public void setArea(int area) {
        this.area = area;
    }

    public int getOrigin() {
        return origin;
    }

    public void setOrigin(int origin) {
        this.origin = origin;
    }

    public int getDestination() {
        return destination;
    }

    public void setDestination(int destination) {
        this.destination = destination;
    }

    public int getOriginTownHall() {
        return originTownHall;
    }

    public void setOriginTownHall(int originTownHall) {
        this.originTownHall = originTownHall;
    }

    public int getDestinationTownHall() {
        return destinationTownHall;
    }

    public void setDestinationTownHall(int destinationTownHall) {
        this.destinationTownHall = destinationTownHall;
    }

    // Check type Debit=1 or Cancel = 0
    public boolean isDebit() {
        return type == 1;
    }

    // Check type Debit=1 or Cancel = 0
    public boolean isCancel() {
        return type == 0;
    }
}
