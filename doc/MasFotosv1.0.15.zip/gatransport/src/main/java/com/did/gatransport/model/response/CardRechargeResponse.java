package com.did.gatransport.model.response;

public final class CardRechargeResponse {

    private int fee;

    private String form;

    public CardRechargeResponse() {
    }

    public int getFee() {
        return fee;
    }

    public void setFee(int fee) {
        this.fee = fee;
    }

    public String getForm() {
        return form;
    }

    public void setForm(String form) {
        this.form = form;
    }

}
