package com.did.gacard.core.files.model;

import com.did.gacard.ecard.core.iso7816.files.EFile;
import com.did.gacard.ecard.util.ByteArray;
import com.google.gson.annotations.SerializedName;

public final class KeyEFile extends EFile {

    @SerializedName("admin")
    private byte[] adminKey;
    @SerializedName("charge")
    private byte[] chargeKey;
    @SerializedName("debit")
    private byte[] debitKey;

    public KeyEFile() {
        super();
    }

    public KeyEFile(KeyEFile other) {
        super(other);
        if (other == null) return;
        this.adminKey = ByteArray.copyOf(other.adminKey);
        this.chargeKey = ByteArray.copyOf(other.chargeKey);
        this.debitKey = ByteArray.copyOf(other.debitKey);
    }

    public byte[] getAdminKey() {
        return adminKey;
    }

    public void setAdminKey(byte[] adminKey) {
        this.adminKey = adminKey;
    }

    public byte[] getChargeKey() {
        return chargeKey;
    }

    public void setChargeKey(byte[] chargeKey) {
        this.chargeKey = chargeKey;
    }

    public byte[] getDebitKey() {
        return debitKey;
    }

    public void setDebitKey(byte[] debitKey) {
        this.debitKey = debitKey;
    }
}

