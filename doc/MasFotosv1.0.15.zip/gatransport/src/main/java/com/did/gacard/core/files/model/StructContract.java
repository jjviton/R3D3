package com.did.gacard.core.files.model;

import com.did.gacard.ecard.util.ByteArray;

public final class StructContract {

    private static final int OFFSET_GENERALDATA = 0;
    private static final int LENGTH_GENERALDATA = 11;
    private static final int OFFSET_LASTUPDATE = OFFSET_GENERALDATA + LENGTH_GENERALDATA;
    private static final int LENGTH_LASTUPDATE = 9;
    private static final int OFFSET_BEFORELASTUPDATE = OFFSET_LASTUPDATE + LENGTH_LASTUPDATE;
    private static final int LENGTH_BEFORELASTUPDATE = 9;

    private static final int LENGTH = OFFSET_BEFORELASTUPDATE + LENGTH_BEFORELASTUPDATE;

    private byte[] data;

    public StructContract() {
        this.data = new byte[LENGTH];
    }

    public StructContract(byte[] data) throws Exception {
        if (data == null) throw new Exception("StructContract: Cannot be NULL.");
        if (data.length != LENGTH) throw new Exception("StructContract: Invalid length.");
        this.data = data;
    }

    public byte[] getData() {
        return data;
    }

    public byte[] getGeneralData() {
        // Datos generales: (11 bytes)
        // Versión de estructura de contrato    1	1 byte	01
        // Código de título	Perfil	1 byte	01
        // Indicador unidades de saldo	111 3 btis	0
        // RFU (reservado usos futuros)	No se gestiona	5 bits	0
        // Fecha inicio validez título	Fecha inicio perfil	2 bytes	00000
        // Fecha límite validez título	Fecha cad. perfil		00000
        // Zonas validez título 	*RFU- Xunta	1 byte	00
        // RFU (Reservado Futuros Usos)	No se gestiona	3 byte	000000
        return ByteArray.getBytes(data, OFFSET_GENERALDATA, LENGTH_GENERALDATA);
    }

    public void setGeneralData(byte[] generalData) throws Exception {
        if (generalData == null) throw new Exception("GeneralData: Cannot be NULL.");
        if (generalData.length != LENGTH_GENERALDATA)
            throw new Exception("GeneralData: Invalid length.");
        ByteArray.fillBytes(data, OFFSET_GENERALDATA, generalData);
    }

    public byte[] getLastUpdate() {
        // Datos carga: (9 bytes)
        // Valor cargado		2 bytes	0000
        // Código terminal recarga		2 bytes	0494
        // Fecha Adquisición		2 bytes	0000
        // Código entidad punto de recarga		1 byte	FF
        // NT última carga		2 bytes	0000
        return ByteArray.getBytes(data, OFFSET_LASTUPDATE, LENGTH_LASTUPDATE);
    }

    public void setLastUpdate(byte[] lastUpdate) throws Exception {
        if (lastUpdate == null) throw new Exception("LastUpdate: Cannot be NULL.");
        if (lastUpdate.length != LENGTH_LASTUPDATE)
            throw new Exception("LastUpdate: Invalid length.");
        ByteArray.fillBytes(data, OFFSET_LASTUPDATE, lastUpdate);
    }

    public byte[] getBeforeLastUpdate() {
        // Datos carga: (9 bytes)
        // Valor cargado		2 bytes	0000
        // Código terminal recarga		2 bytes	0494
        // Fecha Adquisición		2 bytes	0000
        // Código entidad punto de recarga		1 byte	FF
        // NT última carga		2 bytes	0000
        return ByteArray.getBytes(data, OFFSET_BEFORELASTUPDATE, LENGTH_BEFORELASTUPDATE);
    }

    public void setBeforeLastUpdate(byte[] beforeLastUpdate) throws Exception {
        if (beforeLastUpdate == null) throw new Exception("BeforeLastUpdate: Cannot be NULL.");
        if (beforeLastUpdate.length != LENGTH_BEFORELASTUPDATE)
            throw new Exception("BeforeLastUpdate: Invalid length.");
        ByteArray.fillBytes(data, OFFSET_BEFORELASTUPDATE, beforeLastUpdate);
    }

    public StructContractUpdate getStructLastUpdate() throws Exception {
        return new StructContractUpdate(getLastUpdate());
    }

    public void setLastUpdate(StructContractUpdate lastUpdate) throws Exception {
        setLastUpdate(lastUpdate.getData());
    }

    public StructContractUpdate getStructBeforeLastUpdate() throws Exception {
        return new StructContractUpdate(getBeforeLastUpdate());
    }

    public void setBeforeLastUpdate(StructContractUpdate beforeLastUpdate) throws Exception {
        setBeforeLastUpdate(beforeLastUpdate.getData());
    }

}
