package com.did.gatransport.model.request;

import android.os.Parcel;
import android.os.Parcelable;

import com.did.gatransport.model.CardPayment;

public final class CardRechargeRequest extends RechargeRequest<CardPayment> implements Parcelable {

    public CardRechargeRequest() {
    }

    public CardRechargeRequest(String pwd, CardPayment payment) {
        super(pwd, payment);
    }

    public CardRechargeRequest(Parcel in) {
        super(in);
    }

    @Override
    CardPayment getPaymentFromParcel(Parcel in) {
        return in.readParcelable(CardPayment.class.getClassLoader());
    }

    public static final Parcelable.Creator<CardRechargeRequest> CREATOR
            = new Parcelable.Creator<CardRechargeRequest>() {
        public CardRechargeRequest createFromParcel(Parcel in) {
            return new CardRechargeRequest(in);
        }

        public CardRechargeRequest[] newArray(int size) {
            return new CardRechargeRequest[size];
        }
    };

}
