package com.did.gatransport.rest.model.response;

import com.google.gson.annotations.SerializedName;

// TODO ONLY FOR DEBUG
final class FakeRechargeResponse extends BaseResponse {
    @SerializedName("Signature")
    private byte[] signature;

    public byte[] getSignature() {
        return signature;
    }

    public void setSignature(byte[] signature) {
        this.signature = signature;
    }
}
