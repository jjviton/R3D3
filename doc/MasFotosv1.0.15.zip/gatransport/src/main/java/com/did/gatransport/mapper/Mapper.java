package com.did.gatransport.mapper;

public class Mapper<U, S, R> {

    public S uiToStore(U obj) {
        return null;
    }


    public U storeToUi(S obj) {
        return null;
    }


    public S restToStore(R obj) {
        return null;
    }


    public R storeToRest(S obj) {
        return null;
    }


    public R uiToRest(U obj) {
        return null;
    }

    public U restToUi(R obj) {
        return null;
    }

}
