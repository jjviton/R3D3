package com.did.gacard.core.files.model;

import com.did.gacard.ecard.core.iso7816.files.EFile;
import com.did.gacard.ecard.util.ByteArray;
import com.google.gson.annotations.SerializedName;

public final class NtEFile extends EFile {

    @SerializedName("nt")
    private byte[] nt;

    public NtEFile() {
        super();
    }

    public NtEFile(NtEFile other) {
        super(other);
        if (other == null) return;
        this.nt = ByteArray.copyOf(other.nt);
    }

    public byte[] getNt() {
        return nt;
    }

    public void setNt(byte[] nt) {
        this.nt = nt;
    }
}
