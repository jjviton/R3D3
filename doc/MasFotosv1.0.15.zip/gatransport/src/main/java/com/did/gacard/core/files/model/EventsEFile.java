package com.did.gacard.core.files.model;

import com.did.gacard.ecard.core.iso7816.files.EFile;
import com.google.gson.annotations.SerializedName;

import java.util.LinkedList;

public final class EventsEFile extends EFile {

    @SerializedName("events")
    private LinkedList<EventEFile> events = new LinkedList<>();

    public EventsEFile() {
        super();
    }

    public EventsEFile(EventsEFile other) {
        super(other);
        if (other == null) return;
        for (EventEFile eventEFile : other.events) {
            this.events.add(new EventEFile(eventEFile));
        }
    }

    public EventsEFile(LinkedList<EventEFile> events) {
        this.events = events;
    }

    public LinkedList<EventEFile> getEvents() {
        return events;
    }

    public void setEvents(LinkedList<EventEFile> events) {
        this.events = events;
    }
}
