package com.did.gatransport.rest.retrofit.request;

import com.google.gson.annotations.SerializedName;

public class BaseRechargeRequest implements RechargeRequest {

    @SerializedName("Phone_ID")
    private String phoneId;
    @SerializedName("HW_ID")
    private String hwId;
    @SerializedName("Amount")
    private String amount;
    @SerializedName("Date")
    private String date;

    public BaseRechargeRequest() {
    }

    @Override
    public String getPhoneId() {
        return phoneId;
    }

    @Override
    public void setPhoneId(String phoneId) {
        this.phoneId = phoneId;
    }

    @Override
    public String getHwId() {
        return hwId;
    }

    @Override
    public void setHwId(String hwId) {
        this.hwId = hwId;
    }

    @Override
    public String getAmount() {
        return amount;
    }

    @Override
    public void setAmount(String amount) {
        this.amount = amount;
    }

    @Override
    public String getDate() {
        return date;
    }

    @Override
    public void setDate(String date) {
        this.date = date;
    }
}
