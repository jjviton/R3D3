package com.did.gacard.core.files.model;

import com.did.gacard.ecard.util.ByteArray;

public final class StructContractUpdate {

    private static final int OFFSET_VALUE = 0;
    private static final int LENGTH_VALUE = 2;
    private static final int OFFSET_TERMINAL = OFFSET_VALUE + LENGTH_VALUE;
    private static final int LENGTH_TERMINAL = 2;
    private static final int OFFSET_DATE = OFFSET_TERMINAL + LENGTH_TERMINAL;
    private static final int LENGTH_DATE = 2;
    private static final int OFFSET_ENTITY = OFFSET_DATE + LENGTH_DATE;
    private static final int LENGTH_ENTITY = 1;
    private static final int OFFSET_NT = OFFSET_ENTITY + LENGTH_ENTITY;
    private static final int LENGTH_NT = 2;

    private static final int LENGTH = OFFSET_NT + LENGTH_NT;

    private byte[] data;

    public StructContractUpdate() {
        this.data = new byte[LENGTH];
    }

    public StructContractUpdate(byte[] data) throws Exception {
        if (data == null) throw new Exception("StructContractUpdate: Cannot be NULL.");
        if (data.length != LENGTH) throw new Exception("StructContractUpdate: Invalid length.");
        this.data = data;
    }

    public byte[] getData() {
        // Datos carga: (9 bytes)
        // Valor cargado		2 bytes	0000
        // Código terminal recarga		2 bytes	0494
        // Fecha Adquisición		2 bytes	0000
        // Código entidad punto de recarga		1 byte	FF
        // NT última carga		2 bytes	0000
        return data;
    }

    public byte[] getValue() {
        return ByteArray.getBytes(data, OFFSET_VALUE, LENGTH_VALUE);
    }

    public void setValue(byte[] value) throws Exception {
        if (value == null) throw new Exception("Value: Cannot be NULL.");
        if (value.length != LENGTH_VALUE) throw new Exception("Value: Invalid length.");
        ByteArray.fillBytes(data, OFFSET_VALUE, value);
    }

    public byte[] getTerminal() {
        return ByteArray.getBytes(data, OFFSET_TERMINAL, LENGTH_TERMINAL);
    }

    public void setTerminal(byte[] terminal) throws Exception {
        if (terminal == null) throw new Exception("Value: Cannot be NULL.");
        if (terminal.length != LENGTH_TERMINAL) throw new Exception("Value: Invalid length.");
        ByteArray.fillBytes(data, OFFSET_TERMINAL, terminal);
    }

    public byte[] getDate() {
        return ByteArray.getBytes(data, OFFSET_DATE, LENGTH_DATE);
    }

    public void setDate(byte[] date) throws Exception {
        if (date == null) throw new Exception("Date: Cannot be NULL.");
        if (date.length != LENGTH_DATE) throw new Exception("Date: Invalid length.");
        ByteArray.fillBytes(data, OFFSET_DATE, date);
    }

    public byte[] getEntity() {
        return ByteArray.getBytes(data, OFFSET_ENTITY, LENGTH_ENTITY);
    }

    public void setEntity(byte[] entity) throws Exception {
        if (entity == null) throw new Exception("Entity: Cannot be NULL.");
        if (entity.length != LENGTH_ENTITY) throw new Exception("Entity: Invalid length.");
        ByteArray.fillBytes(data, OFFSET_ENTITY, entity);
    }

    public byte[] getNT() {
        return ByteArray.getBytes(data, OFFSET_NT, LENGTH_NT);
    }

    public void setNT(byte[] nt) throws Exception {
        if (nt == null) throw new Exception("NT: Cannot be NULL.");
        if (nt.length != LENGTH_NT) throw new Exception("NT: Invalid length.");
        ByteArray.fillBytes(data, OFFSET_NT, nt);
    }
}
