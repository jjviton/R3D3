package com.did.gatransport.rest.model.response;

import com.did.gatransport.rest.model.ProfileUpdate;
import com.google.gson.annotations.SerializedName;

import java.util.ArrayList;

public final class ProfileUpdateListResponse extends BaseResponse {

    @SerializedName("Profile_change_list")
    private ArrayList<ProfileUpdate> profileUpdates;

    public ProfileUpdateListResponse() {
    }

    public ArrayList<ProfileUpdate> getProfileUpdates() {
        return profileUpdates;
    }

    public void setProfileUpdates(ArrayList<ProfileUpdate> profileUpdates) {
        this.profileUpdates = profileUpdates;
    }
}
