package com.did.gatransport.rest.retrofit.request;

import com.google.gson.annotations.SerializedName;

public final class OTPFinishEnrollRequest extends BaseFinishEnrollRequest implements FinishEnrollRequest {

    @SerializedName("Token_ID")
    private String tokenId;
    @SerializedName("Request_ID")
    private String requestId;
    @SerializedName("OTP")
    private String otp;

    public OTPFinishEnrollRequest() {
    }

    public String getTokenId() {
        return tokenId;
    }

    public void setTokenId(String tokenId) {
        this.tokenId = tokenId;
    }

    public String getRequestId() {
        return requestId;
    }

    public void setRequestId(String requestId) {
        this.requestId = requestId;
    }

    public String getOtp() {
        return otp;
    }

    public void setOtp(String otp) {
        this.otp = otp;
    }
}
