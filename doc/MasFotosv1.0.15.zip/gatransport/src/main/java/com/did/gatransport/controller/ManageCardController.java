package com.did.gatransport.controller;

import android.content.ContextWrapper;

import com.did.gatransport.R;
import com.did.gatransport.interfaces.CardHostErrorChainRequestListener;
import com.did.gatransport.interfaces.RequestListener;
import com.did.gatransport.model.Error;
import com.did.gatransport.model.request.ManageCardRequest;
import com.did.gatransport.model.request.RegisterPushChannelRequest;
import com.did.gatransport.rest.GaRestController;
import com.did.gatransport.rest.model.response.BaseResponse;
import com.did.gatransport.store.GaStoreManager;
import com.did.gatransport.store.model.User;
import com.did.gatransport.util.ErrorFactory;
import com.did.security.core.SecurityHelper;

import java.security.InvalidParameterException;

final class ManageCardController {

    private static boolean isRunning = false;

    private static boolean checkIsRunning(ContextWrapper context, RequestListener listener) {
        if (isRunning) {
            finishKO(ErrorFactory.getWarnError(context, Error.GENERAL_PROCESS_IS_RUNNING), listener);
            return true;
        }
        return false;
    }

    private static void finishKO(Error error, RequestListener listener) {
        isRunning = false;

        CoreController.getLogger().logDebug("ManageCardController::finishKO", "ManageCard Process KO END");
        CoreController.getLogger().logError("ManageCardController::finishKO", error, "ManageCard Process KO END");

        if (listener != null)
            listener.onFailure(error);
    }

    static void manageCard(final ContextWrapper context, final ManageCardRequest request, final String hwId, final GaStoreManager storeManager, final GaRestController restController, final SecurityHelper securityHelper, final RequestListener<Void> listener) {
        CoreController.getLogger().logDebug("ManageCardController::manageCard", "ManageCard Process START");
        if (checkIsRunning(context, listener)) return;

        if (request == null) {
            finishKO(ErrorFactory.getWarnError(context, Error.GENERAL_INVALID_INPUT), listener);
            return;
        }

        if (request.getUser() == null || request.getUser().trim().isEmpty()) {
            finishKO(ErrorFactory.getWarnError(context, Error.GENERAL_INVALID_INPUT, new Exception(String.format(context.getString(R.string.EXCEPTION_INVALID_INPUT), "user"))), listener);
            return;
        }

        if (request.getPwd() == null || request.getPwd().trim().isEmpty()) {
            finishKO(ErrorFactory.getWarnError(context, Error.GENERAL_INVALID_INPUT, new Exception(String.format(context.getString(R.string.EXCEPTION_INVALID_INPUT), "pwd"))), listener);
            return;
        }

        if (request.getStatus() == null || request.getStatus().isEmpty()) {
            finishKO(ErrorFactory.getWarnError(context, Error.GENERAL_INVALID_INPUT, new Exception(String.format(context.getString(R.string.EXCEPTION_INVALID_INPUT), "status"))), listener);
            return;
        }

        // Check obligatory fields Indicator + Method if Status == 03
        if (ManageCardRequest.STATUS_UNSUBSCRIBE.equalsIgnoreCase(request.getStatus())) {
            if (request.getIndicator() == null || request.getIndicator().isEmpty()) {
                finishKO(ErrorFactory.getWarnError(context, Error.GENERAL_INVALID_INPUT, new Exception(String.format(context.getString(R.string.EXCEPTION_INVALID_INPUT), "indicator"))), listener);
                return;
            }
//            if (request.getMethod() == null || request.getMethod().isEmpty()) {
//                finishKO(ErrorFactory.getWarnError(context, Error.GENERAL_INVALID_INPUT, new Exception(String.format(context.getString(R.string.EXCEPTION_INVALID_INPUT), "Method"))), listener);
//                return;
//            }
        }

        isRunning = true;

        CoreController.getLogger().logDebug("ManageCardController::manageCard", "First, doLogin for Authorization refresh.");
        LoginController.login(context, storeManager, restController, request.getUser(), request.getPwd(), new RequestListener<Void>() {
            @Override
            public void onSuccess(Void response) {
                CoreController.getLogger().logDebug("ManageCardController::manageCard", "Second, doSync.");
                sync(context, storeManager, restController, securityHelper, new RequestListener<Void>() {
                    @Override
                    public void onSuccess(final Void response) {
                        storeManager.getUser(new RequestListener<User>() {
                            @Override
                            public void onSuccess(final User user) {
                                if (user != null) {
                                    String userName = user.getName();
                                    String userToken = user.getToken();
                                    String phoneId = user.getPhoneId();
                                    // (String userToken, String user, String phoneId, String hwId, String status, String cause, String indicator, String method, RequestListener<BaseResponse> listener);
                                    CoreController.getLogger().logDebug("ManageCardController::manageCard", "Third, REST_Send ManageCardRequest.");
                                    restController.manageCard(userToken, userName, phoneId, hwId, request.getStatus(), request.getCause(), request.getIndicator(), request.getMethod(), new CardHostErrorChainRequestListener<>(context, storeManager, restController, securityHelper, new RequestListener<BaseResponse>() {
                                        @Override
                                        public void onSuccess(BaseResponse response) {
                                            CoreController.getLogger().logDebug("ManageCardController::manageCard", "Fourth(Last), DB_Delete ALL.");
                                            deleteAll(context, storeManager);

                                            isRunning = false;

                                            if (listener != null)
                                                listener.onSuccess(null);
                                        }

                                        @Override
                                        public void onFailure(Error error) {
                                            finishKO(error, listener);
                                        }
                                    }));
                                } else {
                                    finishKO(ErrorFactory.getWarnError(context, Error.GENERAL_USER_NOT_EXISTS), listener);
                                }
                            }

                            @Override
                            public void onFailure(Error error) {
                                finishKO(error, listener);
                            }
                        });
                    }

                    @Override
                    public void onFailure(Error error) {
                        finishKO(error, listener);
                    }
                });
            }

            @Override
            public void onFailure(Error error) {
                finishKO(error, listener);
            }
        });
    }

    static void deleteAll(ContextWrapper context, GaStoreManager storeManager) {
        PreferencesController.getInstance(context).removePreferences();
        storeManager.reset();
    }

    private static void sync(final ContextWrapper context, final GaStoreManager storeManager, GaRestController restController, SecurityHelper securityHelper, final RequestListener<Void> listener) {
        SyncController.sync(context, storeManager, restController, securityHelper, new RequestListener<Void>() {
            @Override
            public void onSuccess(Void response) {
                if (listener != null)
                    listener.onSuccess(null);
            }

            @Override
            public void onFailure(Error error) {
                finishKO(error, listener);
            }
        });
    }

    static void doRegisterPushChannel(final ContextWrapper context, final RegisterPushChannelRequest request, final String hwId, final GaStoreManager storeManager, final GaRestController restController, final SecurityHelper securityHelper, final RequestListener<Void> listener) {
        if (request == null) {
            listener.onFailure(ErrorFactory.getWarnError(context, Error.GENERAL_INVALID_INPUT));
            return;
        }
        if (request.getAppVersion() == null || request.getAppVersion().length() > 15) {
            listener.onFailure(ErrorFactory.getWarnError(context, Error.GENERAL_INVALID_INPUT, new InvalidParameterException(String.format(context.getString(R.string.EXCEPTION_INVALID_INPUT_LENGTH_MIN_MAX), "appVersion", 0, 15))));
            return;
        }
        if (request.getOsVersion() == null || request.getOsVersion().length() > 15) {
            listener.onFailure(ErrorFactory.getWarnError(context, Error.GENERAL_INVALID_INPUT, new InvalidParameterException(String.format(context.getString(R.string.EXCEPTION_INVALID_INPUT_LENGTH_MIN_MAX), "oSVersion", 0, 15))));
            return;
        }
        storeManager.getUser(new RequestListener<User>() {
            @Override
            public void onSuccess(User response) {
                if (response != null) {
                    // String userToken, String user, String phoneId, String hwId, String pan, String deviceId, String connector, RequestListener<BaseResponse> listener
                    restController.registerPushChannel(response.getToken(), response.getName(), response.getPhoneId(), hwId, response.getCardId(), request.getDeviceId(), request.getConnector(), request.getOsVersion(), request.getAppVersion(), new CardHostErrorChainRequestListener<>(context, storeManager, restController, securityHelper, new RequestListener<BaseResponse>() {
                        @Override
                        public void onSuccess(BaseResponse response) {
                            listener.onSuccess(null);
                        }

                        @Override
                        public void onFailure(Error error) {
                            listener.onFailure(error);
                        }
                    }));
                } else
                    listener.onFailure(ErrorFactory.getWarnError(context, Error.GENERAL_USER_NOT_EXISTS));
            }

            @Override
            public void onFailure(Error error) {

            }
        });
    }
}
