package com.did.gacard.core;

import com.did.gacard.GaCard;
import com.did.gacard.core.files.model.EventEFile;
import com.did.gacard.core.files.model.StructEvent;
import com.did.gacard.ecard.util.ByteArray;
import com.did.gacard.ecard.util.DateParser;

final class GaAppletEventParser {

    public static GaAppletEvent parse(byte[] balance, EventEFile eventFile) {
        if (eventFile == null) return null;

        GaAppletEvent event = new GaAppletEvent();
        event.setNt(ByteArray.arrayByteToInt(eventFile.getNt()));
        event.setValue(ByteArray.arrayByteToInt(eventFile.getImpEvent()));
        event.setPreBalance(ByteArray.arrayByteToInt(eventFile.getBalEvent()));
        event.setPosBalance(ByteArray.arrayByteToInt(balance));
        event.setType(getType(eventFile.getTransEvent()));
        event.setContract(getContract(eventFile.getTransEvent()));

        StructEvent structEvent = null;
        try {
            structEvent = new StructEvent(eventFile.getStructEvent());
        } catch (Exception e) {
            GaCard.getInstance().getLogger().logError("GaAppletEventParser::parse", "Bad Event", e);
        }
        if (structEvent != null) {
            event.setDirection(ByteArray.byteToInt(structEvent.getDirection()));
            event.setTransaction(ByteArray.byteToInt(structEvent.getTransaction()));
            event.setOperator(ByteArray.arrayByteToInt(structEvent.getOperator()));
            event.setTitle(ByteArray.arrayByteToInt(structEvent.getTitle()));
            event.setLine(ByteArray.arrayByteToInt(structEvent.getLine()));
            event.setManager(ByteArray.arrayByteToInt(structEvent.getManager()));
            event.setDate(DateParser.parseDateTime(structEvent.getDate(), structEvent.getTime(), eventFile.getNt()));
            event.setTrips(ByteArray.byteToInt(structEvent.getTrips()));
            event.setBonusTrips(ByteArray.arrayByteToInt(structEvent.getBonusTrips()));
            event.setCurrency(ByteArray.byteToInt(structEvent.getCurrency()));
            event.setFlatRate(ByteArray.byteToInt(structEvent.getFlatRate()));
            event.setArea(ByteArray.byteToInt(structEvent.getArea()));
            event.setOrigin(ByteArray.arrayByteToInt(structEvent.getOrigin()));
            event.setDestination(ByteArray.arrayByteToInt(structEvent.getDestination()));
            event.setOriginTownHall(ByteArray.arrayByteToInt(structEvent.getOriginTownHall()));
            event.setDestinationTownHall(ByteArray.arrayByteToInt(structEvent.getDestinationTownHall()));
        }


        return event;
    }

    private static byte getType(byte transaction) {
        return (byte) ((transaction & 0xC0) >> 6);
    }

    private static byte getContract(byte transaction) {
        return (byte) (transaction & 0x1F);
    }

}
