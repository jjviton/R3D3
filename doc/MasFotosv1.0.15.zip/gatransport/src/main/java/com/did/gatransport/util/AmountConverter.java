package com.did.gatransport.util;

import java.math.BigDecimal;

public final class AmountConverter {

    private static int DECIMALS = 2;

    public static int reverseDecimalAmount(String amount) {
        return amount != null && !amount.trim().isEmpty() ? reverseDecimalAmount(new BigDecimal(amount.trim())) : 0;
    }

    public static int reverseDecimalAmount(BigDecimal amount) {
        return amount != null ? amount.multiply(new BigDecimal(10).pow(DECIMALS)).intValue() : 0;
    }

    public static BigDecimal getDecimalAmount(int amount) {
        return new BigDecimal(amount).divide(new BigDecimal(10).pow(DECIMALS));
    }

    public static String getDecimalAmountString(int amount) {
        return getDecimalAmount(amount).toString();
    }
}
