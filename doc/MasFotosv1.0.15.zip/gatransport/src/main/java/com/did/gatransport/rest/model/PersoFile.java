package com.did.gatransport.rest.model;

import com.did.gacard.core.files.model.GaAppFile;
import com.google.gson.annotations.SerializedName;

public final class PersoFile {
    // TODO Si se implementa seleccion de ficheros por aid habrá que pasar aquí un listado de AppFiles.
    @SerializedName("memory_ga")
    private GaAppFile file;

    public PersoFile() {
    }

    public GaAppFile getFile() {
        return file;
    }

    public void setFile(GaAppFile file) {
        this.file = file;
    }
}
