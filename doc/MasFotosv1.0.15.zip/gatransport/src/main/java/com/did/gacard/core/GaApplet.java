package com.did.gacard.core;

import android.os.Handler;

import com.did.gacard.GaCard;
import com.did.gacard.core.files.GaAppFileLoader;
import com.did.gacard.core.files.GaAppFileManager;
import com.did.gacard.core.files.model.ContractEFile;
import com.did.gacard.core.files.model.EventEFile;
import com.did.gacard.core.protocol.GaCommandFactory;
import com.did.gacard.core.protocol.GaSecurityCalculator;
import com.did.gacard.core.protocol.GaSecurityElement;
import com.did.gacard.ecard.core.Applet;
import com.did.gacard.ecard.core.AppletService;
import com.did.gacard.ecard.core.iso7816.CommandApdu;
import com.did.gacard.ecard.core.iso7816.ResponseApdu;
import com.did.gacard.ecard.util.ByteArray;
import com.did.gacard.util.GaCardException;

import java.io.ByteArrayOutputStream;
import java.util.Arrays;

public final class GaApplet implements Applet {
    private static final boolean ENABLE_WRITE = false;

    // Response SW
    private static final byte[] ERROR_NO_PROCESSED = null;
    private static final byte[] ERROR_SW_DEFAULT = ResponseApdu.SW_6A82; // SW_6982
    private static final byte[] ERROR_SW_CANCELCLOSE = ResponseApdu.SW_9302;
    private static final byte[] OK_SW = ResponseApdu.SW_9000;

    private static final String SELECT_APDU_HEADER = "00A40400";

    // AID : 98702001000001 (4F11)
    private static final String NETWORK = "4F11";

    public static boolean isPreSelectApdu(byte[] commandApdu) {
        String vs = ByteArray.byteArrayToHexString(commandApdu);
        return SELECT_APDU_HEADER.equalsIgnoreCase(vs.substring(0, SELECT_APDU_HEADER.length()));
    }

    public boolean isSelectApdu(byte[] commandApdu) {
        return isPreSelectApdu(commandApdu);
    }

    public interface GaAppletListener {
        void onSelected(byte[] aid);

        void onEvent(GaAppletEvent event);

        void onDestroy(boolean hasOperated);
    }

    private GaAppFileManager fileManager;
    private GaSecurityElement securityElement;
    private GaSecurityCalculator securityCalculator;
    private GaAppletListener appletListener;

    private static final int STATE_IDLE = 1;
    private static final int STATE_SELECTED = 2;
    private static final int STATE_OPENED = 3;
    private static final int STATE_AUTH = 4;

    private int state = STATE_IDLE;

    private boolean running = false;
    private boolean selected = false;

    private ResponseApdu responseApdu = null;

    private boolean hasOperated = false;

    public GaApplet(GaAppFileLoader fileLoader, GaSecurityElement securityElement, GaAppletListener appletListener) throws GaCardException {
        this.fileManager = new GaAppFileManager(fileLoader);
        this.securityElement = securityElement;
        this.appletListener = appletListener;
    }

    private boolean isSelected() {
        return selected;
    }

    private void select() {
        selected = true;
        state = STATE_IDLE;
    }

    private void deselect() {
        selected = false;
        state = STATE_IDLE;
    }

    @Override
    public byte[] getAid() {
        return fileManager.getAid();
    }

    @Override
    public boolean doSelectFile(byte[] commandApdu) {
        // TODO Habría que implementar la selección del fichero por su aid.
        String aid = fileManager.getStringAid();
        int aidLength = aid.length() / 2;
        String byteAidLength = aidLength < 10 ? "0" + aidLength : "" + aidLength;
        String selectAid = SELECT_APDU_HEADER + byteAidLength + aid;
        if (selectAid.length() % 2 != 0) {
            selectAid += 0;
        }

        boolean isFileSelected = Arrays.equals(ByteArray.hexStringToByteArray(selectAid), commandApdu);
//        boolean isFileSelected = isSelectApdu(commandApdu);
        if (isFileSelected) {
            GaCard.getInstance().getLogger().logDebug("GaApplet::doSelectFile", "fileSelected: " + aid);
        }
        return isFileSelected;
    }

    @Override
    public void deactivate() {
        deselect();
    }

    @Override
    public void destroy() {
        deactivate();
        if (appletListener != null) appletListener.onDestroy(hasOperated);
    }

    @Override
    public byte[] process(final byte[] commandApdu, AppletService.AsyncResponseListener asyncResponseListener) {
        byte[] response = ERROR_SW_DEFAULT;
        if (running) return response;
        running = true;

        if (doSelectFile(commandApdu)) {
            select();
            securityCalculator = new GaSecurityCalculator(fileManager.getDebitKey(), securityElement);
            response = OK_SW;
            hasOperated = false;
            if (appletListener != null) appletListener.onSelected(getAid());
        } else if (isSelected()) {
            processAsync(commandApdu, asyncResponseListener);
            return null;
        }

        checkErrorResponse(response);
        running = false;
        return response;
    }

    private void checkErrorResponse(byte[] response) {
        if (response != null && response.length == 2 && !Arrays.equals(response, OK_SW)) {
            state = STATE_IDLE;
        }
    }

    private final Handler mHandler = new Handler();

    private void processAsync(final byte[] apdu, final AppletService.AsyncResponseListener asyncResponseListener) {
        Thread t = new Thread(new Runnable() {
            @Override
            public void run() {
                finish(processAppletApdu(apdu, fileManager, securityCalculator), asyncResponseListener);
            }
        });
        t.setPriority(Thread.MAX_PRIORITY);
        t.start();
    }

    private void processSync(byte[] apdu, AppletService.AsyncResponseListener asyncResponseListener) {
        finish(processAppletApdu(apdu, fileManager, securityCalculator), asyncResponseListener);
    }

    private class GaAppletResponse {
        private byte[] response;

        private boolean dataCommit;
        private byte[] certificateHiToCommit;

        private boolean notifyEvent;
        private boolean units;
        private int contract;
        private EventEFile newEventEF;

        GaAppletResponse(byte[] response) {
            this.response = response;
            this.dataCommit = false;
            this.notifyEvent = false;
        }
    }

    private void finish(GaAppletResponse gaAppletResponse, AppletService.AsyncResponseListener asyncResponseListener) {
        // Check if connection was lost
        if (state == STATE_IDLE) {
            if (gaAppletResponse != null && gaAppletResponse.dataCommit)
                fileManager.rollBack();

            GaCard.getInstance().getLogger().logDebug("GaApplet::finish", "Operation canceled by idle state.");
            sendResponse(ERROR_NO_PROCESSED, asyncResponseListener);
            return;
        }
        if (gaAppletResponse == null) return;

        sendResponse(gaAppletResponse.response, asyncResponseListener);

        if (gaAppletResponse.dataCommit) {
            commit(gaAppletResponse.certificateHiToCommit);
        }
        if (gaAppletResponse.notifyEvent) {
            notifyEvent(gaAppletResponse.units, gaAppletResponse.contract, gaAppletResponse.newEventEF);
        }
    }

    private void commit(final byte[] certificateHiToCommit) {
        mHandler.post(new Runnable() {
            @Override
            public void run() {
                securityCalculator.commitCertificateHi(certificateHiToCommit);
                fileManager.commit();
                hasOperated = true;
            }
        });
    }

    private void notifyEvent(final boolean units, final int contract, final EventEFile newEventEF) {
        mHandler.post(new Runnable() {
            @Override
            public void run() {
                // Recover new Balance
                byte[] newBalance;
                if (units) {
                    newBalance = fileManager.getBalance();
                } else {
                    newBalance = fileManager.getContract(contract).getCounterContract();
                }

                if (appletListener != null) {
                    appletListener.onEvent(GaAppletEventParser.parse(newBalance, newEventEF));//!units, contract, ByteArray.arrayByteToInt(value), ByteArray.arrayByteToInt(newBalance), System.currentTimeMillis());
                }
            }
        });
    }

    private void sendResponse(final byte[] response,
                              final AppletService.AsyncResponseListener asyncResponseListener) {
        mHandler.post(new Runnable() {
            @Override
            public void run() {
                checkErrorResponse(response);
                running = false;
                if (asyncResponseListener != null)
                    asyncResponseListener.onResponse(response);
            }
        });
    }

    private GaAppletResponse processAppletApdu(byte[] commandApdu, GaAppFileManager
            fileManager, GaSecurityCalculator securityCalculator) {
        GaAppletResponse response = new GaAppletResponse(ERROR_SW_DEFAULT);

        CommandApdu command = GaCommandFactory.getCommand(commandApdu);
        if (command != null) {
            switch (command.getId()) {
                default: // FAILS
                    break;

                case GaCommandFactory.SELECT_TRANSPORT_NETWORK:
                    response = doSelect(command, fileManager, securityCalculator);
                    break;
                case GaCommandFactory.OPEN_VALIDATOR_SESSION:
                    response = doOpen(command, fileManager, securityCalculator);
                    break;
                case GaCommandFactory.CLOSE_VALIDATOR_SESSION:
                    response = doClose(command, fileManager, securityCalculator);
                    break;
                case GaCommandFactory.CANCEL_VALIDATOR_SESSION:
                    response = doCancel(command, fileManager, securityCalculator);
                    break;
                case GaCommandFactory.CLEAR_RATIFICATION_BIT:
                    response = doClear(command, fileManager, securityCalculator);
                    break;
                case GaCommandFactory.READ_CONTRACT:
                    response = doReadContract(command, fileManager, securityCalculator);
                    break;
                case GaCommandFactory.READ_EVENT:
                    response = doReadEvent(command, fileManager, securityCalculator);
                    break;
                case GaCommandFactory.READ_ENV_HOL_TOK:
                    response = doReadEnvHolTok(command, fileManager, securityCalculator);
                    break;
                case GaCommandFactory.WRITE_CONTRACT:
                    response = doWriteContract(command, fileManager, securityCalculator);
                    break;
                case GaCommandFactory.WRITE_EVENT:
                    response = doWriteEvent(command, fileManager, securityCalculator);
                    break;
                case GaCommandFactory.WRITE_ENV_HOL:
                    response = doWriteEnvHol(command, fileManager, securityCalculator);
                    break;
                case GaCommandFactory.RELOAD_TOKEN_PURSE:
                    response = doReloadToken(command, fileManager, securityCalculator);
                    break;
                case GaCommandFactory.INTERNAL_AUTH:
                    response = doInternalAuth(command, fileManager, securityCalculator);
                    break;
                case GaCommandFactory.GET_RESPONSE:
                    response = doGetResponse(command, fileManager, securityCalculator);
                    break;
            }
        }

        return response;
    }

    // SELECT_TRANSPORT_NETWORK > OPEN > READ CON > CLOSE

    // Select Transport Network
    // Selecciona una aplicación de transporte y devuelve la versión de clave de débito,
    // el identificador de algoritmo de débito y el número de serie de la aplicación.
    //
    // States:
    // SW_6400
    // SW_6581
    // SW_6CXX
    // SW_6985
    // SW_6A82
    // SW_6D00
    // SW_6E00
    // SW_9000 - OK
    private GaAppletResponse doSelect(CommandApdu commandApdu, GaAppFileManager
            fileManager, GaSecurityCalculator securityCalculator) {
        if (Arrays.equals(commandApdu.getP1P2(), ByteArray.hexStringToByteArray(NETWORK))) {
            byte[] nt = fileManager.getNt();
            byte[] serialNumber = fileManager.getSerialApp();
            byte[] sw = OK_SW;

            state = STATE_SELECTED;

            return new GaAppletResponse(GaCommandFactory.buildResponseSelectTransportNetwork(nt, serialNumber, sw, ERROR_SW_DEFAULT).getBytes());
        }

        return new GaAppletResponse(ERROR_SW_DEFAULT);
    }

    //  **Open Validator Session
    // Comienza la transacción de débito y devuelve el entorno, el perfil de usuario,
    // el último evento y la lista de contratos válidos.
    //
    // Solo permite: Read Contract, Read Event, Read Env Hol Tok, Get Response (sólo contactos)
    //
    // States:
    // SW_613A
    // SW_6700
    // SW_6958
    // SW_6A83
    // SW_6A86
    // SW_6D00
    // SW_6E00
    // SW_9000 - OK
    private GaAppletResponse doOpen(CommandApdu commandApdu, GaAppFileManager
            fileManager, GaSecurityCalculator securityCalculator) {
        if (state < STATE_SELECTED) return new GaAppletResponse(ERROR_SW_DEFAULT);

        EventEFile lastEvent = fileManager.getLastEvent();
        byte[] nt = lastEvent.getNt();
        byte[] impEvent = lastEvent.getImpEvent();
        byte[] balEvent = lastEvent.getBalEvent();

        // TransEvent   Operation   RFU     Counter/Contract Number
        //              b7b6        b5      b4-b0
        // Consume      01          -
        // Cancel       00          -
        byte[] transEvent = new byte[1];
        transEvent[0] = lastEvent.getTransEvent();

        byte[] eventStruct = lastEvent.getStructEvent();
        byte[] envirStruct = fileManager.getStructEnvironment();
        byte[] holderStruct = fileManager.getStructUser();
        byte[] purseValue = fileManager.getBalance();

        // Ratification   Y/N Ratification  RFU
        //                  b7              b6-b0
        byte[] ratification = new byte[1];
        ratification[0] = lastEvent.getBitRatification();

        byte[] sw = OK_SW;

        // Security: Initiate security calculator
        byte[] cardChallenge = securityCalculator.init(commandApdu.getData());

        // Security: Add out
        ByteArrayOutputStream outputStream = new ByteArrayOutputStream();
        try {
            outputStream.write(nt);
            outputStream.write(impEvent);
            outputStream.write(balEvent);
            outputStream.write(transEvent);
            outputStream.write(eventStruct);
            outputStream.write(envirStruct);
            outputStream.write(holderStruct);
            outputStream.write(purseValue);
            outputStream.write(ratification);
        } catch (Throwable t) {
            GaCard.getInstance().getLogger().logError("GaApplet::doOpen", "Packing response error", t);
            return new GaAppletResponse(ERROR_SW_DEFAULT);
        }
        securityCalculator.add(outputStream.toByteArray());

        state = STATE_OPENED;

        return new GaAppletResponse(GaCommandFactory.buildResponseOpenValidatorSession(nt, impEvent, balEvent, transEvent, eventStruct, envirStruct, holderStruct, purseValue, ratification, cardChallenge, sw, ERROR_SW_DEFAULT).getBytes());
    }

    //  *Close Validator Session
    // Concluye la sesión de débito y añade un nuevo evento en la tarjeta, con la posibilidad de
    // decrementar algún contador y la posibilidad de invalidar algún contrato
    //
    // States:
    // SW_6104
    // SW_6581
    // SW_6700
    // SW_6985
    // SW_6A83
    // SW_6A86
    // SW_6D00
    // SW_6E00
    // SW_9102
    // SW_9302
    // SW_9000 - OK
    private GaAppletResponse doClose(CommandApdu commandApdu, GaAppFileManager
            fileManager, GaSecurityCalculator securityCalculator) {
        if (state != STATE_OPENED) return new GaAppletResponse(ERROR_SW_DEFAULT);

        byte[] certificateHi;
        EventEFile newEventEF = null;
        boolean decrementUnits = false;
        int decrementContract = -1;
        byte[] decValue = null;

        // Recover certificateHi (lc = 0x04 or 0x24) and generate new Event (only in case lc = 0x24)
        byte lc = commandApdu.getLc();
        if (lc == GaCommandFactory.LC_04) {
            GaCard.getInstance().getLogger().logDebug("GaApplet::doClose", "LC 04");
            certificateHi = commandApdu.getData();
        } else { // lc == 0x24
            GaCard.getInstance().getLogger().logDebug("GaApplet::doClose", "LC 24");
            byte p1 = commandApdu.getP1();
            decrementUnits = ByteArray.isSet(p1, 7);
            decrementContract = p1 & GaCommandFactory.MASK_B40;

            newEventEF = new EventEFile(commandApdu.getData());
            newEventEF.setBitRatification(GaCommandFactory.RATIFICATION_PENDING);
            newEventEF.setRfu(new byte[EventEFile.FILE_SIZE_RFU]);

            byte[] nt = newEventEF.getNt();
            byte[] impEvent = newEventEF.getImpEvent();
            byte[] balEvent = newEventEF.getBalEvent();
            byte transEvent = newEventEF.getTransEvent();
            byte[] newEvent = newEventEF.getStructEvent();
            decValue = ByteArray.getBytes(commandApdu.getData(), commandApdu.getData().length - 7, 3);
            certificateHi = ByteArray.getBytes(commandApdu.getData(), commandApdu.getData().length - 4, 4);

            if (checkEvent(fileManager.getNt(), decrementUnits ? fileManager.getBalance() : fileManager.getContract(decrementContract).getCounterContract(), commandApdu.getP2(), decrementContract, decValue, newEventEF)) {
                GaCard.getInstance().getLogger().logDebug("GaApplet::doClose", "Good New Event");

                // Security: Add in
                // The last element
                ByteArrayOutputStream outputStream = new ByteArrayOutputStream();
                try {
                    outputStream.write(nt);
                    outputStream.write(impEvent);
                    outputStream.write(balEvent);
                    outputStream.write(transEvent);
                    outputStream.write(newEvent);
                    outputStream.write(decValue);
                } catch (Throwable t) {
                    GaCard.getInstance().getLogger().logError("GaApplet::doClose", "Packing response error", t);
                    return new GaAppletResponse(ERROR_SW_DEFAULT);
                }
                securityCalculator.add(outputStream.toByteArray());
            } else
                return new GaAppletResponse(ERROR_SW_DEFAULT);
        }

        securityCalculator.digest();

        byte[] certificateLo = securityCalculator.getCertificateLo();
        byte[] newBalance = new byte[0];
        if (securityCalculator.checkCertificateHi(certificateHi)) {
            GaCard.getInstance().getLogger().logDebug("GaApplet::doClose", "Good Cert");
            if (newEventEF != null) {
                // Add event
                fileManager.edit().add(newEventEF);

                // Decrement units
                if (decrementUnits) {
                    GaCard.getInstance().getLogger().logDebug("GaApplet::doClose", "DecrementUnits by " + ByteArray.arrayByteToInt(decValue));
                    fileManager.edit().decrementUnits(decValue);
                } else if (fileManager.edit().decrementContract(decrementContract, decValue) == null) {
                    fileManager.rollBack();
                    GaCard.getInstance().getLogger().logDebug("GaApplet::doClose", "Could not modify contract.");
                    return new GaAppletResponse(ERROR_SW_DEFAULT);
                } else {
                    GaCard.getInstance().getLogger().logDebug("GaApplet::doClose", "DecrementContract " + decrementContract + " by " + ByteArray.arrayByteToInt(decValue));
                }

                // Increment nt
                fileManager.edit().setNt(newEventEF.getNt());
            }

            ResponseApdu responseApdu = GaCommandFactory.buildResponseCloseValidatorSession(certificateLo, OK_SW, ERROR_SW_DEFAULT);

            GaAppletResponse gaAppletResponse = new GaAppletResponse(responseApdu.getBytes());
            gaAppletResponse.dataCommit = Arrays.equals(responseApdu.getState(), OK_SW) && lc == GaCommandFactory.LC_24;
            gaAppletResponse.certificateHiToCommit = certificateHi;
            gaAppletResponse.notifyEvent = gaAppletResponse.dataCommit;
            gaAppletResponse.units = decrementUnits;
            gaAppletResponse.contract = decrementContract;
            gaAppletResponse.newEventEF = newEventEF;
            return gaAppletResponse;
        } else {
            GaCard.getInstance().getLogger().logDebug("GaApplet::doClose", "Bad Cert: " + ByteArray.byteArrayToHexString(certificateHi));
        }

        return new GaAppletResponse(ERROR_SW_CANCELCLOSE);
    }

    private boolean checkEvent(byte[] oldNt, byte[] oldBal, byte p2, int b4b0,
                               byte[] decValue, EventEFile newEventEF) {
        // check NT
        byte[] newNt = Arrays.copyOf(oldNt, oldNt.length);
        try {
            ByteArray.increment(newNt);
        } catch (Exception e) {
            GaCard.getInstance().getLogger().logError("GaApplet::checkEvent", "Nt error", e);
        }
        boolean chkNt = Arrays.equals(newEventEF.getNt(), newNt);
        GaCard.getInstance().getLogger().logDebug("GaApplet::checkEvent", "Nt ok? " + chkNt);

        // check ImpEvent
        boolean chkImpEvent = Arrays.equals(newEventEF.getImpEvent(), ByteArray.getBytes(decValue, 1, 2));
        GaCard.getInstance().getLogger().logDebug("GaApplet::checkEvent", "ImpEvent ok? " + chkImpEvent);

        // check  BalEvent
        boolean chkBalEvent = Arrays.equals(newEventEF.getBalEvent(), oldBal);
        GaCard.getInstance().getLogger().logDebug("GaApplet::checkEvent", "BalEvent ok? " + chkBalEvent);

        // check TransEvent
        // Transaction Type
        boolean chkB7 = !ByteArray.isSet(newEventEF.getTransEvent(), 7);
        boolean chkB6 = (GaCommandFactory.P2_00 == p2 && ByteArray.isSet(newEventEF.getTransEvent(), 6))
                || (GaCommandFactory.P2_01 == p2 && !ByteArray.isSet(newEventEF.getTransEvent(), 6));
        // RFU
        boolean chkB5 = !ByteArray.isSet(newEventEF.getTransEvent(), 5);
        // B4-0
        boolean chkB40 = ((int) newEventEF.getTransEvent() & GaCommandFactory.MASK_B40) == b4b0;
        boolean chkTransEvent = chkB7 && chkB6 && chkB5 && chkB40;
        GaCard.getInstance().getLogger().logDebug("GaApplet::checkEvent", "TransEvent ok? " + chkTransEvent);

        return chkNt && chkImpEvent && chkBalEvent && chkTransEvent;
    }

    //  *Cancel Validator Session
    // Concluye la sesión de cancelación y añade un nuevo evento en la tarjeta, cancelando la
    // última trasnsacción en la tarjeta.
    //
    // States:
    // SW_6104
    // SW_6581
    // SW_6700
    // SW_6985
    // SW_6A83
    // SW_6A86
    // SW_6D00
    // SW_6E00
    // SW_9102
    // SW_9302
    // SW_9505
    // SW_9000 - OK
    private GaAppletResponse doCancel(CommandApdu commandApdu, GaAppFileManager
            fileManager, GaSecurityCalculator securityCalculator) {
        if (state != STATE_OPENED) return new GaAppletResponse(ERROR_SW_DEFAULT);

        byte[] certificateHi;
        EventEFile newEventEF;
        boolean incrementUnits;
        int incrementContract;
        byte[] cancValue;

        byte p1 = commandApdu.getP1();
        incrementUnits = ByteArray.isSet(p1, 7);
        incrementContract = p1 & GaCommandFactory.MASK_B40;

        newEventEF = new EventEFile(commandApdu.getData());
        newEventEF.setBitRatification(GaCommandFactory.RATIFICATION_PENDING);
        newEventEF.setRfu(new byte[EventEFile.FILE_SIZE_RFU]);

        byte[] nt = newEventEF.getNt();
        byte[] impEvent = newEventEF.getImpEvent();
        byte[] balEvent = newEventEF.getBalEvent();
        byte transEvent = newEventEF.getTransEvent();
        byte[] newEvent = newEventEF.getStructEvent();
        cancValue = ByteArray.getBytes(commandApdu.getData(), commandApdu.getData().length - 7, 3);
        certificateHi = ByteArray.getBytes(commandApdu.getData(), commandApdu.getData().length - 4, 4);

        if (checkEvent(fileManager.getNt(), incrementUnits ? fileManager.getBalance() : fileManager.getContract(incrementContract).getCounterContract(), commandApdu.getP2(), incrementContract, cancValue, newEventEF)) {
            GaCard.getInstance().getLogger().logDebug("GaApplet::doCancel", "Good New Event");

            // Security: Add in
            // The last element
            ByteArrayOutputStream outputStream = new ByteArrayOutputStream();
            try {
                outputStream.write(nt);
                outputStream.write(impEvent);
                outputStream.write(balEvent);
                outputStream.write(transEvent);
                outputStream.write(newEvent);
                outputStream.write(cancValue);
            } catch (Throwable t) {
                GaCard.getInstance().getLogger().logError("GaApplet::doCancel", "Packing response error", t);
                return new GaAppletResponse(ERROR_SW_DEFAULT);
            }
            securityCalculator.add(outputStream.toByteArray());
        } else
            return new GaAppletResponse(ERROR_SW_DEFAULT);

        securityCalculator.digest();

        byte[] certificateLo = securityCalculator.getCertificateLo();
        byte[] newBalance = new byte[0];
        if (securityCalculator.checkCertificateHi(certificateHi)) {
            GaCard.getInstance().getLogger().logDebug("GaApplet::doCancel", "Good Cert");
            // Add event
            fileManager.edit().add(newEventEF);

            // Decrement units
            if (incrementUnits) {
                GaCard.getInstance().getLogger().logDebug("GaApplet::doCancel", "IncrementUnits by " + ByteArray.arrayByteToInt(cancValue));
                fileManager.edit().incrementUnits(cancValue);
            } else if (fileManager.edit().incrementContract(incrementContract, cancValue) == null) {
                fileManager.rollBack();
                GaCard.getInstance().getLogger().logDebug("GaApplet::doCancel", "Could not modify contract.");
                return new GaAppletResponse(ERROR_SW_DEFAULT);
            } else {
                GaCard.getInstance().getLogger().logDebug("GaApplet::doCancel", "IncrementContract " + incrementContract + " by " + ByteArray.arrayByteToInt(cancValue));
            }

            // Increment nt
            fileManager.edit().setNt(newEventEF.getNt());

            ResponseApdu responseApdu = GaCommandFactory.buildResponseCloseValidatorSession(certificateLo, OK_SW, ERROR_SW_DEFAULT);

            GaAppletResponse gaAppletResponse = new GaAppletResponse(responseApdu.getBytes());
            gaAppletResponse.dataCommit = Arrays.equals(responseApdu.getState(), OK_SW);
            gaAppletResponse.certificateHiToCommit = certificateHi;
            gaAppletResponse.notifyEvent = gaAppletResponse.dataCommit;
            gaAppletResponse.units = incrementUnits;
            gaAppletResponse.contract = incrementContract;
            gaAppletResponse.newEventEF = newEventEF;
            return gaAppletResponse;
        } else {
            GaCard.getInstance().getLogger().logDebug("GaApplet::doCancel", "Bad Cert: " + ByteArray.byteArrayToHexString(certificateHi));
        }

        return new GaAppletResponse(ERROR_SW_CANCELCLOSE);
    }

    // Clear Ratification Bit
    // Completa el proceso de ratificación de la transacción.
    //
    // States:
    // SW_6581
    // SW_6700
    // SW_6985
    // SW_6A86
    // SW_6D00
    // SW_6E00
    // SW_9000 - OK
    private GaAppletResponse doClear(CommandApdu commandApdu, GaAppFileManager
            fileManager, GaSecurityCalculator securityCalculator) {
        if (state < STATE_SELECTED) return new GaAppletResponse(ERROR_SW_DEFAULT);

        fileManager.edit().clearRatification();

        byte[] sw = OK_SW;

        ResponseApdu responseApdu = GaCommandFactory.buildResponseClearRatificationBit(sw, ERROR_SW_DEFAULT);

        GaAppletResponse gaAppletResponse = new GaAppletResponse(responseApdu.getBytes());
        gaAppletResponse.dataCommit = true;
        gaAppletResponse.certificateHiToCommit = null;

        return gaAppletResponse;
    }

    //  *Read Contract
    // Lectura de un contrato de transportes.
    //
    // States:
    // SW_6CXX
    // SW_6985
    // SW_6A83
    // SW_6A86
    // SW_6D00
    // SW_6E00
    // SW_9000
    private GaAppletResponse doReadContract(CommandApdu commandApdu, GaAppFileManager
            fileManager, GaSecurityCalculator securityCalculator) {
        if (state < STATE_SELECTED) return new GaAppletResponse(ERROR_SW_DEFAULT);

        // Security: Add in
        securityCalculator.add(commandApdu.getLcDataLe());

        int contractNumber = commandApdu.getP1() & GaCommandFactory.MASK_B40;
        ContractEFile contract = fileManager.getContract(contractNumber);
        if (contract == null)
            return new GaAppletResponse(ERROR_SW_DEFAULT);

        byte[] contractStruct = contract.getStructContract();
        byte[] counterVal = contract.getCounterContract();
        byte[] sw = OK_SW;

        // Security: Add out
        ResponseApdu response = GaCommandFactory.buildResponseReadContact(contractStruct, counterVal, sw, ERROR_SW_DEFAULT);
        securityCalculator.add(response.getData());

        return new GaAppletResponse(response.getBytes());
    }

    //  *Read Event
    // Lectura de un evento de transportes.
    //
    // States:
    // SW_6CXX
    // SW_6985
    // SW_6A83
    // SW_6A86
    // SW_6D00
    // SW_6E00
    // SW_9000 - ok
    private GaAppletResponse doReadEvent(CommandApdu commandApdu, GaAppFileManager
            fileManager, GaSecurityCalculator securityCalculator) {
        if (state < STATE_SELECTED) return new GaAppletResponse(ERROR_SW_DEFAULT);

        // Security: Add in
        securityCalculator.add(commandApdu.getLcDataLe());

        int eventNumber = commandApdu.getP1() & GaCommandFactory.MASK_B40;
        EventEFile event = fileManager.getEvent(eventNumber);
        if (event == null)
            return new GaAppletResponse(ERROR_SW_DEFAULT);

        byte[] nt = event.getNt();
        byte[] impEvent = event.getImpEvent();
        byte[] balEvent = event.getBalEvent();
        byte[] transEvent = new byte[1];
        transEvent[0] = event.getTransEvent();
        byte[] eventStruct = event.getStructEvent();
        byte[] sw = OK_SW;

        // Security: Add out
        ResponseApdu response = GaCommandFactory.buildResponseReadEvent(nt, impEvent, balEvent, transEvent, eventStruct, sw, ERROR_SW_DEFAULT);
        securityCalculator.add(response.getData());

        return new GaAppletResponse(response.getBytes());
    }

    //  *Read Enviroment, Holder Profile and Token Purse
    // Lectura de los datos de entorno, perfil de usuario y monedero de unidades.
    //
    // States:
    // SW_6CXX
    // SW_6985
    // SW_6A86
    // SW_6D00
    // SW_6E00
    // SW_9000 - OK
    private GaAppletResponse doReadEnvHolTok(CommandApdu commandApdu, GaAppFileManager
            fileManager, GaSecurityCalculator securityCalculator) {
        if (state < STATE_SELECTED) return new GaAppletResponse(ERROR_SW_DEFAULT);

        // Security: Add in
        securityCalculator.add(commandApdu.getLcDataLe());

        byte[] envirStruct = fileManager.getStructEnvironment();
        byte[] holderStruct = fileManager.getStructUser();
        byte[] purseValue = fileManager.getBalance();
        byte[] sw = OK_SW;

        // Security: Add out
        ResponseApdu response = GaCommandFactory.buildResponseReadEnvironmentHolderProfilesTokenPurse(envirStruct, holderStruct, purseValue, sw, ERROR_SW_DEFAULT);
        securityCalculator.add(response.getData());

        return new GaAppletResponse(response.getBytes());
    }

    // Write Contract
    // Escritura de un contrato.
    //
    // States:
    // SW_6581
    // SW_6700
    // SW_6985
    // SW_6982
    // SW_6A86
    // SW_6D00
    // SW_6E00
    // SW_9000
    // SW_9302
    private GaAppletResponse doWriteContract(CommandApdu commandApdu, GaAppFileManager
            fileManager, GaSecurityCalculator securityCalculator) {
        if (ENABLE_WRITE && state != STATE_AUTH)
            return new GaAppletResponse(ERROR_SW_DEFAULT);

        byte[] sw = OK_SW;

        return new GaAppletResponse(GaCommandFactory.buildResponseWriteContract(sw, ERROR_SW_DEFAULT).getBytes());
    }

    // Write Event
    // Escritura de un evento.
    //
    // States:
    // SW_6581
    // SW_6700
    // SW_6985
    // SW_6982
    // SW_6A86
    // SW_6D00
    // SW_6E00
    // SW_9000 - OK
    // SW_9302
    // SW_9403
    private GaAppletResponse doWriteEvent(CommandApdu commandApdu, GaAppFileManager
            fileManager, GaSecurityCalculator securityCalculator) {
        if (ENABLE_WRITE && state != STATE_AUTH)
            return new GaAppletResponse(ERROR_SW_DEFAULT);

        byte[] sw = OK_SW;

        return new GaAppletResponse(GaCommandFactory.buildResponseWriteEvent(sw, ERROR_SW_DEFAULT).getBytes());
    }

    // Write Environment and Holder Profile
    // Escritura de datos de entorno y los datos de usuario.
    //
    // States:
    // SW_6581
    // SW_6700
    // SW_6985
    // SW_6982
    // SW_6A86
    // SW_6D00
    // SW_6E00
    // SW_9000
    // SW_9302
    private GaAppletResponse doWriteEnvHol(CommandApdu commandApdu, GaAppFileManager
            fileManager, GaSecurityCalculator securityCalculator) {
        if (ENABLE_WRITE && state != STATE_AUTH)
            return new GaAppletResponse(ERROR_SW_DEFAULT);

        byte[] sw = OK_SW;

        return new GaAppletResponse(GaCommandFactory.buildResponseWriteEnvironmentHolderProfile(sw, ERROR_SW_DEFAULT).getBytes());
    }

    // Reload Token Purse
    // Recarga del monedero de unidades de la aplicación.
    //
    // States:
    // SW_6581
    // SW_6700
    // SW_6985
    // SW_6982
    // SW_6A86
    // SW_6D00
    // SW_6E00
    // SW_9000
    // SW_9302
    // SW_9403
    private GaAppletResponse doReloadToken(CommandApdu commandApdu, GaAppFileManager
            fileManager, GaSecurityCalculator securityCalculator) {
        if (ENABLE_WRITE && state != STATE_AUTH)
            return new GaAppletResponse(ERROR_SW_DEFAULT);

        byte[] sw = OK_SW;

        return new GaAppletResponse(GaCommandFactory.buildResponseReloadTokenPurse(sw, ERROR_SW_DEFAULT).getBytes());
    }

    // Internal Authenticate
    // Establecimiento de una clave de sesión para la transacción de carga.
    //
    // States:
    // SW_610A - OK
    // SW_6581
    // SW_6700
    // SW_6983
    // SW_6985
    // SW_6A86
    // SW_6D00
    // SW_6E00
    private GaAppletResponse doInternalAuth(CommandApdu commandApdu, GaAppFileManager
            fileManager, GaSecurityCalculator securityCalculator) {
        if (ENABLE_WRITE && state != STATE_SELECTED)
            return new GaAppletResponse(ERROR_SW_DEFAULT);

        byte[] nt = new byte[2];
        byte[] s1 = new byte[8];
        byte[] sw = OK_SW;

        return new GaAppletResponse(GaCommandFactory.buildResponseReadInternalAuth(nt, s1, sw, ERROR_SW_DEFAULT).getBytes());
    }

    //  *Get Response
    // Devuelve los datos pendientes del comando anterior.
    //
    // States:
    // SW_6700
    // SW_6CXX
    // SW_6985
    // SW_6A86
    // SW_6D00
    // SW_6E00
    // SW_9000 - OK
    private GaAppletResponse doGetResponse(CommandApdu commandApdu, GaAppFileManager
            fileManager, GaSecurityCalculator securityCalculator) {

        int lc = commandApdu.getLc() & 0xFF;
        byte[] response = responseApdu == null ? null : responseApdu.getBytes();
        responseApdu = null;
        if (response == null || response.length != lc)
            return new GaAppletResponse(ERROR_SW_DEFAULT);

        byte[] sw = OK_SW;

        return new GaAppletResponse(GaCommandFactory.buildResponseGetResponse(response, lc, sw, ERROR_SW_DEFAULT).getBytes());
    }
}
