package com.did.gatransport.ui;

import android.content.ContextWrapper;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.v4.app.DialogFragment;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;

import com.did.gatransport.R;
import com.did.gatransport.controller.CoreController;
import com.did.gatransport.controller.RechargeController;
import com.did.gatransport.interfaces.RequestListener;
import com.did.gatransport.model.CardPayment;
import com.did.gatransport.model.Error;
import com.did.gatransport.model.request.CardRechargeRequest;
import com.did.gatransport.model.response.CardRechargeResponse;
import com.did.gatransport.rest.GaRestController;
import com.did.gatransport.rest.GaRestFactory;
import com.did.gatransport.rest.retrofit.request.BalanceRequest;
import com.did.gatransport.store.GaStoreFactory;
import com.did.gatransport.store.GaStoreManager;
import com.did.gatransport.util.AmountConverter;
import com.did.gatransport.util.ErrorFactory;
import com.did.security.core.SecurityHelper;

import java.net.URL;
import java.security.InvalidParameterException;

final class CardRechargeActivityController implements RechargeActivityController {

    private final int FRAG_ID_GATEWAY = 0;

    private ContextWrapper mContext;
    private FragmentManager mFragmentManager;

    private int containerViewId;

    private LoadDialogFragment loadingDialogFragment;

    private CardRechargeRequest request;
    private URL host;

    private SecurityHelper securityHelper;
    private GaStoreManager storeManager;
    private GaRestController restController;

    private RechargeActivityControllerListener listener;
    private final BadResourcesListener badResourcesListener = new BadResourcesListener() {
        @Override
        public void onBadResources() {
            finishKOBadResources();
        }
    };


    private Error confirmRechargeError = null;

    private boolean finishedOK = false;

    CardRechargeActivityController(@NonNull ContextWrapper context, @NonNull FragmentManager fragmentManager, int containerViewId, CardRechargeRequest request, URL host, RechargeActivityControllerListener listener) {
        this.mContext = context;
        this.mFragmentManager = fragmentManager;
        this.containerViewId = containerViewId;

        this.request = request;
        this.host = host;

        this.listener = listener;
    }

    @Override
    public boolean isFinishedOK() {
        return finishedOK;
    }

    @Override
    public Error getConfirmRechargeError() {
        return confirmRechargeError;
    }

    @Override
    public void destroy() {
        if (storeManager != null)
            storeManager.close();
    }

    private void changeFragment(@SuppressWarnings("SameParameterValue") int fragmentID, Bundle args) {
        Fragment fragment = null;

        switch (fragmentID) {
            case FRAG_ID_GATEWAY:
                fragment = RechargeGatewayWebViewFragment.create(badResourcesListener, rechargeWebListener);
                break;
        }

        if (fragment == null) {
            finishKOBadResources();
            return;
        }

        if (args != null)
            fragment.setArguments(args);

        mFragmentManager.beginTransaction()
                .replace(containerViewId, fragment)
                .addToBackStack(null)
                .commit();
    }

    private void finishOK() {
        CoreController.getLogger().logDebug("CardRechargeActivityController::finishOK", "Recharge process ended OK.");
        if (listener != null) listener.onFinishOK();
    }

    private void finishKO(Error error) {
        CoreController.getLogger().logDebug("CardRechargeActivityController::finishKO", "Recharge process ended KO.");
        CoreController.getLogger().logError("CardRechargeActivityController::finishKO", error, "Recharge process ended KO.");
        if (listener != null) listener.onFinishKO(error);
    }

    private void finishKOBadResources() {
        finishKO(ErrorFactory.getFatalError(mContext, Error.GENERAL_INVALID_RESOURCES));
    }

    private boolean isDialogFragmentShowing(DialogFragment dialogFragment) {
        return dialogFragment != null && dialogFragment.getDialog() != null && dialogFragment.getDialog().isShowing();
    }

    private void showLoading(int idResource) {
        if (!isDialogFragmentShowing(loadingDialogFragment))
            loadingDialogFragment.show(mFragmentManager, "loginDialog");
        loadingDialogFragment.start(mContext.getString(idResource), null, false);
    }

    private void updateLoadingOK(String title, LoadDialogFragment.MyListener listener) {
        loadingDialogFragment.setListener(listener);
        loadingDialogFragment.finishOK(title, "", true);
    }

    private void updateLoadingKO(String title, Error error, boolean disableDismiss, LoadDialogFragment.MyListener listener) {
        loadingDialogFragment.setListener(listener);
        loadingDialogFragment.finishKO(title, error == null ? "" : error.getMsg(), disableDismiss);
    }

    private Error validate() {
        CoreController.getLogger().logDebug("CardRechargeActivityController::validate", "Validating request data.");
        if (mContext == null)
            return ErrorFactory.getGeneralContextError();
        if (mFragmentManager == null)
            return ErrorFactory.getGeneralContextError();
        if (containerViewId <= 0)
            return ErrorFactory.getFatalError(mContext, Error.GENERAL_INVALID_RESOURCES);
        if (host == null)
            return ErrorFactory.getWarnError(mContext, Error.GENERAL_INVALID_INPUT, new InvalidParameterException(String.format(mContext.getString(R.string.EXCEPTION_INVALID_INPUT), "host")));
        if (request == null)
            return ErrorFactory.getWarnError(mContext, Error.GENERAL_INVALID_INPUT, new InvalidParameterException(String.format(mContext.getString(R.string.EXCEPTION_INVALID_INPUT), "request")));

        String pwd = request.getPwd();
        int amount = -1;
        String pan = null;
        String cvv = null;
        String month = null;
        String year = null;
        if (request.getPayment() != null) {
            amount = request.getPayment().getAmount();
            pan = request.getPayment().getPan();
            cvv = request.getPayment().getCvv();
            month = request.getPayment().getMonth();
            year = request.getPayment().getYear();
        }

        if (pwd == null || pwd.isEmpty()) {
            return ErrorFactory.getWarnError(mContext, Error.GENERAL_INVALID_INPUT, new InvalidParameterException(String.format(mContext.getString(R.string.EXCEPTION_INVALID_INPUT), "pwd")));
        } else if (!RechargeController.validateMinAmount(amount)) {
            return ErrorFactory.getWarnError(mContext, Error.GENERAL_INVALID_INPUT, new InvalidParameterException(mContext.getString(R.string.EXCEPTION_BAD_AMOUNT_MIN)));
        } else if (!RechargeController.validatePan(pan)) {
            return ErrorFactory.getWarnError(mContext, Error.GENERAL_INVALID_INPUT, new InvalidParameterException(String.format(mContext.getString(R.string.EXCEPTION_INVALID_INPUT), "pan")));
        } else if (!RechargeController.validatePanLength(pan)) {
            return ErrorFactory.getWarnError(mContext, Error.GENERAL_INVALID_INPUT, new InvalidParameterException(mContext.getString(R.string.EXCEPTION_BAD_PAN_LENGTH)));
        } else if (!RechargeController.validateMoth(month)) {
            return ErrorFactory.getWarnError(mContext, Error.GENERAL_INVALID_INPUT, new InvalidParameterException(String.format(mContext.getString(R.string.EXCEPTION_INVALID_INPUT), "month")));
        } else if (!RechargeController.validateYear(year)) {
            return ErrorFactory.getWarnError(mContext, Error.GENERAL_INVALID_INPUT, new InvalidParameterException(String.format(mContext.getString(R.string.EXCEPTION_INVALID_INPUT), "year")));
        } else if (!RechargeController.validateCvv(cvv)) {
            return ErrorFactory.getWarnError(mContext, Error.GENERAL_INVALID_INPUT, new InvalidParameterException(String.format(mContext.getString(R.string.EXCEPTION_INVALID_INPUT), "cvv")));
        } else if (!RechargeController.validateCvvLength(cvv)) {
            return ErrorFactory.getWarnError(mContext, Error.GENERAL_INVALID_INPUT, new InvalidParameterException(mContext.getString(R.string.EXCEPTION_BAD_CVV_LENGTH)));
        } else {
            if (month.length() == 1 && Integer.valueOf(month) < 10)
                request.getPayment().setMonth("0" + month);

            return null;
        }
    }

    @Override
    public void startProcess() {
        CoreController.getLogger().logDebug("CardRechargeActivityController::startProcess", "Recharge process starting...");
        Error error = validate();
        if (error != null) {
            finishKO(error);
            return;
        }

        securityHelper = new SecurityHelper(mContext);
        storeManager = GaStoreFactory.getRealmGaStoreManager(mContext, securityHelper);
        restController = GaRestFactory.getRetrofitGaRestController(host);

        loadingDialogFragment = LoadDialogFragment.create(badResourcesListener, null);
        if (loadingDialogFragment == null) {
            finishKOBadResources();
            return;
        }

        CoreController.getLogger().logDebug("CardRechargeActivityController::startProcess", "First, doLogin+doSync for Authorization/Sync refresh.");
        showLoading(R.string.gatdefault_sending_request);
        RechargeController.doLogin(mContext, storeManager, restController, securityHelper, request.getPwd(), new RequestListener<Void>() {
            @Override
            public void onSuccess(Void response) {
                sendRequest(request.getPayment());
            }

            @Override
            public void onFailure(final Error error) {
                updateLoadingKO(mContext.getString(R.string.gatdefault_something_wrong), error, true, new LoadDialogFragment.MyListener() {
                    @Override
                    public void onConfirm(DialogFragment dialogFragment) {
                        finishKO(error);
                    }
                });
            }
        });
    }

    private void sendRequest(CardPayment request) {
        showLoading(R.string.gatdefault_sending_request);
        CoreController.getLogger().logDebug("CardRechargeActivityController::sendRequest", "Second, REST_Send CardRechargeRequest");
        // final Context mContext, String userToken, String user, String phoneId, String hwId, final CardRechargeRequest request, final RequestListener<Bundle> listener
        RechargeController.doCardRecharge(mContext, storeManager, restController, securityHelper, request, new RequestListener<CardRechargeResponse>() {
            @Override
            public void onSuccess(CardRechargeResponse response) {
                final String htmlForm = response.getForm();
                final String fee = AmountConverter.getDecimalAmountString(response.getFee());
                final boolean showConfirm = response.getFee() > 0;
                if (showConfirm) {
                    CoreController.getLogger().logDebug("CardRechargeActivityController::sendRequest", "Showing ConfirmFeeDialog");
                    ConfirmFeeDialogFragment confirmFeeDialog = ConfirmFeeDialogFragment.create(badResourcesListener, fee, new ConfirmFeeDialogFragment.MyListener() {
                        @Override
                        public void onConfirm() {
                            sendGateWayRequest(htmlForm);
                        }

                        @Override
                        public void onCancel() {
                            RechargeController.doDiscardRechargeConfirmRequest(mContext, new RequestListener<Void>() {
                                @Override
                                public void onSuccess(Void response) {
                                    finishKO(ErrorFactory.getWarnError(mContext, Error.RECHARGE_CANCELED));
                                }

                                @Override
                                public void onFailure(Error error) {
                                    finishKO(error);
                                }
                            });
                        }
                    });
                    if (confirmFeeDialog == null) {
                        RechargeController.doDiscardRechargeConfirmRequest(mContext, new RequestListener<Void>() {
                            @Override
                            public void onSuccess(Void response) {
                                finishKOBadResources();
                            }

                            @Override
                            public void onFailure(Error error) {
                                finishKO(error);
                            }
                        });
                    } else {
                        confirmFeeDialog.show(mFragmentManager, "confirmFeeDialog");
                    }
                } else
                    sendGateWayRequest(htmlForm);
            }

            @Override
            public void onFailure(final Error error) {
                updateLoadingKO(mContext.getString(R.string.gatdefault_something_wrong), error, true, new LoadDialogFragment.MyListener() {
                    @Override
                    public void onConfirm(DialogFragment dialogFragment) {
                        finishKO(error);
                    }
                });
            }
        });
    }

    private String getHtmlParameters(String html) {
        StringBuilder postDataBuilder = new StringBuilder();
        String[] lines = html.split(" {2}");
        for (int i = 0; i < lines.length; i++) {
            String[] partsLines = lines[i].split("\'");
            if (i > 0 && partsLines.length > 3)
                postDataBuilder.append(partsLines[1]).append("=").append(partsLines[3]).append("&");
        }

        return postDataBuilder.substring(0, postDataBuilder.length() - 1);
    }

    private String getPostURL(String html) {
        String[] lines = html.split(" {2}");
        return lines[0].split(" ")[1].split("=")[1];
    }

    private void sendGateWayRequest(String htmlForm) {
        // 1º comprobar datos del bundle. Si va mal finish ko con el error de bad gateway. Si va bien, commit confirm. Si va mal finish ko con el error (no debería pasar). 3ºSi va bien llamamos a la pasarela.

        CoreController.getLogger().logDebug("CardRechargeActivityController::sendGateWayRequest", "Validating GateWayForm.");

        String url;
        byte[] postData;
        String urlOK = null;
        String urlKO = null;
        try {
            url = getPostURL(htmlForm);
            String htmlParameters = getHtmlParameters(htmlForm);
            postData = htmlParameters.getBytes();

            String[] fields = htmlParameters.split("&");
            for (String field : fields) {
                if (field.contains("URL_OK=")) {
                    urlOK = field.split("URL_OK=")[1];
                } else if (field.contains("URL_NOK=")) {
                    urlKO = field.split("URL_NOK=")[1];
                }

            }

            if (url != null && !url.trim().isEmpty()
                    && postData != null && postData.length > 0
                    && urlOK != null && !urlOK.isEmpty()
                    && urlKO != null && !urlKO.isEmpty()) {
                final Bundle bundle = new Bundle();
                bundle.putString(RechargeGatewayWebViewFragment.BUNDLE_URL, url);
                bundle.putByteArray(RechargeGatewayWebViewFragment.BUNDLE_POST_DATA, postData);
                bundle.putString(RechargeGatewayWebViewFragment.BUNDLE_URL_OK, urlOK);
                bundle.putString(RechargeGatewayWebViewFragment.BUNDLE_URL_NOK, urlKO);


                CoreController.getLogger().logDebug("CardRechargeActivityController::sendGateWayRequest", "GateWayForm OK. Third, save PendingRechargeConfirm.");
                RechargeController.doCommitRechargeConfirmRequest(mContext, storeManager, new RequestListener<Void>() {
                    @Override
                    public void onSuccess(Void response) {
                        CoreController.getLogger().logDebug("CardRechargeActivityController::sendGateWayRequest", "POST_Send GateWayForm");

                        confirmRechargeError = ErrorFactory.getFatalError(mContext, Error.RECHARGE_CANNOT_CONFIRM);

                        changeFragment(FRAG_ID_GATEWAY, bundle);
                    }

                    @Override
                    public void onFailure(Error error) {
                        finishKO(error);
                    }
                });
            } else {
                finishKO(ErrorFactory.getFatalError(mContext, Error.RECHARGE_BAD_GATEWAY_FORM));
            }
        } catch (Exception e) {
            Error error = ErrorFactory.getFatalError(mContext, Error.RECHARGE_BAD_GATEWAY_FORM);
            error.setPreviousError(ErrorFactory.getFatalError(mContext, Error.GENERAL_UNEXPECTED_EXCEPTION, e));
            finishKO(error);
        }
    }

    private RechargeGatewayWebViewFragment.MyListener rechargeWebListener = new RechargeGatewayWebViewFragment.MyListener() {
        private final int MAX_CONFIRM_TRY = 3;
        private int confirmRechargeTry = 0;
        private boolean isConfirming = false;

        private boolean dismissOnFirstLoad = true;

        private void doUpdateConfirmRecharge(final String status) {
            CoreController.getLogger().logDebug("CardRechargeActivityController::doUpdateConfirmRecharge", "Fourth, DB_Update PendingRechargeConfirm. Status: " + status);
            RechargeController.doUpdateConfirmRecharge(mContext, storeManager, restController, securityHelper, new RequestListener<Void>() {
                @Override
                public void onSuccess(Void response) {
                    CoreController.getLogger().logDebug("CardRechargeActivityController::doUpdateConfirmRecharge", "DB_Update PendingRechargeConfirm OK");
                }

                @Override
                public void onFailure(Error error) {
                    CoreController.getLogger().logDebug("CardRechargeActivityController::doUpdateConfirmRecharge", "DB_Update PendingRechargeConfirm KO");
                    CoreController.getLogger().logError("CardRechargeActivityController::doUpdateConfirmRecharge", error, "DB_Update PendingRechargeConfirm KO");
                }
            }, status);
        }

        private void doConfirmRecharge() {
            isConfirming = true;
            showLoading(R.string.gatdefault_gateway_confirm_recharge);
            CoreController.getLogger().logDebug("CardRechargeActivityController::doConfirmRecharge", "Fith(Last), REST_Send PendingRechargeConfirm. Try: " + confirmRechargeTry + "/" + MAX_CONFIRM_TRY);
            RechargeController.doConfirmRecharge(mContext, storeManager, restController, securityHelper, new RequestListener<Void>() {
                @Override
                public void onSuccess(Void response) {
                    isConfirming = false;
                    finishedOK = true;
                    confirmRechargeError = null;
                    updateLoadingOK(mContext.getString(R.string.gatdefault_gateway_confirm_recharge_ok), new LoadDialogFragment.MyListener() {
                        @Override
                        public void onConfirm(DialogFragment dialogFragment) {
                            finish();
                        }
                    });
                }

                @Override
                public void onFailure(Error error) {
                    if (error != null) {
                        error.setPreviousError(confirmRechargeError);
                    }
                    confirmRechargeError = error;
                    isConfirming = false;

                    if (ErrorFactory.isRechargeCannotConfirmError(confirmRechargeError)) {
                        confirmRechargeTry++;
                        updateLoadingKO(String.format(mContext.getString(R.string.gatdefault_retry_request), String.valueOf(MAX_CONFIRM_TRY - confirmRechargeTry)), confirmRechargeError, true, new LoadDialogFragment.MyListener() {
                            @Override
                            public void onConfirm(DialogFragment dialogFragment) {
                                if (confirmRechargeTry < MAX_CONFIRM_TRY) {
                                    doConfirmRecharge();
                                } else {
                                    finish();
                                }
                            }
                        });
                    } else {
                        // Canceled Operation
                        updateLoadingKO(mContext.getString(R.string.gatdefault_gateway_confirm_recharge_ko), confirmRechargeError, true, new LoadDialogFragment.MyListener() {
                            @Override
                            public void onConfirm(DialogFragment dialogFragment) {
                                finish();
                            }
                        });
                    }
                }
            });
        }

        @Override
        public void onLoaded() {
            CoreController.getLogger().logDebug("CardRechargeActivityController::onLoaded", "Loaded new url");

            if (dismissOnFirstLoad && isDialogFragmentShowing(loadingDialogFragment))
                loadingDialogFragment.dismiss();
            dismissOnFirstLoad = false;
        }

        @Override
        public void onAccepted() {
            confirmRechargeError = null;
            doUpdateConfirmRecharge(BalanceRequest.OK);
        }

        @Override
        public void onRejected() {
            confirmRechargeError = ErrorFactory.getWarnError(mContext, Error.RECHARGE_REJECTED);
            doUpdateConfirmRecharge(BalanceRequest.NOK);
        }

        @Override
        public void onGateWayProblems(Exception e) {
            confirmRechargeError = ErrorFactory.getFatalError(mContext, Error.RECHARGE_GATEWAY_PROBLEMS, e);
            doUpdateConfirmRecharge(BalanceRequest.NO_RESPONSE);
        }

        @Override
        public void onFinished() {
            confirmRechargeTry = 0;
            doConfirmRecharge();
        }

        @Override
        public void onClosed() {
            // Ask for confirmation
            ConfirmDialogFragment confirmDialog = ConfirmDialogFragment.create(badResourcesListener, R.string.gatdefault_gateway_confirm_close, new ConfirmDialogFragment.MyListener() {
                @Override
                public void onConfirm() {
                    if (isConfirming || finishedOK)
                        return; // Can not ocurr. But then wait for confirm result.
                    if (confirmRechargeError == null) // Create CANNOT_CONFIRM ERROR
                        confirmRechargeError = ErrorFactory.getFatalError(mContext, Error.RECHARGE_CANNOT_CONFIRM);

                    showLoading(R.string.gatdefault_gateway_confirm_recharge);
                    updateLoadingKO(mContext.getString(R.string.gatdefault_gateway_confirm_recharge_ko), confirmRechargeError, true, new LoadDialogFragment.MyListener() {
                        @Override
                        public void onConfirm(DialogFragment dialogFragment) {
                            finish();
                        }
                    });
                }

                @Override
                public void onCancel() {
                    // Nothing
                }
            });
            if (confirmDialog != null) {
                confirmDialog.show(mFragmentManager, "confirmDialog");
            }
        }

        private void finish() {
            if (confirmRechargeError != null) {
                finishKO(confirmRechargeError);
            } else {
                finishOK();
            }
        }
    };
}
