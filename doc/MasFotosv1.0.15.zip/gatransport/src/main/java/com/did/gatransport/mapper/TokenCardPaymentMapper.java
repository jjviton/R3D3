package com.did.gatransport.mapper;

import com.did.gatransport.model.TokenCardPayment;
import com.did.gatransport.rest.model.response.TokenCard;

import java.util.ArrayList;
import java.util.List;

public final class TokenCardPaymentMapper extends Mapper<TokenCardPayment, Void, TokenCard> {

    @Override
    public TokenCardPayment restToUi(TokenCard obj) {
        TokenCardPayment tokenCard = new TokenCardPayment();
        tokenCard.setId(obj.getId());
        tokenCard.setBin(obj.getBin());
        tokenCard.setLast(obj.getLast());
        tokenCard.setExpiration(obj.getExpiration());
        return tokenCard;
    }

    public List<TokenCardPayment> restToUiList(List<TokenCard> list) {
        List<TokenCardPayment> result = new ArrayList<>();
        if (list != null) {
            for (TokenCard item : list) {
                result.add(restToUi(item));
            }
        }
        return result;
    }
}
