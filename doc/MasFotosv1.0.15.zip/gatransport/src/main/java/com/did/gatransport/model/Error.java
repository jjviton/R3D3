package com.did.gatransport.model;

import com.google.gson.annotations.SerializedName;

public class Error {

    public static final int LEVEL_NON_FATAL = 0;
    public static final int LEVEL_WARN = 1;
    public static final int LEVEL_HTTP = 8;
    public static final int LEVEL_FATAL = 9;

    public static final int BASE = 1000;

    public static final int GENERAL_NEED_INITIALIZE = 1;
    public static final int GENERAL_INVALID_CONTEXT = 2;
    public static final int GENERAL_NO_PERMISSIONS_GRANTED = 3;
    public static final int GENERAL_INVALID_USER = 5;
    public static final int GENERAL_USER_NOT_EXISTS = 6;
    public static final int GENERAL_INVALID_INPUT = 10;
    public static final int GENERAL_PROCESS_IS_RUNNING = 11;
    public static final int GENERAL_CARD_LOCKED_BY_HOST = 12;
    public static final int GENERAL_CARD_UNSUBSCRIBED_BY_HOST = 13;
    public static final int GENERAL_UNEXPECTED_EXCEPTION = 14;
    public static final int GENERAL_INVALID_RESOURCES = 15;
    public static final int GENERAL_PENDING_RECHARGE_CONFIRM_NOT_EXISTS = 16;

    public static final int SECURITY_UKN_ERROR = 100;
    public static final int SECURITY_ROOTED = 101;
    public static final int SECURITY_NO_SYSTEM_ENCRYPT = 102;
    public static final int SECURITY_NO_LOCK = 103;
    public static final int SECURITY_NO_HW_ID = 104;
    public static final int SECURITY_BAD_DATE = 105;

    public static final int ENROLL_USER_ENROLLED = 201;
    public static final int ENROLL_NO_DNI_PAN_ENROLLMENT = 202;
    public static final int ENROLL_BAD_RESPONSE_1 = 206;
    public static final int ENROLL_BAD_RESPONSE_2 = 207;
    public static final int ENROLL_USER_HAS_OLD_CARD = 212;
    public static final int ENROLL_CANNOT_UPDATE_PROFILE = 213;

    public static final int RECHARGE_INACTIVE = 308;
    public static final int RECHARGE_REJECTED = 309;
    public static final int RECHARGE_CANCELED = 310;
    public static final int RECHARGE_BAD_GATEWAY_FORM = 311;
    public static final int RECHARGE_GATEWAY_PROBLEMS = 312;
    public static final int RECHARGE_CANNOT_CONFIRM = 314;

    public static final int CARD_LOCKED = 400;
    public static final int CARD_LOCKED_NEED_SYNC = 401;
    public static final int CARD_LOCKED_MANUALLY = 402;
    public static final int CARD_LOCKED_NEED_LOGIN = 403;
    public static final int CARD_LOCKED_NEED_CONFIRM_RECHARGE = 404;
    public static final int CARD_NEED_CONFIRM_PROFILE_UPDATE = 406;
    public static final int CARD_LOCKED_NO_DATA = 407;

    public static final int STORE_NOT_SECURE = 500;
    // Repasra
    public static final int STORE_ERROR_INSERTING_TRANSACTION = 506;
    public static final int STORE_REFRESHING_KEYS = 507;
    public static final int STORE_NOT_VALID_TABLE = 509;
    public static final int STORE_BAD_MIGRATION = 510;
    public static final int STORE_CANNOT_OPEN = 514;
    public static final int STORE_TABLE_CORRUPTED = 515;

    public static final int REST_CONNECTION = 600;
    public static final int REST_THROWABLE = 601;
    public static final int REST_RESPONSE = 602;


    @SerializedName("level")
    private int level;

    @SerializedName("code")
    private int code;

    @SerializedName("msg")
    private String msg;

    @SerializedName("exception")
    private Throwable exception;

    @SerializedName("time")
    private long time;

    @SerializedName("previousError")
    private Error previousError;

    public Error() {
    }

    public Error(int level, int code, String msg, Throwable exception, long time) {
        this.level = level;
        this.code = code;
        this.msg = msg;
        this.exception = exception;
        this.time = time;
    }

    public final int getLevel() {
        return level;
    }

    public final void setLevel(int level) {
        this.level = level;
    }

    public final int getCode() {
        return code;
    }

    public final void setCode(int code) {
        this.code = code;
    }

    public final String getMsg() {
        return msg;
    }

    public final void setMsg(String msg) {
        this.msg = msg;
    }

    public final Throwable getException() {
        return exception;
    }

    public final void setException(Throwable exception) {
        this.exception = exception;
    }

    public final long getTime() {
        return time;
    }

    public final void setTime(long time) {
        this.time = time;
    }

    public final Error getPreviousError() {
        return previousError;
    }

    public final void setPreviousError(Error previousError) {
        this.previousError = previousError;
    }
}
