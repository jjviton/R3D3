package com.did.gatransport.store.realm;

import android.content.ContextWrapper;
import android.support.annotation.NonNull;

import com.did.gatransport.controller.CoreController;
import com.did.gatransport.controller.ProcessController;
import com.did.gatransport.interfaces.RequestListener;
import com.did.gatransport.model.Error;
import com.did.gatransport.store.GaStoreManager;
import com.did.gatransport.store.GaStoreSecurityElement;
import com.did.gatransport.store.model.GaCard;
import com.did.gatransport.store.model.ProfileUpdateConfirmRequest;
import com.did.gatransport.store.model.RechargeConfirmRequest;
import com.did.gatransport.store.model.Transaction;
import com.did.gatransport.store.model.User;
import com.did.gatransport.store.realm.model.GaCardRealm;
import com.did.gatransport.store.realm.model.ProfileUpdateConfirmRequestRealm;
import com.did.gatransport.store.realm.model.RechargeConfirmRequestRealm;
import com.did.gatransport.store.realm.model.RechargeRealm;
import com.did.gatransport.store.realm.model.TransactionRealm;
import com.did.gatransport.store.realm.model.TripRealm;
import com.did.gatransport.store.realm.model.UserRealm;
import com.did.gatransport.util.ErrorFactory;
import com.google.gson.Gson;

import java.security.InvalidParameterException;
import java.util.ArrayList;
import java.util.List;

import io.realm.Realm;
import io.realm.RealmConfiguration;
import io.realm.RealmResults;
import io.realm.Sort;

public final class RealmGaStoreManager implements GaStoreManager {

    public interface RealmLifeListener {
        void onMigrate();

        void onError(Error error);
    }

    private static final int CURRENT_DB_VERSION = 7;

    private static final Gson GSON = new Gson();
    private static final String WHERE_DATE = "date";
    private static final String WHERE_NT = "nt";
    private static final String WHERE_STATE = "state";

    private static final int MAX_TABLE_SIZE_RECHARGE = 20;
    private static final int MAX_TABLE_SIZE_TRIP = 20;

    private ContextWrapper mContext;
    private Realm realm;
    private RealmConfiguration realmConfiguration;
    private GaStoreSecurityElement storeSecurityElement;

    private boolean wasMigrated = false;
    private Error migrationError = null;

    private final RealmLifeListener lifeListener = new RealmGaStoreManager.RealmLifeListener() {
        @Override
        public void onMigrate() {
            wasMigrated = true;
        }

        @Override
        public void onError(Error error) {
            CoreController.getLogger().logError("RealmLifeListener::onError", error);
            migrationError = error;
        }
    };

    public RealmGaStoreManager(ContextWrapper context, GaStoreSecurityElement storeSecurityElement) {
        this.mContext = context;
        this.storeSecurityElement = storeSecurityElement;

        Realm.init(mContext);
        open();
    }

    private void configureRealm() throws Exception {
        //noinspection StatementWithEmptyBody
        while (ProcessController.isRkIsRunning()) ;
        byte[] encryptionKey = storeSecurityElement.getEncryptionKey();
        if (encryptionKey != null && encryptionKey.length > 0) {
            this.realmConfiguration = new RealmConfiguration.Builder()
                    .schemaVersion(CURRENT_DB_VERSION)
                    .directory(mContext.getNoBackupFilesDir())
                    .migration(new Migration(lifeListener))
//                .deleteRealmIfMigrationNeeded()
                    .encryptionKey(encryptionKey)
                    .build();
        } else {
            this.realmConfiguration = null;
        }
    }

    private void executeTransaction(Realm.Transaction transaction, RequestListener<Void> listener) {
        if (transaction == null) return;
        realm.executeTransaction(transaction);
        updateHash();
        if (listener != null)
            listener.onSuccess(null);
    }

    private void executeTransactionAsync(Realm.Transaction transaction, final RequestListener<Void> listener) {
        if (transaction == null) return;
        realm.executeTransactionAsync(transaction, new Realm.Transaction.OnSuccess() {
            @Override
            public void onSuccess() {
                updateHash();
                if (listener != null)
                    listener.onSuccess(null);
            }
        }, new Realm.Transaction.OnError() {
            @Override
            public void onError(Throwable error) {
                updateHash();
                if (listener != null)
                    listener.onFailure(ErrorFactory.getFatalError(mContext, Error.GENERAL_UNEXPECTED_EXCEPTION, error));
            }
        });
    }

    @Override
    public String getPath() {
        return realm != null ? realm.getPath() : null;
    }

    @Override
    public Error open() {
        Exception ex = null;
        try {
            if (realmConfiguration == null) {
                configureRealm();
            }
            if (realm == null && realmConfiguration != null) {
                realm = Realm.getInstance(realmConfiguration);
            }
            if (realm != null && wasMigrated) {
                updateHash();
                wasMigrated = false;
            }
        } catch (Exception e) {
            ex = e;
        }
        if (ex != null || realm == null) {
            Error error = ErrorFactory.getFatalError(mContext, Error.STORE_CANNOT_OPEN, ex);
            if (migrationError != null)
                error.setPreviousError(migrationError);
            return error;
        } else if (migrationError != null) {
            return migrationError;
        }
        return null;
    }

    @Override
    public void close() {
        if (realm != null)
            realm.close();
        realm = null;
    }

    private boolean ready = false;
    private final Object lock = new Object();

    @Override
    public void reset() {
        if (realm == null) return;
        ready = false;
        executeTransaction(new Realm.Transaction() {
            @Override
            public void execute(@NonNull Realm realm) {
                realm.deleteAll();
            }
        }, new RequestListener<Void>() {
            @Override
            public void onSuccess(Void response) {
                synchronized (lock) {
                    ready = true;
                    lock.notifyAll();
                }
                CoreController.getLogger().logDebug("RealmGaStoreManager::reset", "rt start!");
                refreshKey(new RequestListener<Void>() {
                    @Override
                    public void onSuccess(Void response) {
                        CoreController.getLogger().logDebug("RealmGaStoreManager::reset", "rt ok!");
                    }

                    @Override
                    public void onFailure(Error error) {
                        CoreController.getLogger().logDebug("RealmGaStoreManager::reset", "rt ko!");
                    }
                });
            }

            @Override
            public void onFailure(Error error) {
                CoreController.getLogger().logError("RealmGaStoreManager::reset", error, "[ERROR] on reset");
                synchronized (lock) {
                    ready = true;
                    lock.notifyAll();
                }
            }
        });
        synchronized (lock) {
            while (!ready) {
                try {
                    lock.wait();
                } catch (Exception e) {
                    CoreController.getLogger().logError("GaCardManager::reset", "[ERROR] on reset", e);
                }
            }
        }
        realm = null;
    }

    @Override
    public void insert(final Object obj, RequestListener<Void> listener) {
        if (checkRealmInstanceCorrupted(listener)) return;

        synchronized (this) {
            if (obj instanceof TripRealm)
                insertTrip((TripRealm) obj, listener);
            else if (obj instanceof RechargeRealm)
                insertRecharge((RechargeRealm) obj, listener);
            else if (obj instanceof TransactionRealm)
                insertTransaction((TransactionRealm) obj, listener);
            else if (obj instanceof UserRealm)
                insertUser((UserRealm) obj, listener);
            else if ((obj instanceof GaCardRealm))
                insertGaCard((GaCardRealm) obj, listener);
            else if ((obj instanceof RechargeConfirmRequest))
                insertRechargeConfirmRequest((RechargeConfirmRequestRealm) obj, listener);
            else if ((obj instanceof ProfileUpdateConfirmRequest))
                insertUpdateConfirmConfirmRequest((ProfileUpdateConfirmRequestRealm) obj, listener);
        }
    }

    @Override
    public void deleteAll(int tableId, RequestListener<Void> listener) {
        if (checkRealmInstanceCorrupted(listener)) return;

        switch (tableId) {
            case TABLE_RECHARGE_CONFIRM:
                deleteRechargeConfirmRequest(listener);
                break;
            case TABLE_UPDATE_PROFILE_CONFIRM:
                deleteProfileUpdateConfirmRequest(listener);
                break;
            default:
                if (listener != null)
                    listener.onFailure(ErrorFactory.getNonFatalError(mContext, Error.STORE_NOT_VALID_TABLE));
                break;
        }
    }

    @Override
    public void getAll(int tableId, RequestListener<List<Object>> listener) {
        if (checkRealmInstanceCorrupted(listener)) return;

        switch (tableId) {
            case TABLE_TRIP:
                getTrips(listener);
                break;
            case TABLE_RECHARGE:
                getRecharges(listener);
                break;
            case TABLE_TRANSACTIONS:
                getTransactions(listener);
                break;
            default:
                if (listener != null)
                    listener.onFailure(ErrorFactory.getNonFatalError(mContext, Error.STORE_NOT_VALID_TABLE));
                break;
        }
    }

    @Override
    public void deleteSentTransactions(RequestListener<Void> listener) {
        if (checkRealmInstanceCorrupted(listener)) return;

        executeTransaction(new Realm.Transaction() {
            @Override
            public void execute(@NonNull Realm realm) {
                RealmResults<TransactionRealm> result = realm.where(TransactionRealm.class)
                        .equalTo(WHERE_STATE, Transaction.STATE_SENT)
                        .findAll();
                result.deleteAllFromRealm();
            }
        }, listener);
    }

    @Override
    public void getPendingTransactions(RequestListener<List<Transaction>> listener) {
        if (checkRealmInstanceCorrupted(listener)) return;

        RealmResults<TransactionRealm> result = realm.where(TransactionRealm.class)
                .equalTo(WHERE_STATE, Transaction.STATE_PENDING)
                .findAll();

        listener.onSuccess(new ArrayList<Transaction>(realm.copyFromRealm(result)));
    }

    @Override
    public void hasPendingTransactions(final RequestListener<Boolean> listener) {
        if (checkRealmInstanceCorrupted(listener)) return;

        getPendingTransactions(new RequestListener<List<Transaction>>() {
            @Override
            public void onSuccess(List<Transaction> response) {
                if (response.size() > 0)
                    listener.onSuccess(true);
                else
                    listener.onSuccess(false);
            }

            @Override
            public void onFailure(Error error) {
                listener.onFailure(error);
            }
        });
    }

    @Override
    public void updateTransactionToSent(final int lastNtSynchronized, RequestListener<Void> listener) {
        if (checkRealmInstanceCorrupted(listener)) return;

        executeTransaction(new Realm.Transaction() {
            @Override
            public void execute(@NonNull Realm realm) {
                RealmResults<TransactionRealm> result = realm.where(TransactionRealm.class)
                        .equalTo(WHERE_STATE, Transaction.STATE_PENDING)
                        .and()
                        .lessThanOrEqualTo(WHERE_NT, lastNtSynchronized)
                        .findAll();
                ArrayList<TransactionRealm> transactions = new ArrayList<>(result);
                for (TransactionRealm t1 : transactions) {
                    t1.setState(Transaction.STATE_SENT);
                }
            }
        }, listener);
    }

    @Deprecated
    @Override
    public void updateTransactionToSent(final List<Transaction> list, RequestListener<Void> listener) {
        if (checkRealmInstanceCorrupted(listener)) return;

        executeTransaction(new Realm.Transaction() {
            @Override
            public void execute(@NonNull Realm realm) {
                RealmResults<TransactionRealm> result = realm.where(TransactionRealm.class)
                        .equalTo(WHERE_STATE, Transaction.STATE_PENDING)
                        .findAll();
                ArrayList<TransactionRealm> transactions = new ArrayList<>(result);
                for (TransactionRealm t1 : transactions) {
                    for (Transaction t2 : list) {
                        if (t1 != null && t2 != null && t1.getNt() == t2.getNt()) {
                            t1.setState(Transaction.STATE_SENT);
                        }
                    }
                }
            }
        }, listener);
    }

    @Override
    public void getLastTransaction(RequestListener<Transaction> listener) {
        if (checkRealmInstanceCorrupted(listener)) return;

        RealmResults<TransactionRealm> result = realm.where(TransactionRealm.class)
                .findAll().sort(WHERE_NT, Sort.DESCENDING);

        if (result.size() > 0) {
            listener.onSuccess(result.first());
        } else {
            //Should never happen because in the enrolment you start wth one transaction to 0.00 €
            listener.onSuccess(null);
        }
    }

    @Override
    public void getUser(RequestListener<User> listener) {
        if (checkRealmInstanceCorrupted(listener)) return;

        RealmResults<UserRealm> result = realm.where(UserRealm.class)
                .findAll();

        if (result.size() > 0)
            listener.onSuccess(result.last());
        else
            listener.onSuccess(null);
    }

    @Override
    public void updateUserToken(final String token, final RequestListener<Void> listener) {
        if (checkRealmInstanceCorrupted(listener)) return;

        executeTransaction(new Realm.Transaction() {
            @Override
            public void execute(@NonNull Realm realm) {
                RealmResults<UserRealm> result = realm.where(UserRealm.class)
                        .findAll();

                if (result.size() > 0)
                    result.last().setToken(token);
            }
        }, listener);
    }

    @Override
    public void updateUserProfile(final String profileType, final String profileExpiration, final RequestListener<Void> listener) {
        if (checkRealmInstanceCorrupted(listener)) return;

        executeTransaction(new Realm.Transaction() {
            @Override
            public void execute(@NonNull Realm realm) {
                RealmResults<UserRealm> result = realm.where(UserRealm.class)
                        .findAll();

                if (result.size() > 0) {
                    result.last().setProfileType(profileType);
                    result.last().setProfileExpiration(profileExpiration);
                }
            }
        }, listener);
    }

    @Override
    public void getGaCard(RequestListener<GaCard> listener) {
        if (checkRealmInstanceCorrupted(listener)) return;

        RealmResults<GaCardRealm> result = realm.where(GaCardRealm.class)
                .findAll();
        if (result.size() == 0)
            listener.onSuccess(null);
        else if (result.size() == 1)
            listener.onSuccess(result.last());
        else
            listener.onFailure(ErrorFactory.getFatalError(mContext, Error.STORE_TABLE_CORRUPTED));
    }

    @Override
    public void getRechargeConfirmRequest(RequestListener<RechargeConfirmRequest> listener) {
        if (checkRealmInstanceCorrupted(listener)) return;

        RealmResults<RechargeConfirmRequestRealm> result = realm.where(RechargeConfirmRequestRealm.class)
                .findAll();
        if (result.size() == 0)
            listener.onSuccess(null);
        else if (result.size() == 1)
            listener.onSuccess(result.last());
        else
            listener.onFailure(ErrorFactory.getFatalError(mContext, Error.STORE_TABLE_CORRUPTED));
    }

    @Override
    public void updateRechargeConfirmRequest(final String status, final RequestListener<Void> listener) {
        if (checkRealmInstanceCorrupted(listener)) return;


        executeTransaction(new Realm.Transaction() {
            @Override
            public void execute(@NonNull Realm realm) {
                RealmResults<RechargeConfirmRequestRealm> result = realm.where(RechargeConfirmRequestRealm.class)
                        .findAll();
                if (result.size() > 0)
                    result.last().setStatus(status);
            }
        }, listener);
    }

    @Override
    public void updateRechargeConfirmRequestId(final String refId, final RequestListener<RechargeConfirmRequest> listener) {
        if (checkRealmInstanceCorrupted(listener)) return;


        executeTransaction(new Realm.Transaction() {
            @Override
            public void execute(@NonNull Realm realm) {
                RealmResults<RechargeConfirmRequestRealm> result = realm.where(RechargeConfirmRequestRealm.class)
                        .findAll();
                if (result.size() > 0)
                    result.last().setRefId(refId);
            }
        }, new RequestListener<Void>() {
            @Override
            public void onSuccess(Void response) {
                getRechargeConfirmRequest(listener);
            }

            @Override
            public void onFailure(Error error) {
                if (listener != null)
                    listener.onFailure(error);
            }
        });
    }

    @Override
    public void getProfileUpdateConfirmRequest(RequestListener<ProfileUpdateConfirmRequest> listener) {
        if (checkRealmInstanceCorrupted(listener)) return;

        RealmResults<ProfileUpdateConfirmRequestRealm> result = realm.where(ProfileUpdateConfirmRequestRealm.class)
                .findAll();
        if (result.size() == 0)
            listener.onSuccess(null);
        else if (result.size() == 1)
            listener.onSuccess(result.last());
        else
            listener.onFailure(ErrorFactory.getFatalError(mContext, Error.STORE_TABLE_CORRUPTED));
    }

    @Override
    public boolean checkGaCard() {
        return realm != null
                && realm.where(GaCardRealm.class)
                .count() > 0;
    }

    @Override
    public boolean checkPendingTransactions() {
        return realm != null
                && realm.where(TransactionRealm.class)
                .equalTo(WHERE_STATE, Transaction.STATE_PENDING)
                .count() > 0;
    }

    @Override
    public boolean checkMaxPendingTransactionsReached() {
        return realm != null
                && realm.where(TransactionRealm.class)
                .equalTo(WHERE_STATE, Transaction.STATE_PENDING)
                .count() >= MAX_TRANSACTION_NOSYNC;
    }

    @Override
    public boolean checkPendingRechargeConfirmRequest() {
        return realm != null
                && realm.where(RechargeConfirmRequestRealm.class)
                .count() > 0;
    }

    @Override
    public boolean checkPendingProfileUpdateConfirmRequest() {
        return realm != null
                && realm.where(ProfileUpdateConfirmRequestRealm.class)
                .count() > 0;
    }

    @Override
    public void refreshKey(RequestListener<Void> listener) {
        storeSecurityElement.refreshEncryptionKey(listener);
    }

    private void insertTrip(final TripRealm trip, RequestListener<Void> listener) {
        executeTransaction(new Realm.Transaction() {
            @Override
            public void execute(@NonNull Realm realm) {
                realm.copyToRealm(trip);

                // Check if need to clear, if yes then clear
                RealmResults<TripRealm> result = realm.where(TripRealm.class)
                        .findAll().sort(WHERE_DATE, Sort.DESCENDING);
                while (result.size() > MAX_TABLE_SIZE_TRIP) {
                    result.deleteLastFromRealm();
                }
            }
        }, listener);
    }

    private void insertRecharge(final RechargeRealm recharge, RequestListener<Void> listener) {
        executeTransaction(new Realm.Transaction() {
            @Override
            public void execute(@NonNull Realm realm) {
                realm.copyToRealm(recharge);

                // Check if need to clear, if yes then clear
                RealmResults<RechargeRealm> result = realm.where(RechargeRealm.class)
                        .findAll().sort(WHERE_DATE, Sort.DESCENDING);
                while (result.size() > MAX_TABLE_SIZE_RECHARGE) {
                    result.deleteLastFromRealm();
                }
            }
        }, listener);
    }

    private void insertTransaction(final TransactionRealm transaction, final RequestListener<Void> listener) {
        getLastTransaction(new RequestListener<Transaction>() {
            @Override
            public void onSuccess(Transaction response) {
                if (response == null || response.getNt() != transaction.getNt()) {
                    executeTransaction(new Realm.Transaction() {
                        @Override
                        public void execute(@NonNull Realm realm) {
                            realm.copyToRealm(transaction);
                        }
                    }, listener);
                } else {
                    listener.onFailure(ErrorFactory.getFatalError(mContext, Error.STORE_ERROR_INSERTING_TRANSACTION, new InvalidParameterException("Transaction repeated.")));
                }
            }

            @Override
            public void onFailure(Error error) {
                listener.onFailure(error);
            }
        });
    }

    private void insertUser(final UserRealm user, RequestListener<Void> listener) {
        executeTransaction(new Realm.Transaction() {
            @Override
            public void execute(@NonNull Realm realm) {
                realm.copyToRealm(user);
            }
        }, listener);
    }

    private void insertGaCard(final GaCardRealm gaCardRealm, RequestListener<Void> listener) {
        executeTransaction(new Realm.Transaction() {
            @Override
            public void execute(@NonNull Realm realm) {
                gaCardRealm.setId(1);
                realm.insertOrUpdate(gaCardRealm);
            }
        }, listener);
    }

    private void insertRechargeConfirmRequest(final RechargeConfirmRequestRealm rechargeConfirmRequestRealm, RequestListener<Void> listener) {
        executeTransaction(new Realm.Transaction() {
            @Override
            public void execute(@NonNull Realm realm) {
                rechargeConfirmRequestRealm.setId(1);
                realm.insertOrUpdate(rechargeConfirmRequestRealm);
            }
        }, listener);
    }

    private void insertUpdateConfirmConfirmRequest(final ProfileUpdateConfirmRequestRealm updateProfileConfirmRequest, RequestListener<Void> listener) {
        executeTransaction(new Realm.Transaction() {
            @Override
            public void execute(@NonNull Realm realm) {
                updateProfileConfirmRequest.setId(1);
                realm.insertOrUpdate(updateProfileConfirmRequest);
            }
        }, listener);
    }

    private void updateHash() {
        storeSecurityElement.updateHash(getPath());
    }

    private void deleteRechargeConfirmRequest(RequestListener<Void> listener) {
        executeTransaction(new Realm.Transaction() {
            @Override
            public void execute(@NonNull Realm realm) {
                realm.delete(RechargeConfirmRequestRealm.class);
            }
        }, listener);
    }

    private void deleteProfileUpdateConfirmRequest(RequestListener<Void> listener) {
        executeTransaction(new Realm.Transaction() {
            @Override
            public void execute(@NonNull Realm realm) {
                realm.delete(ProfileUpdateConfirmRequestRealm.class);
            }
        }, listener);
    }

    private void getTrips(RequestListener<List<Object>> listener) {
        RealmResults<TripRealm> result = realm.where(TripRealm.class)
                .findAll().sort(WHERE_DATE, Sort.DESCENDING);

        listener.onSuccess(new ArrayList<Object>(realm.copyFromRealm(result)));
    }

    private void getRecharges(RequestListener<List<Object>> listener) {
        RealmResults<RechargeRealm> result = realm.where(RechargeRealm.class)
                .findAll().sort(WHERE_DATE, Sort.DESCENDING);

        listener.onSuccess(new ArrayList<Object>(realm.copyFromRealm(result)));
    }

    private void getTransactions(RequestListener<List<Object>> listener) {
        RealmResults<TransactionRealm> result = realm.where(TransactionRealm.class)
                .findAll().sort(WHERE_DATE, Sort.DESCENDING);

        listener.onSuccess(new ArrayList<Object>(realm.copyFromRealm(result)));
    }

    private boolean checkSecurity(RequestListener listener) {
        if (!storeSecurityElement.isValidHash(getPath())) {
            if (listener != null)
                listener.onFailure(ErrorFactory.getFatalError(mContext, Error.STORE_NOT_SECURE));
            return true;
        } else if (!storeSecurityElement.isValidDate(getPath())) {
            if (listener != null)
                listener.onFailure(ErrorFactory.getFatalError(mContext, Error.SECURITY_BAD_DATE));
            return true;
        } else
            return false;
    }

    private boolean checkRealmInstanceCorrupted(RequestListener listener) {
        Error error = null;
        if (realm == null) {
            error = open();
        }
        if (error != null) {
            if (listener != null) {
                listener.onFailure(error);
            }
            return true;
        } else {
            return checkSecurity(listener);
        }
    }
}
