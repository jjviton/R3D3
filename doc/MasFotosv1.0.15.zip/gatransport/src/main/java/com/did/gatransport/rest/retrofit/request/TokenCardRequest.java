package com.did.gatransport.rest.retrofit.request;

import com.google.gson.annotations.SerializedName;

public final class TokenCardRequest {

    @SerializedName("Phone_ID")
    private String phoneId;
    @SerializedName("HW_ID")
    private String hwId;
    @SerializedName("User_ID")
    private String userId;

    public TokenCardRequest() {
    }

    public String getPhoneId() {
        return phoneId;
    }

    public void setPhoneId(String phoneId) {
        this.phoneId = phoneId;
    }

    public String getHwId() {
        return hwId;
    }

    public void setHwId(String hwId) {
        this.hwId = hwId;
    }

    public String getUserId() {
        return userId;
    }

    public void setUserId(String userId) {
        this.userId = userId;
    }
}
