package com.did.gacard.util;

public class GaCardException extends Exception {

    public GaCardException() {
    }

    public GaCardException(String message) {
        super(message);
    }

    public GaCardException(String message, Throwable cause) {
        super(message, cause);
    }

    public GaCardException(Throwable cause) {
        super(cause);
    }

}
