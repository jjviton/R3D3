package com.did.gatransport.rest.model.response;

import com.google.gson.annotations.SerializedName;

public final class EnrollResponse extends BaseResponse {

    @SerializedName("ID")
    private String id;
    @SerializedName("Token_ID")
    private String tokenId;

    public EnrollResponse() {
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getTokenId() {
        return tokenId;
    }

    public void setTokenId(String tokenId) {
        this.tokenId = tokenId;
    }
}
