package com.did.gatransport.model.request;

import com.did.gatransport.rest.retrofit.request.ManageRequest;

public final class ManageCardRequest {

    // Status
    public static final String STATUS_LOCK = ManageRequest.STATUS_LOCK;
    private static final String STATUS_UNLOCK = ManageRequest.STATUS_UNLOCK;
    public static final String STATUS_UNSUBSCRIBE = ManageRequest.STATUS_UNSUBSCRIBE;

    // Cause
    public static final String CAUSE_LOCK = ManageRequest.CAUSE_LOCK;
    private static final String CAUSE_UNLOCK = ManageRequest.CAUSE_UNLOCK;
    public static final String CAUSE_UNSUBSCRIBE = ManageRequest.CAUSE_UNSUBSCRIBE;

    // Indicator
    public static final String INDICATOR_MONEDERO = ManageRequest.INDICATOR_MONEDERO;
    public static final String INDICATOR_FINANCIERA = ManageRequest.INDICATOR_FINANCIERA;
    public static final String INDICATOR_IBAN = ManageRequest.INDICATOR_IBAN;

    private String user;
    private String pwd;
    private String status = "";
    private String cause = "";
    private String indicator = "";
    private String method = "";

    public ManageCardRequest() {
    }

    public ManageCardRequest(String user, String pwd, String status, String cause, String indicator, String method) {
        this.user = user;
        this.pwd = pwd;
        this.status = status;
        this.cause = cause;
        this.indicator = indicator;
        this.method = method;
    }

    public String getUser() {
        return user;
    }

    public void setUser(String user) {
        this.user = user;
    }

    public String getPwd() {
        return pwd;
    }

    public void setPwd(String pwd) {
        this.pwd = pwd;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getCause() {
        return cause;
    }

    public void setCause(String cause) {
        this.cause = cause;
    }

    public String getIndicator() {
        return indicator;
    }

    public void setIndicator(String indicator) {
        this.indicator = indicator;
    }

    public String getMethod() {
        return method;
    }

    public void setMethod(String method) {
        this.method = method;
    }
}
