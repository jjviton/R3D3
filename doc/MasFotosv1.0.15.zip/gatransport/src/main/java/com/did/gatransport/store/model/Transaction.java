package com.did.gatransport.store.model;

import com.did.gatransport.rest.model.TransactionLine;

public interface Transaction {

    int STATE_PENDING = 1;
    int STATE_SENT = 2;

    String TYPE_DEBIT = TransactionLine.TYPE_DEBIT;
    String TYPE_CANCEL = TransactionLine.TYPE_CANCEL;

    void setBalance(int balance);

    int getBalance();

    void setDate(long date);

    long getDate();

    void setState(int state);

    int getState();

    void setNt(int nt);

    int getNt();

    void setAmount(int amount);

    int getAmount();

    void setType(String type);

    String getType();
}
