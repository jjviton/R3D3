package com.did.gatransport.interfaces;

import com.did.gacard.ecard.core.NFCFieldStateListener;
import com.did.gatransport.model.Error;
import com.did.gatransport.model.Trip;

public interface TripListener extends NFCFieldStateListener {

    void onSelected();

    void onSuccess(Trip trip);

    void onFailure(Error error);

}
