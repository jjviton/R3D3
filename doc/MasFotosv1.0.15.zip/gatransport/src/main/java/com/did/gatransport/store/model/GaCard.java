package com.did.gatransport.store.model;

public interface GaCard {

    void setFile(String file);

    String getFile();

}
