package com.did.gatransport.controller;

public final class ProcessController {
    private static boolean ST_IS_RUNNING = false; // Sync Thread
    private static boolean RK_IS_RUNNING = false; // Refresh Key
    private static boolean RE_IS_RUNNING = false; // Recharge Element
    private static boolean CO_IS_RUNNING = false; // Card Operation
    private static boolean RP_IS_RUNNING = false; // Recharge Process

    public static synchronized boolean setStIsRunning(boolean stIsRunning) {
        if (stIsRunning) {
            if (ST_IS_RUNNING) {
                return false;
            }
            ST_IS_RUNNING = true;
            return true;
        } else {
            ST_IS_RUNNING = false;
            return true;
        }
    }

    public static synchronized boolean setRkIsRunning(boolean rkIsRunning) {
        if (rkIsRunning) {
            if (RK_IS_RUNNING) {
                return false;
            }
            RK_IS_RUNNING = true;
            return true;
        } else {
            RK_IS_RUNNING = false;
            return true;
        }
    }

    public static synchronized boolean setReIsRunning(boolean reIsRunning) {
        RE_IS_RUNNING = reIsRunning;
        return true;
    }

    public static synchronized boolean setCoIsRunning(boolean coIsRunning) {
        CO_IS_RUNNING = coIsRunning;
        return true;
    }

    public static synchronized boolean setRpIsRunning(boolean rpIsRunning) {
        RP_IS_RUNNING = rpIsRunning;
        return true;
    }

    public static boolean isStIsRunning() {
        return ST_IS_RUNNING;
    }

    public static boolean isRkIsRunning() {
        return RK_IS_RUNNING;
    }

    public static boolean isReIsRunning() {
        return RE_IS_RUNNING;
    }

    public static boolean isCoIsRunning() {
        return CO_IS_RUNNING;
    }

    public static boolean isRpIsRunning() {
        return RP_IS_RUNNING;
    }

}
