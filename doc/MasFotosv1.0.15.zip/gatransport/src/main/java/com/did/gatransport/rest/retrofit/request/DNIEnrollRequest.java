package com.did.gatransport.rest.retrofit.request;

import com.google.gson.annotations.SerializedName;

public final class DNIEnrollRequest extends BaseEnrollRequest implements EnrollRequest {

    @SerializedName("DNI")
    private String dni;

    public DNIEnrollRequest() {
    }

    public String getDni() {
        return dni;
    }

    public void setDni(String dni) {
        this.dni = dni;
    }
}
