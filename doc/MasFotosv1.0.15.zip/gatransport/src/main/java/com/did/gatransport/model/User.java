package com.did.gatransport.model;

public final class User {

    private String name;
    private String cardPan;
    private String cardType;
    private String profileType;
    private String paySolutionType;

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getCardPan() {
        return cardPan;
    }

    public void setCardPan(String cardPan) {
        this.cardPan = cardPan;
    }

    public String getCardType() {
        return cardType;
    }

    public void setCardType(String cardType) {
        this.cardType = cardType;
    }

    public String getProfileType() {
        return profileType;
    }

    public void setProfileType(String profileType) {
        this.profileType = profileType;
    }

    public String getPaySolutionType() {
        return paySolutionType;
    }

    public void setPaySolutionType(String paySolutionType) {
        this.paySolutionType = paySolutionType;
    }
}
