package com.did.gatransport.rest.retrofit.request;

import com.google.gson.annotations.SerializedName;

public final class ConfirmEnrollRequest {

    @SerializedName("HW_ID")
    private String hwId;
    @SerializedName("PAN")
    private String pan;
    @SerializedName("Token_ID")
    private String tokenId;
    @SerializedName("Phone_ID")
    private String phoneId;

    public ConfirmEnrollRequest() {
    }

    public String getHwId() {
        return hwId;
    }

    public void setHwId(String hwId) {
        this.hwId = hwId;
    }

    public String getPan() {
        return pan;
    }

    public void setPan(String pan) {
        this.pan = pan;
    }

    public String getTokenId() {
        return tokenId;
    }

    public void setTokenId(String tokenId) {
        this.tokenId = tokenId;
    }

    public String getPhoneId() {
        return phoneId;
    }

    public void setPhoneId(String phoneId) {
        this.phoneId = phoneId;
    }
}
