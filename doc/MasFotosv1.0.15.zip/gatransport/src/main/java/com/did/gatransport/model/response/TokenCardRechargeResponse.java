package com.did.gatransport.model.response;

import com.did.gatransport.model.TokenCardPayment;

public final class TokenCardRechargeResponse {

    private int fee;

    private String refundId;

    private TokenCardPayment payment;

    public TokenCardRechargeResponse() {
    }

    public int getFee() {
        return fee;
    }

    public void setFee(int fee) {
        this.fee = fee;
    }

    public String getRefundId() {
        return refundId;
    }

    public void setRefundId(String refundId) {
        this.refundId = refundId;
    }

    public TokenCardPayment getPayment() {
        return payment;
    }

    public void setPayment(TokenCardPayment payment) {
        this.payment = payment;
    }
}
