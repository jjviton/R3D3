package com.did.gatransport.model.request;

public final class FinishEnrollRequest {
    private String otp;

    public FinishEnrollRequest() {
    }

    public FinishEnrollRequest(String otp) {
        this.otp = otp;
    }

    public String getOtp() {
        return otp;
    }

    public void setOtp(String otp) {
        this.otp = otp;
    }
}
