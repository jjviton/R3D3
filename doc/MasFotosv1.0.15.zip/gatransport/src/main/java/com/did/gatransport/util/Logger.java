package com.did.gatransport.util;

import com.did.gatransport.model.Error;

public interface Logger {

    void setLevel(int level);

    int getLevel();

    void logDebug(String log);

    void logError(String log, Throwable tr);

    void logDebug(String classFunction, String log);

    void logError(String classFunction, String log, Throwable tr);

    void logError(String classFunction, Error error, String defaultLog);

    void logError(String classFunction, Error error);
}
