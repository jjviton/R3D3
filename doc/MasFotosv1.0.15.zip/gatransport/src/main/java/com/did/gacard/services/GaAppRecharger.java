package com.did.gacard.services;

public interface GaAppRecharger {
    byte[] getNt(GaAppletManager manager);

    byte[] getBalance(GaAppletManager manager);

    byte[] getLastEvent(GaAppletManager manager);

    void rechargeBalance(GaAppletManager manager, int newNt, int newBalance, int recharge) throws Exception;

    void updateProfile(GaAppletManager manager, String profile, String profileInitialization, String profileExpiration, String profileTimestamp, String profileDescription, String newEvent) throws Exception;
}
