package com.did.gacard.core.files.model;

import com.did.gacard.ecard.core.iso7816.files.EFile;
import com.did.gacard.ecard.util.ByteArray;
import com.google.gson.annotations.SerializedName;

public final class ResponseEFile extends EFile {

    @SerializedName("tag")
    private byte tag;
    @SerializedName("length")
    private byte length;
    @SerializedName("name")
    private byte[] name;

    public ResponseEFile() {
        super();
    }

    public ResponseEFile(ResponseEFile other) {
        super(other);
        if (other == null) return;
        this.tag = other.tag;
        this.length = other.length;
        this.name = ByteArray.copyOf(other.name);
    }

    public byte getTag() {
        return tag;
    }

    public void setTag(byte tag) {
        this.tag = tag;
    }

    public byte getLength() {
        return length;
    }

    public void setLength(byte fileLength) {
        this.length = fileLength;
    }

    public byte[] getName() {
        return name;
    }

    public void setName(byte[] name) {
        this.name = name;
    }
}
