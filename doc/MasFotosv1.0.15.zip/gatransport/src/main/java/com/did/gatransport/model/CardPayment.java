package com.did.gatransport.model;

import android.os.Parcel;
import android.os.Parcelable;

public final class CardPayment extends Payment implements Parcelable {

    private String pan;

    private String month;

    private String year;

    private String cvv;

    private boolean tokenize;

    public CardPayment() {
    }

    public CardPayment(Parcel in) {
        super(in);
        this.pan = in.readString();
        this.month = in.readString();
        this.year = in.readString();
        this.cvv = in.readString();
        this.tokenize = in.readByte() != 0;
    }

    @Override
    public int describeContents() {
        return super.describeContents();
    }

    @Override
    public void writeToParcel(Parcel out, int flags) {
        super.writeToParcel(out, flags);
        out.writeString(pan);
        out.writeString(month);
        out.writeString(year);
        out.writeString(cvv);
        out.writeByte((byte) (tokenize ? 1 : 0));
    }

    public static final Parcelable.Creator<CardPayment> CREATOR
            = new Parcelable.Creator<CardPayment>() {
        public CardPayment createFromParcel(Parcel in) {
            return new CardPayment(in);
        }

        public CardPayment[] newArray(int size) {
            return new CardPayment[size];
        }
    };

    public String getPan() {
        return pan;
    }

    public void setPan(String pan) {
        this.pan = pan;
        clearPan();
    }

    public String getMonth() {
        return month;
    }

    public void setMonth(String month) {
        this.month = month;
        clearMonth();
    }

    public String getYear() {
        return year;
    }

    public void setYear(String year) {
        this.year = year;
        clearYear();
    }

    public String getCvv() {
        return cvv;
    }

    public void setCvv(String cvv) {
        this.cvv = cvv;
        clearCVV();
    }

    private void clearPan() {
        if (pan != null) {
            pan = pan.trim().replace(" ", "");
        }
    }

    private void clearMonth() {
        if (month != null) {
            month = month.trim().replace(" ", "");
        }
    }

    private void clearYear() {
        if (year != null) {
            year = year.trim().replace(" ", "");
        }
    }

    private void clearCVV() {
        if (cvv != null) {
            cvv = cvv.trim().replace(" ", "");
        }
    }

    public boolean isTokenize() {
        return tokenize;
    }

    public void setTokenize(boolean tokenize) {
        this.tokenize = tokenize;
    }
}
