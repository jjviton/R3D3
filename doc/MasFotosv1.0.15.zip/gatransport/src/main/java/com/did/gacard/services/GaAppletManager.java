package com.did.gacard.services;

import com.did.gacard.core.GaApplet;
import com.did.gacard.core.files.GaAppFileLoader;
import com.did.gacard.core.protocol.GaSecurityElement;
import com.did.gacard.util.GaCardException;

public interface GaAppletManager extends GaAppFileLoader, GaSecurityElement, GaApplet.GaAppletListener {
    byte[] getNt() throws GaCardException;

    byte[] getBalance() throws GaCardException;

    byte[] getLastEvent() throws GaCardException;

    byte getGroupCode() throws GaCardException;

    byte[] getProfileInitialization() throws GaCardException;

    byte[] getProfileExpiration() throws GaCardException;

    byte[] getGenData() throws GaCardException;

    void rechargeBalance(int newNt, int newBalance, int recharge) throws GaCardException;

    void updateProfileUser(String newStructEnvironmentUser, String newEvent) throws GaCardException;

    // TODO ONLY FOR DEBUG
//    void resetState() throws GaCardException;
}
