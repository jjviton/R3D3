package com.did.gatransport.interfaces;

import com.did.gatransport.model.Error;

public interface SynchronizationListener {

    void onStart();

    void onSuccess();

    void onFailure(Error error);

}
