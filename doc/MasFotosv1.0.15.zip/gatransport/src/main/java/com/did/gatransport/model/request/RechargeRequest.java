package com.did.gatransport.model.request;

import android.os.Parcel;
import android.os.Parcelable;

import com.did.gatransport.model.Payment;

public abstract class RechargeRequest<T extends Payment> implements Parcelable {

    private String pwd = null;

    private T payment;

    public RechargeRequest() {
    }

    public RechargeRequest(String pwd, T payment) {
        this.pwd = pwd;
        this.payment = payment;
    }

    public RechargeRequest(Parcel in) {
        this.pwd = in.readString();
        this.payment = getPaymentFromParcel(in);
    }

    abstract T getPaymentFromParcel(Parcel in);

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel out, int flags) {
        out.writeString(pwd);
        out.writeParcelable(payment, flags);
    }

    public String getPwd() {
        return pwd;
    }

    public void setPwd(String pwd) {
        this.pwd = pwd;
    }

    public T getPayment() {
        return payment;
    }

    public void setPayment(T payment) {
        this.payment = payment;
    }
}
