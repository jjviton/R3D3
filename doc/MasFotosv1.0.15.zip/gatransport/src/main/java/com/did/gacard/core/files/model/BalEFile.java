package com.did.gacard.core.files.model;

import com.did.gacard.ecard.core.iso7816.files.EFile;
import com.did.gacard.ecard.util.ByteArray;
import com.google.gson.annotations.SerializedName;

public final class BalEFile extends EFile {

    @SerializedName("balance")
    private byte[] balance;
    @SerializedName("ratification")
    private byte bitRatification;
    @SerializedName("signature")
    private byte[] signature;

    public byte[] getBalance() {
        return balance;
    }

    public BalEFile() {
        super();
    }

    public BalEFile(BalEFile other) {
        super(other);
        if (other == null) return;
        this.balance = ByteArray.copyOf(other.balance);
        this.bitRatification = other.bitRatification;
        this.signature = ByteArray.copyOf(other.signature);
    }

    public void setBalance(byte[] balance) {
        this.balance = balance;
    }

    public byte getBitRatification() {
        return bitRatification;
    }

    public void setBitRatification(byte bitRatification) {
        this.bitRatification = bitRatification;
    }

    public byte[] getSignature() {
        return signature;
    }

    public void setSignature(byte[] signature) {
        this.signature = signature;
    }
}
