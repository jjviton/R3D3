package com.did.gatransport.controller;

import android.content.ContextWrapper;
import android.support.annotation.NonNull;

import com.did.gatransport.R;
import com.did.gatransport.interfaces.RequestListener;
import com.did.gatransport.model.Error;
import com.did.gatransport.rest.GaRestController;
import com.did.gatransport.rest.model.response.LoginResponse;
import com.did.gatransport.store.GaStoreManager;
import com.did.gatransport.store.model.User;
import com.did.gatransport.util.ErrorFactory;

import java.security.InvalidParameterException;

final class LoginController {

    static void login(@NonNull final ContextWrapper context, @NonNull final GaStoreManager storeManager, @NonNull final GaRestController restController, final String user, final String pwd, @NonNull final RequestListener<Void> listener) {
        if (pwd == null || pwd.trim().isEmpty()) {
            listener.onFailure(ErrorFactory.getWarnError(context, Error.GENERAL_INVALID_INPUT, new InvalidParameterException(String.format(context.getString(R.string.EXCEPTION_INVALID_INPUT), "pwd"))));
            return;
        }

        if (user == null || user.trim().isEmpty()) {
            listener.onFailure(ErrorFactory.getWarnError(context, Error.GENERAL_INVALID_INPUT, new InvalidParameterException(String.format(context.getString(R.string.EXCEPTION_INVALID_INPUT), "user"))));
            return;
        }

        storeManager.getUser(new RequestListener<User>() {
            @Override
            public void onSuccess(User response) {
                if (response != null) {
                    if (response.getName() != null && response.getName().equalsIgnoreCase(user)) {
                        String userToken = response.getToken();
                        restController.performLogin(userToken, user, pwd, new RequestListener<LoginResponse>() {
                            @Override
                            public void onSuccess(LoginResponse response) {
                                storeManager.updateUserToken(response.getToken(), new RequestListener<Void>() {
                                    @Override
                                    public void onSuccess(Void response) {
                                        PreferencesController.getInstance(context).setUserName(user);
                                        listener.onSuccess(null);
                                    }

                                    @Override
                                    public void onFailure(Error error) {
                                        listener.onFailure(error);
                                    }
                                });
                            }

                            @Override
                            public void onFailure(Error error) {
                                listener.onFailure(error);
                            }
                        });
                    } else {
                        listener.onFailure(ErrorFactory.getWarnError(context, Error.GENERAL_INVALID_USER));
                    }
                } else {
                    listener.onFailure(ErrorFactory.getWarnError(context, Error.GENERAL_USER_NOT_EXISTS));
                }
            }

            @Override
            public void onFailure(Error error) {
                listener.onFailure(error);
            }
        });

    }

    static void logout(@NonNull final ContextWrapper context) {
        PreferencesController.getInstance(context).setUserName(null);
    }
}
