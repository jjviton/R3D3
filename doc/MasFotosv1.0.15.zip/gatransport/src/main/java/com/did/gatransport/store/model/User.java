package com.did.gatransport.store.model;

public interface User {

    void setName(String name);

    String getName();

    void setToken(String token);

    String getToken();

    void setPhoneId(String phoneId);

    String getPhoneId();

    void setCardId(String cardId);

    String getCardId();

    void setCardType(String type);

    String getCardType();

    void setProfileType(String type);

    String getProfileType();

    void setUserId(String userId);

    String getUserId();

    String getPaySolutionType();

    void setPaySolutionType(String paySolutionType);

    String getProfileExpiration();

    void setProfileExpiration(String profileExpiration);
}
