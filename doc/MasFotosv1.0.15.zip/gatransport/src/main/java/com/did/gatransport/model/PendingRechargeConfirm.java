package com.did.gatransport.model;

public final class PendingRechargeConfirm extends Recharge {

    public PendingRechargeConfirm() {
        super();
    }

    public PendingRechargeConfirm(long date, int type, int amount, String cardLastDig) {
        super(date, type, amount, cardLastDig);
    }
}
