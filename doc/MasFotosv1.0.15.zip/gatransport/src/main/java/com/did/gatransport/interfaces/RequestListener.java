package com.did.gatransport.interfaces;

import com.did.gatransport.model.Error;

public interface RequestListener<T> extends CustomRequestListener<T, Error> {

}
