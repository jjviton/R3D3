package com.did.gatransport.ui;

import android.app.Dialog;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.v4.app.DialogFragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import com.did.gatransport.R;
import com.did.gatransport.controller.CoreController;

public final class LoadDialogFragment extends DialogFragment {

    public static LoadDialogFragment create(RechargeActivityController.BadResourcesListener badResourcesListener, MyListener listener) {
        if (badResourcesListener == null) {
            return null;
        }

        LoadDialogFragment fragment = new LoadDialogFragment();
        fragment.listener = listener;
        fragment.badResourcesListener = badResourcesListener;
        return fragment;
    }

    public interface MyListener {
        void onConfirm(DialogFragment dialogFragment);
    }

    private MyListener listener;

    private View progressView, okView, nokView, acceptButtonView;
    private TextView messageTextView, errorTextView;

    private RechargeActivityController.BadResourcesListener badResourcesListener;

    // Settings
    private static final int STATE_LOAD = 0;
    private static final int STATE_OK = 1;
    private static final int STATE_KO = 2;
    private int state = STATE_LOAD;
    private boolean showButton = false;
    private boolean disableDismissOnAccept = false;
    private String strTitle = "";
    private String strError = "";

    public void setListener(MyListener listener) {
        this.listener = listener;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setStyle(DialogFragment.STYLE_NORMAL, R.style.gatdefault_full_dialog);
    }

    @Override
    public View onCreateView(@NonNull final LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View rootView = null;
        try {
            rootView = inflater.inflate(R.layout.gatdefault_layout_loading, container, false);
        } catch (Exception e) {
            CoreController.getLogger().logError("LoadDialogFragment::onCreateView", "Error inflating layout.", e);
        }
        if (rootView == null) {
            if (badResourcesListener != null)
                badResourcesListener.onBadResources();
            return null;
        }

        progressView = rootView.findViewById(R.id.gatdefault_progress_view);
        okView = rootView.findViewById(R.id.gatdefault_ok_view);
        nokView = rootView.findViewById(R.id.gatdefault_nok_view);

        messageTextView = rootView.findViewById(R.id.gatdefault_message_textview);
        errorTextView = rootView.findViewById(R.id.gatdefault_error_textview);

        acceptButtonView = rootView.findViewById(R.id.gatdefault_accept_button);
        if (acceptButtonView != null) {
            acceptButtonView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    if (!disableDismissOnAccept)
                        dismiss();
                    if (listener != null) listener.onConfirm(LoadDialogFragment.this);
                }
            });
        }

        return rootView;
    }

    @Override
    public void onStart() {
        super.onStart();
        Dialog d = getDialog();
        if (d != null) {
            if (d.getWindow() != null)
                d.getWindow().setLayout(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT);
            d.setCancelable(false);
            d.setCanceledOnTouchOutside(false);
        }
    }

    @Override
    public void onResume() {
        super.onResume();

        setup();
    }

    private void setText(TextView t, CharSequence text) {
        if (t != null) t.setText(text != null ? text : "");
    }

    private void setVisibility(View v, int visibility) {
        if (v != null) v.setVisibility(visibility);
    }

    private void setup() {
        if (!isAdded() || isDetached() || getDialog() == null)
            return;

        setVisibility(acceptButtonView, showButton ? View.VISIBLE : View.INVISIBLE);
        setText(messageTextView, strTitle);
        setText(errorTextView, strError);

        switch (state) {
            case STATE_LOAD:
            default:
                setVisibility(progressView, View.VISIBLE);
                setVisibility(okView, View.INVISIBLE);
                setVisibility(nokView, View.INVISIBLE);
                break;
            case STATE_OK:
                setVisibility(progressView, View.INVISIBLE);
                setVisibility(okView, View.VISIBLE);
                setVisibility(nokView, View.INVISIBLE);
                break;
            case STATE_KO:
                setVisibility(progressView, View.INVISIBLE);
                setVisibility(okView, View.INVISIBLE);
                setVisibility(nokView, View.VISIBLE);
                break;
        }
    }

    private void update(int state, String title, String error, boolean showButton, boolean disableDismissOnAccept) {
        this.state = state;
        this.strTitle = title != null ? title : "";
        this.strError = error != null ? error : "";
        this.showButton = showButton;
        this.disableDismissOnAccept = disableDismissOnAccept;
        setup();
    }

    public void start(String title, String error, boolean disableDismissOnAccept) {
        update(STATE_LOAD, title, error, false, disableDismissOnAccept);
    }

    public void finishOK(String title, String error, boolean disableDismissOnAccept) {
        update(STATE_OK, title, error, true, disableDismissOnAccept);
    }

    public void finishKO(String title, String error, boolean disableDismissOnAccept) {
        update(STATE_KO, title, error, true, disableDismissOnAccept);
    }
}
