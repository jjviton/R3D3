package com.did.gatransport.rest.model.response;

import com.google.gson.annotations.SerializedName;

public final class GenericResponse extends BaseResponse {

    @SerializedName("Transaction")
    private String transaction;

    public GenericResponse() {
    }

    public String getTransaction() {
        return transaction;
    }

    public void setTransaction(String transaction) {
        this.transaction = transaction;
    }
}
