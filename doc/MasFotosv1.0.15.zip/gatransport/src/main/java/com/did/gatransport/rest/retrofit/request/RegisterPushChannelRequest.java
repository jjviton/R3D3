package com.did.gatransport.rest.retrofit.request;

import com.google.gson.annotations.SerializedName;

public class RegisterPushChannelRequest {

    @SerializedName("Phone_ID")
    private String phoneId;
    @SerializedName("HW_ID")
    private String hwId;
    @SerializedName("PAN")
    private String pan;
    @SerializedName("Dev_ID")
    private String deviceId = "";
    @SerializedName("Connector")
    private String connector = "";
    @SerializedName("Ver_SO")
    private String osVersion = "";
    @SerializedName("Ver_App")
    private String appVersion = "";

    public RegisterPushChannelRequest() {
    }

    public String getPhoneId() {
        return phoneId;
    }

    public void setPhoneId(String phoneId) {
        this.phoneId = phoneId;
    }

    public String getHwId() {
        return hwId;
    }

    public void setHwId(String hwId) {
        this.hwId = hwId;
    }

    public String getPan() {
        return pan;
    }

    public void setPan(String pan) {
        this.pan = pan;
    }

    public String getDeviceId() {
        return deviceId;
    }

    public void setDeviceId(String deviceId) {
        this.deviceId = deviceId != null ? deviceId : "";
    }

    public String getConnector() {
        return connector;
    }

    public void setConnector(String connector) {
        this.connector = connector != null ? connector : "";
    }

    public String getOsVersion() {
        return osVersion;
    }

    public void setOsVersion(String osVersion) {
        this.osVersion = osVersion != null ? osVersion : "";
    }

    public String getAppVersion() {
        return appVersion;
    }

    public void setAppVersion(String appVersion) {
        this.appVersion = appVersion != null ? appVersion : "";
    }
}
