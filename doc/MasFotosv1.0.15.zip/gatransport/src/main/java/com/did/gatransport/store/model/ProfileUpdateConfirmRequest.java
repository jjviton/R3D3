package com.did.gatransport.store.model;

public interface ProfileUpdateConfirmRequest {

    String getOldProfile();

    void setOldProfile(String profile);

    String getOldProfileExpiration();

    void setOldProfileExpiration(String dateExpiration);

    String getNewProfile();

    void setNewProfile(String profile);

    String getNewProfileExpiration();

    void setNewProfileExpiration(String dateExpiration);

    String getTimestamp();

    void setTimestamp(String timestamp);

}
