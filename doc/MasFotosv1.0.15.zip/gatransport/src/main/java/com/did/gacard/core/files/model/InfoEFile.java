package com.did.gacard.core.files.model;

import com.did.gacard.ecard.core.iso7816.files.EFile;
import com.did.gacard.ecard.util.ByteArray;
import com.google.gson.annotations.SerializedName;

public final class InfoEFile extends EFile {

    @SerializedName("version")
    private byte debitKeyVersion;
    @SerializedName("algoritme")
    private byte debitAlgoritmeId;
    @SerializedName("serial")
    private byte[] serialApp;

    public InfoEFile() {
        super();
    }

    public InfoEFile(InfoEFile other) {
        super(other);
        if (other == null) return;
        this.debitKeyVersion = other.debitKeyVersion;
        this.debitAlgoritmeId = other.debitAlgoritmeId;
        this.serialApp = ByteArray.copyOf(other.serialApp);
    }

    public byte getDebitKeyVersion() {
        return debitKeyVersion;
    }

    public void setDebitKeyVersion(byte debitKeyVersion) {
        this.debitKeyVersion = debitKeyVersion;
    }

    public byte getDebitAlgoritmeId() {
        return debitAlgoritmeId;
    }

    public void setDebitAlgoritmeId(byte debitAlgoritmeId) {
        this.debitAlgoritmeId = debitAlgoritmeId;
    }

    public byte[] getSerialApp() {
        return serialApp;
    }

    public void setSerialApp(byte[] serialApp) {
        this.serialApp = serialApp;
    }
}
