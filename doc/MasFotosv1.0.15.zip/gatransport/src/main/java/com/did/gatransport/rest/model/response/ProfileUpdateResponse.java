package com.did.gatransport.rest.model.response;

import com.google.gson.annotations.SerializedName;

public final class ProfileUpdateResponse extends BaseResponse {

    @SerializedName("Event")
    private String newEvent;
    @SerializedName("User_struct")
    private String newStructEnvironmentUser;
    @SerializedName("Signature")
    private byte[] newSignature;

    public ProfileUpdateResponse() {
    }

    public String getNewEvent() {
        return newEvent;
    }

    public void setNewEvent(String newEvent) {
        this.newEvent = newEvent;
    }

    public String getNewStructEnvironmentUser() {
        return newStructEnvironmentUser;
    }

    public void setNewStructEnvironmentUser(String newStructEnvironmentUser) {
        this.newStructEnvironmentUser = newStructEnvironmentUser;
    }

    public byte[] getNewSignature() {
        return newSignature;
    }

    public void setNewSignature(byte[] newSignature) {
        this.newSignature = newSignature;
    }
}
