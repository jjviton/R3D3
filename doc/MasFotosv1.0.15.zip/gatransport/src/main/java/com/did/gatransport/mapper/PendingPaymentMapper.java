package com.did.gatransport.mapper;

import com.did.gatransport.model.PendingPayment;
import com.did.gatransport.util.AmountConverter;

import java.util.ArrayList;
import java.util.List;

public final class PendingPaymentMapper extends Mapper<PendingPayment, Void, com.did.gatransport.rest.model.PendingPayment> {

    @Override
    public PendingPayment restToUi(com.did.gatransport.rest.model.PendingPayment obj) {
        PendingPayment pendingPayment = new PendingPayment();
        pendingPayment.setMsg(obj.getMsg());
        pendingPayment.setAmount(AmountConverter.reverseDecimalAmount(obj.getAmount()));
        pendingPayment.setExpDate(obj.getExpDate());
        pendingPayment.setKey(obj.getKey());
        pendingPayment.setType(obj.getType());

        return pendingPayment;
    }


    public List<PendingPayment> listRestToUi(List<com.did.gatransport.rest.model.PendingPayment> pendingPaymentRestList) {
        List<PendingPayment> pendingPayments = new ArrayList<>();
        if (pendingPaymentRestList != null) {
            for (com.did.gatransport.rest.model.PendingPayment pendingPaymentRest : pendingPaymentRestList) {
                pendingPayments.add(restToUi(pendingPaymentRest));
            }
        }

        return pendingPayments;
    }
}
