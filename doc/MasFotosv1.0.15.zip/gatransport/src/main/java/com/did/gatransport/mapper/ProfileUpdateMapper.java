package com.did.gatransport.mapper;

import com.did.gatransport.model.ProfileUpdate;

import java.util.ArrayList;
import java.util.List;

public final class ProfileUpdateMapper extends Mapper<ProfileUpdate, Void, com.did.gatransport.rest.model.ProfileUpdate> {

    @Override
    public ProfileUpdate restToUi(com.did.gatransport.rest.model.ProfileUpdate obj) {
        ProfileUpdate profileUpdate = new ProfileUpdate();
        profileUpdate.setType(obj.getType());
        profileUpdate.setCurrentProfile(obj.getCurrentProfile());
        profileUpdate.setCurrentProfileExpiration(obj.getCurrentProfileExpiration());
        profileUpdate.setCurrentProfileDescription(obj.getCurrentProfileDescription());
        profileUpdate.setTimestamp(obj.getTimestamp());
        profileUpdate.setNewProfile(obj.getNewProfile());
        profileUpdate.setNewProfileInitialization(obj.getNewProfileInitialization());
        profileUpdate.setNewProfileExpiration(obj.getNewProfileExpiration());
        profileUpdate.setNewProfileDescription(obj.getNewProfileDescription());

        return profileUpdate;
    }

    public List<ProfileUpdate> restToUiList(List<com.did.gatransport.rest.model.ProfileUpdate> list) {
        List<ProfileUpdate> result = new ArrayList<>();
        if (list != null) {
            for (com.did.gatransport.rest.model.ProfileUpdate item : list) {
                result.add(restToUi(item));
            }
        }
        return result;
    }
}
