package com.did.gatransport.mapper;

import com.did.gatransport.model.PendingRechargeConfirm;
import com.did.gatransport.model.Recharge;
import com.did.gatransport.store.model.RechargeConfirmRequest;
import com.did.gatransport.store.realm.model.RechargeRealm;

import java.util.ArrayList;
import java.util.List;

public final class RechargeMapper extends Mapper<Recharge, RechargeRealm, Void> {

    @Override
    public Recharge storeToUi(RechargeRealm obj) {
        Recharge recharge = new Recharge();
        recharge.setDate(obj.getDate());
        recharge.setAmount(obj.getAmount());
        recharge.setType(obj.getType());
        recharge.setCardLastDig(obj.getCardLastDig());

        return recharge;
    }


    public List<Recharge> listStoreToUi(List<RechargeRealm> rechargeRealmList) {
        List<Recharge> recharges = new ArrayList<>();
        if (rechargeRealmList != null && rechargeRealmList.size() > 0) {
            for (RechargeRealm rechargeRealm : rechargeRealmList) {
                recharges.add(storeToUi(rechargeRealm));
            }
        }

        return recharges;
    }

    public PendingRechargeConfirm fromRechargeConfirmRequestRealm(RechargeConfirmRequest rechargeConfirmRequestRealm) {
        PendingRechargeConfirm recharge = new PendingRechargeConfirm();
        if (rechargeConfirmRequestRealm != null) {
            recharge.setDate(rechargeConfirmRequestRealm.getDate());
            recharge.setAmount(rechargeConfirmRequestRealm.getAmount());
            recharge.setType(rechargeConfirmRequestRealm.getType());
            recharge.setCardLastDig(rechargeConfirmRequestRealm.getLastDig());
        }
        return recharge;
    }
}
