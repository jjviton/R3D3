package com.did.gatransport.interfaces;

import com.did.gatransport.model.Error;

abstract class ChainRequestListener<T> implements RequestListener<T> {

    private RequestListener<T> nextListener;


    ChainRequestListener(RequestListener<T> nextListener) {
        this.nextListener = nextListener;
    }

    @Override
    public final void onSuccess(T response) {
        onSuccess(nextListener, response);
    }

    @Override
    public final void onFailure(Error error) {
        onFailure(nextListener, error);
    }

    abstract void onSuccess(RequestListener<T> nextListener, T response);

    abstract void onFailure(RequestListener<T> nextListener, Error error);

}
