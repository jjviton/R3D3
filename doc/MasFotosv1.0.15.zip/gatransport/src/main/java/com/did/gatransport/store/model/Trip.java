package com.did.gatransport.store.model;

import com.did.gatransport.rest.model.TransactionLine;

public interface Trip {

    String TYPE_DEBIT = TransactionLine.TYPE_DEBIT;
    String TYPE_CANCEL = TransactionLine.TYPE_CANCEL;

    void setLine(String line);

    String getLine();

    void setAmount(int amount);

    int getAmount();

    void setDate(long date);

    long getDate();

    void setType(String type);

    String getType();
}
