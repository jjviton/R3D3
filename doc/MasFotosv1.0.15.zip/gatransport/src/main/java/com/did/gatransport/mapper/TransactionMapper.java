package com.did.gatransport.mapper;

import com.did.gatransport.rest.model.TransactionLine;
import com.did.gatransport.store.model.Transaction;
import com.did.gatransport.util.AmountConverter;

public final class TransactionMapper extends Mapper<Void, Transaction, TransactionLine> {

    @Override
    public TransactionLine storeToRest(Transaction obj) {
        TransactionLine transactionLine = new TransactionLine();
        transactionLine.setBalance(AmountConverter.getDecimalAmountString(obj.getBalance()));
        transactionLine.setAmount(AmountConverter.getDecimalAmountString(obj.getAmount()));
        transactionLine.setDate(String.valueOf(obj.getDate()));
        transactionLine.setNt(String.valueOf(obj.getNt()));
        transactionLine.setType(obj.getType());

        return transactionLine;
    }
}
