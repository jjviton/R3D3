package com.did.gatransport.rest.retrofit.request;

import com.google.gson.annotations.SerializedName;

public class BaseEnrollRequest implements EnrollRequest {

    @SerializedName("HW_ID")
    private String hwId;
    @SerializedName("Card_Type")
    private String cardType;
    @SerializedName("Profile")
    private String profile;

    public BaseEnrollRequest() {
    }

    @Override
    public String getHwId() {
        return hwId;
    }

    @Override
    public void setHwId(String hwId) {
        this.hwId = hwId;
    }

    @Override
    public String getCardType() {
        return cardType;
    }

    @Override
    public void setCardType(String cardType) {
        this.cardType = cardType;
    }

    @Override
    public String getProfile() {
        return profile;
    }

    @Override
    public void setProfile(String profile) {
        this.profile = profile;
    }
}
