package com.did.gatransport.rest.retrofit.request;

public interface FinishEnrollRequest {

    String getPwd();

    void setPwd(String pwd);

    String getMail();

    void setMail(String mail);

    String getPhone();

    void setPhone(String phone);

    String getHwId();

    void setHwId(String hwId);

    String getCardType();

    void setCardType(String cardType);

    String getProfile();

    void setProfile(String profile);

    String getProfileExpiration();

    void setProfileExpiration(String profileExpiration);

    String getPaySolution();

    void setPaySolution(String paySolution);

}
