package com.did.gatransport.rest.model.response;

import com.google.gson.annotations.SerializedName;

public final class TokenCard {

    @SerializedName("id")
    private String id;

    @SerializedName("bin")
    private String bin;

    @SerializedName("last")
    private String last;

    @SerializedName("expiry")
    private String expiration;

    public TokenCard() {
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getBin() {
        return bin;
    }

    public void setBin(String bin) {
        this.bin = bin;
    }

    public String getLast() {
        return last;
    }

    public void setLast(String last) {
        this.last = last;
    }

    public String getExpiration() {
        return expiration;
    }

    public void setExpiration(String expiration) {
        this.expiration = expiration;
    }
}
