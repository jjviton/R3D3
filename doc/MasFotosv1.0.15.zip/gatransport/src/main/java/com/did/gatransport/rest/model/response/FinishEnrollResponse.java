package com.did.gatransport.rest.model.response;

import com.did.gatransport.rest.model.PersoFile;
import com.google.gson.annotations.SerializedName;

public final class FinishEnrollResponse extends BaseResponse {

    @SerializedName("Card_Expiry_Date")
    private String cardExpiration;
    @SerializedName("HW_ID")
    private String hwId;
    @SerializedName("User_ID")
    private String userId;
    @SerializedName("Phone_ID")
    private String phoneId;
    @SerializedName("Profile_Expiry_Date")
    private String profileExpiration;
    @SerializedName("Token_ID")
    private String tokenId;
    @SerializedName("Card_PAN")
    private String pan;
    @SerializedName("Signature")
    private byte[] signature;
    @SerializedName("Balance")
    private String balance;
    @SerializedName("Profile")
    private String profile;
    @SerializedName("NT")
    private String nt;
    @SerializedName("PersoFile")
    private PersoFile persoFile;

    public FinishEnrollResponse() {
    }

    public String getCardExpiration() {
        return cardExpiration;
    }

    public void setCardExpiration(String cardExpiration) {
        this.cardExpiration = cardExpiration;
    }

    public String getHwId() {
        return hwId;
    }

    public void setHwId(String hwId) {
        this.hwId = hwId;
    }

    public String getUserId() {
        return userId;
    }

    public void setUserId(String userId) {
        this.userId = userId;
    }

    public String getPhoneId() {
        return phoneId;
    }

    public void setPhoneId(String phoneId) {
        this.phoneId = phoneId;
    }

    public String getProfileExpiration() {
        return profileExpiration;
    }

    public void setProfileExpiration(String profileExpiration) {
        this.profileExpiration = profileExpiration;
    }

    public String getTokenId() {
        return tokenId;
    }

    public void setTokenId(String tokenId) {
        this.tokenId = tokenId;
    }

    public String getPan() {
        return pan;
    }

    public void setPan(String pan) {
        this.pan = pan;
    }

    public byte[] getSignature() {
        return signature;
    }

    public void setSignature(byte[] signature) {
        this.signature = signature;
    }

    public String getBalance() {
        return balance;
    }

    public void setBalance(String balance) {
        this.balance = balance;
    }

    public String getProfile() {
        return profile;
    }

    public void setProfile(String profile) {
        this.profile = profile;
    }

    public String getNt() {
        return nt;
    }

    public void setNt(String nt) {
        this.nt = nt;
    }

    public PersoFile getPersoFile() {
        return persoFile;
    }

    public void setPersoFile(PersoFile persoFile) {
        this.persoFile = persoFile;
    }
}
