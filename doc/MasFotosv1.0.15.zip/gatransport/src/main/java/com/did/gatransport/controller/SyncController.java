package com.did.gatransport.controller;

import android.app.job.JobInfo;
import android.app.job.JobScheduler;
import android.content.ComponentName;
import android.content.Context;
import android.content.ContextWrapper;
import android.os.Build;
import android.support.annotation.NonNull;
import android.support.annotation.RequiresApi;
import android.text.TextUtils;

import com.did.gatransport.R;
import com.did.gatransport.interfaces.CustomRequestListener;
import com.did.gatransport.interfaces.RequestListener;
import com.did.gatransport.interfaces.SynchronizationListener;
import com.did.gatransport.mapper.TransactionMapper;
import com.did.gatransport.model.Error;
import com.did.gatransport.model.ErrorResponse;
import com.did.gatransport.rest.GaRestController;
import com.did.gatransport.rest.model.TransactionLine;
import com.did.gatransport.rest.model.response.GenericResponse;
import com.did.gatransport.services.SyncJobService;
import com.did.gatransport.store.GaStoreManager;
import com.did.gatransport.store.model.Transaction;
import com.did.gatransport.store.model.User;
import com.did.gatransport.util.ErrorFactory;
import com.did.security.core.SecurityHelper;
import com.google.gson.Gson;

import java.util.ArrayList;
import java.util.List;

public final class SyncController {

    private static final int JOB_ID_SYNC = 7190;

    private static Class<?> getSyncJobServiceClass(String className) {
        if (className == null || className.isEmpty()) return null;
        try {
            return Class.forName(className).asSubclass(SyncJobService.class);
        } catch (Exception e) {
            CoreController.getLogger().logError("SyncController::getSyncJobServiceClass", "Exception", e);
        }
        return null;
    }

    public static boolean validateSyncJobServiceClass(String className) {
        return getSyncJobServiceClass(className) != null;
    }

    @RequiresApi(api = Build.VERSION_CODES.LOLLIPOP)
    public static void scheduleSync(@NonNull ContextWrapper context) {
        scheduleJob(context, PreferencesController.getInstance(context).getSyncJobServiceClassName(), false);
    }

    @RequiresApi(api = Build.VERSION_CODES.LOLLIPOP)
    public static void scheduleSyncDelayed(@NonNull ContextWrapper context) {
        scheduleJob(context, PreferencesController.getInstance(context).getSyncJobServiceClassName(), true);
    }

    @RequiresApi(api = Build.VERSION_CODES.LOLLIPOP)
    private static void scheduleJob(ContextWrapper context, String className, boolean delay) {
        CoreController.getLogger().logDebug("SyncController::scheduleJob", "Scheduling SyncService: " + className);
        Class syncJobServiceClass = getSyncJobServiceClass(className);
        if (syncJobServiceClass == null) {
            CoreController.getLogger().logDebug("SyncController::scheduleJob", "Scheduling SyncService KO. BAD NAME:" + className);
            return;
        }

        JobScheduler jobScheduler = (JobScheduler) context.getSystemService(Context.JOB_SCHEDULER_SERVICE);
        if (jobScheduler != null) {
            int newMinimumLatency = 0;//delay ? 3 * 60 * 1000 : 0;
            boolean hasBeenScheduled = false;
            for (JobInfo jobInfo : jobScheduler.getAllPendingJobs()) {
                if (jobInfo.getId() == JOB_ID_SYNC && ProcessController.isStIsRunning()) { // && jobInfo.getMinLatencyMillis() > newMinimumLatency) {
                    hasBeenScheduled = true;
                    break;
                }
            }
            if (!hasBeenScheduled) {
                ComponentName serviceComponent = new ComponentName(context, syncJobServiceClass);
                JobInfo.Builder builder = new JobInfo.Builder(JOB_ID_SYNC, serviceComponent)
                        .setRequiredNetworkType(JobInfo.NETWORK_TYPE_ANY)
                        .setBackoffCriteria(60 * 1000, JobInfo.BACKOFF_POLICY_LINEAR)
                        .setMinimumLatency(newMinimumLatency);
//                .setOverrideDeadline(24 * 60 * 60 * 1000);
                JobInfo jobInfo = builder.build();

                // Schedule
                jobScheduler.schedule(jobInfo);

                CoreController.getLogger().logDebug("SyncController::scheduleJob", "Scheduling SyncService OK. Schedule delayed: " + newMinimumLatency + "ms");
            } else {
                CoreController.getLogger().logDebug("SyncController::scheduleJob", "Scheduling SyncService KO. JobService was scheduled previously or it is running now.");
            }
        } else {
            CoreController.getLogger().logDebug("SyncController::scheduleJob", "Scheduling SyncService KO. JobScheduler NO available.");
        }
    }

    private static void cancelJob(ContextWrapper context) {
        cancelJob(context, PreferencesController.getInstance(context).getSyncJobServiceClassName());
    }

    private static void cancelJob(ContextWrapper context, String className) {
        CoreController.getLogger().logDebug("SyncController::cancelJob", "Cancel Schedule SyncService: " + className);
        Class syncJobServiceClass = getSyncJobServiceClass(className);
        if (syncJobServiceClass == null) {
            CoreController.getLogger().logDebug("SyncController::cancelJob", "Cancel Schedule SyncService KO. BAD NAME:" + className);
            return;
        }

        JobScheduler jobScheduler = (JobScheduler) context.getSystemService(Context.JOB_SCHEDULER_SERVICE);
        if (jobScheduler != null) {
            boolean hasBeenScheduled = false;
            for (JobInfo jobInfo : jobScheduler.getAllPendingJobs()) {
                if (jobInfo.getId() == JOB_ID_SYNC) {
                    hasBeenScheduled = true;
                    break;
                }
            }
            if (!hasBeenScheduled) {
                // Cancel Schedule
                jobScheduler.cancel(JOB_ID_SYNC);

                CoreController.getLogger().logDebug("SyncController::cancelJob", "Cancel Schedule SyncService OK. JobService was scheduled previously.");
            } else {
                CoreController.getLogger().logDebug("SyncController::cancelJob", "Cancel Schedule SyncService OK.");
            }
        } else {
            CoreController.getLogger().logDebug("SyncController::cancelJob", "Cancel Schedule SyncService KO. JobScheduler NO available.");
        }
    }

    private static void sync(@NonNull ContextWrapper context, @NonNull GaStoreManager storeManager, @NonNull GaRestController restController, @NonNull SecurityHelper securityHelper, RequestListener<Void> listener, SynchronizationListener synchronizationListener, Error prevError) {
        CoreController.getLogger().logDebug("SyncController::sync", "Sync CALLED");
        if (ProcessController.setStIsRunning(true)) {
            CoreController.getLogger().logDebug("SyncController::sync", "Sync START");
            if (synchronizationListener != null)
                synchronizationListener.onStart();

            checkTransactions(context, storeManager, restController, securityHelper, listener, synchronizationListener, prevError);
        } else {
            Error error = ErrorFactory.getNonFatalError(context, Error.GENERAL_PROCESS_IS_RUNNING, new IllegalStateException(context.getString(R.string.EXCEPTION_ST_SERVICE_RUNNING)));
            CoreController.getLogger().logDebug("SyncController::sync", "Sync END");
            CoreController.getLogger().logError("SyncController::sync", error);
            if (listener != null)
                listener.onFailure(error);
        }
    }

    public static void sync(@NonNull ContextWrapper context, @NonNull GaStoreManager storeManager, @NonNull GaRestController restController, @NonNull SecurityHelper securityHelper, RequestListener<Void> listener, SynchronizationListener synchronizationListener) {
        sync(context, storeManager, restController, securityHelper, listener, synchronizationListener, null);
    }

    public static void sync(@NonNull ContextWrapper context, @NonNull GaStoreManager storeManager, @NonNull GaRestController restController, @NonNull SecurityHelper securityHelper, RequestListener<Void> listener, Error prevError) {
        sync(context, storeManager, restController, securityHelper, listener, null, prevError);
    }

    static void sync(@NonNull ContextWrapper context, @NonNull GaStoreManager storeManager, @NonNull GaRestController restController, @NonNull SecurityHelper securityHelper, RequestListener<Void> listener) {
        sync(context, storeManager, restController, securityHelper, listener, null, null);
    }

    private static void finishOK(ContextWrapper context, RequestListener<Void> listener, SynchronizationListener synchronizationListener) {
        cancelJob(context);
        ProcessController.setStIsRunning(false);

        CoreController.getLogger().logDebug("SyncController::finishOK", "Sync OK END");

        if (listener != null)
            listener.onSuccess(null);
        if (synchronizationListener != null)
            synchronizationListener.onSuccess();
    }

    private static void finishKO(Error error, RequestListener<Void> listener, SynchronizationListener synchronizationListener) {
        ProcessController.setStIsRunning(false);

        CoreController.getLogger().logDebug("SyncController::finishKO", "Sync KO END");
        CoreController.getLogger().logError("SyncController::finishKO", error);

        if (listener != null)
            listener.onFailure(error);
        if (synchronizationListener != null)
            synchronizationListener.onFailure(error);

    }

    private static void checkTransactions(final ContextWrapper context, @NonNull final GaStoreManager storeManager, @NonNull final GaRestController restController, @NonNull final SecurityHelper securityHelper, final RequestListener<Void> listener, final SynchronizationListener synchronizationListener, final Error prevError) {
        CoreController.getLogger().logDebug("SyncController::checkTransactions", "Check PendingTransactions");
        storeManager.getPendingTransactions(new RequestListener<List<Transaction>>() {
            @Override
            public void onSuccess(List<Transaction> response) {
                CoreController.getLogger().logDebug("SyncController::checkTransactions", "PendingTransactions Size = " + response.size());

                if (response.size() > 0) {
                    sendTransactions(context, storeManager, restController, securityHelper, response, listener, synchronizationListener, prevError);
                } else if (ErrorFactory.isCardLockedUnsubscribedError(prevError)) {
                    deleteAllData(context, storeManager, listener, synchronizationListener, prevError);
                } else if (prevError == null && storeManager.checkPendingRechargeConfirmRequest()) {
                    sendPendingRechargeConfirm(context, storeManager, restController, securityHelper, listener, synchronizationListener);
                } else if (prevError == null && storeManager.checkPendingProfileUpdateConfirmRequest()) {
                    sendPendingProfileUpdateConfirm(context, storeManager, restController, securityHelper, listener, synchronizationListener);
                } else {
                    CoreController.getLogger().logDebug("SyncController::checkTransactions", "BD_Delete SentTransactions");
                    storeManager.deleteSentTransactions(new RequestListener<Void>() {
                        @Override
                        public void onSuccess(Void response) {
                            if (prevError == null)
                                finishOK(context, listener, synchronizationListener);
                            else
                                finishKO(prevError, listener, synchronizationListener);
                        }

                        @Override
                        public void onFailure(Error error) {
                            if (prevError == null)
                                finishOK(context, listener, synchronizationListener);
                            else
                                finishKO(prevError, listener, synchronizationListener);
                        }
                    });
                }

            }

            @Override
            public void onFailure(Error error) {
                finishKO(error, listener, synchronizationListener);
            }
        });
    }

    private static void deleteAllData(ContextWrapper context, @NonNull GaStoreManager storeManager, RequestListener<Void> listener, SynchronizationListener synchronizationListener, Error prevError) {
        CoreController.getLogger().logDebug("SyncController::deleteAllData", "BD_Delete ALL");

        ManageCardController.deleteAll(context, storeManager);

        finishKO(ErrorFactory.getCardLockedUnsubscribedError(context, prevError), listener, synchronizationListener);
    }

    private static void sendTransactions(final ContextWrapper context, @NonNull final GaStoreManager storeManager, @NonNull final GaRestController restController, @NonNull final SecurityHelper securityHelper, final List<Transaction> pendingTransactions, final RequestListener<Void> listener, final SynchronizationListener synchronizationListener, final Error prevError) {
        CoreController.getLogger().logDebug("SyncController::sendTransactions", "REST_Send PendingTransactions");
        storeManager.getUser(new RequestListener<User>() {
            @Override
            public void onSuccess(User response) {
                String hwid = securityHelper.getHardwareIdentifier();
                byte[] signature = securityHelper.getSecretBytes(4);
                restController.sendTransactions(response.getToken(), response.getName(), response.getPhoneId(), hwid, new Gson().toJson(signature),
                        convertForRest(pendingTransactions), new CustomRequestListener<GenericResponse, ErrorResponse<GenericResponse>>() {
                            private void setSentTransactions(String lastNtSynchronized, final RequestListener<Void> setSentListener) {
                                if (lastNtSynchronized == null || lastNtSynchronized.isEmpty() || !TextUtils.isDigitsOnly(lastNtSynchronized) || Integer.valueOf(lastNtSynchronized) < 0) {
                                    if (setSentListener != null)
                                        setSentListener.onFailure(ErrorFactory.getWarnError(context, Error.REST_RESPONSE, new Exception("Bad NT value: " + lastNtSynchronized)));
                                } else {
                                    // Sencond set ALL Transactions with NT <= lastNTSynchronized to SENT
                                    CoreController.getLogger().logDebug("SyncController::sendTransactions", "DB_Update Set SENT all PendingTransactions with NT <= " + lastNtSynchronized);
                                    storeManager.updateTransactionToSent(Integer.valueOf(lastNtSynchronized), new RequestListener<Void>() {
                                        @Override
                                        public void onSuccess(Void response) {
                                            if (setSentListener != null)
                                                setSentListener.onSuccess(null);
                                        }

                                        @Override
                                        public void onFailure(Error error) {
                                            if (setSentListener != null)
                                                setSentListener.onFailure(error);
                                        }
                                    });
                                }
                            }

                            @Override
                            public void onSuccess(GenericResponse response) {
                                if (response != null) {
                                    setSentTransactions(response.getTransaction(), new RequestListener<Void>() {
                                        @Override
                                        public void onSuccess(Void response) {
                                            checkTransactions(context, storeManager, restController, securityHelper, listener, synchronizationListener, prevError);
                                        }

                                        @Override
                                        public void onFailure(Error error) {
                                            if (error != null) {
                                                error.setPreviousError(prevError);
                                            } else {
                                                error = prevError;
                                            }
                                            finishKO(error, listener, synchronizationListener);
                                        }
                                    });
                                }
                            }

                            @Override
                            public void onFailure(ErrorResponse<GenericResponse> errorResponse) {
                                Error error = errorResponse == null ? null : errorResponse.getError();
                                if (error != null) {
                                    error.setPreviousError(prevError);
                                } else {
                                    error = prevError;
                                }
                                final Error finalError = error;
                                if (errorResponse != null && errorResponse.getResponse() != null) {
                                    setSentTransactions(errorResponse.getResponse().getTransaction(), new RequestListener<Void>() {
                                        @Override
                                        public void onSuccess(Void response) {
                                            if (ErrorFactory.isCardLockedUnsubscribedError(finalError)) {
                                                deleteAllData(context, storeManager, listener, synchronizationListener, finalError);
                                            } else if (ErrorFactory.isCardLockedUnsubscribedError(prevError)) {
                                                deleteAllData(context, storeManager, listener, synchronizationListener, prevError);
                                            } else {
                                                finishKO(finalError, listener, synchronizationListener);
                                            }
                                        }

                                        @Override
                                        public void onFailure(Error error) {
                                            if (finalError != null) {
                                                finalError.setPreviousError(error);
                                                finishKO(finalError, listener, synchronizationListener);
                                            } else {
                                                finishKO(error, listener, synchronizationListener);
                                            }
                                        }
                                    });
                                } else {
                                    finishKO(finalError, listener, synchronizationListener);
                                }
                            }
                        });
            }

            @Override
            public void onFailure(Error error) {
                finishKO(error, listener, synchronizationListener);
            }
        });
    }

    private static void sendPendingRechargeConfirm(@NonNull final ContextWrapper context, @NonNull final GaStoreManager storeManager, @NonNull final GaRestController restController, @NonNull final SecurityHelper securityHelper, final RequestListener<Void> listener, final SynchronizationListener synchronizationListener) {
        CoreController.getLogger().logDebug("SyncController::sendPendingRechargeConfirm", "REST_Send PendingRechargeConfirm");
        RechargeController.doConfirmRecharge(context, storeManager, restController, securityHelper, new RequestListener<Void>() {
            @Override
            public void onSuccess(Void response) {
                finishOK(context, listener, synchronizationListener);
            }

            @Override
            public void onFailure(Error error) {
                finishKO(error, listener, synchronizationListener);
            }
        });
    }

    private static void sendPendingProfileUpdateConfirm(@NonNull final ContextWrapper context, @NonNull final GaStoreManager storeManager, @NonNull final GaRestController restController, @NonNull final SecurityHelper securityHelper, final RequestListener<Void> listener, final SynchronizationListener synchronizationListener) {
        CoreController.getLogger().logDebug("SyncController::sendPendingProfileUpdateConfirm", "REST_Send PendingProfileUpdateConfirm");
        ProfileUpdateController.confirmProfileUpdate(context, storeManager, restController, securityHelper, new RequestListener<Void>() {
            @Override
            public void onSuccess(Void response) {
                finishOK(context, listener, synchronizationListener);
            }

            @Override
            public void onFailure(Error error) {
                finishKO(error, listener, synchronizationListener);
            }
        });
    }

    private static List<TransactionLine> convertForRest(List<Transaction> transactions) {
        List<TransactionLine> transactionLines = new ArrayList<>();
        if (transactions != null && transactions.size() > 0) {
            TransactionMapper mapper = new TransactionMapper();
            for (Transaction transaction : transactions) {
                transactionLines.add(mapper.storeToRest(transaction));
            }
        }

        return transactionLines;
    }

}
