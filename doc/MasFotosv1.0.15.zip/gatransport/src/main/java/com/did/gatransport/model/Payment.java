package com.did.gatransport.model;

import android.os.Parcel;
import android.os.Parcelable;

public class Payment implements Parcelable {

    private int amount;

    public Payment() {
    }

    public Payment(Parcel in) {
        this.amount = in.readInt();
    }

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel out, int flags) {
        out.writeInt(amount);
    }

    public static final Creator<Payment> CREATOR
            = new Creator<Payment>() {
        public Payment createFromParcel(Parcel in) {
            return new Payment(in);
        }

        public Payment[] newArray(int size) {
            return new Payment[size];
        }
    };

    public int getAmount() {
        return amount;
    }

    public void setAmount(int amount) {
        this.amount = amount;
    }
}
