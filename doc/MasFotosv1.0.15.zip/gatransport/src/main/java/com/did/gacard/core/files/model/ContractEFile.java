package com.did.gacard.core.files.model;

import com.did.gacard.ecard.util.ByteArray;
import com.google.gson.annotations.SerializedName;

public final class ContractEFile {

    @SerializedName("struct_contract")
    private byte[] structContract;
    @SerializedName("counter")
    private byte[] counterContract;

    public ContractEFile() {
    }

    public ContractEFile(ContractEFile other) {
        if (other == null) return;
        this.structContract = ByteArray.copyOf(other.structContract);
        this.counterContract = ByteArray.copyOf(other.counterContract);
    }

    public byte[] getStructContract() {
        return structContract;
    }

    public void setStructContract(byte[] structContract) {
        this.structContract = structContract;
    }

    public byte[] getCounterContract() {
        return counterContract;
    }

    public void setCounterContract(byte[] counterContract) {
        this.counterContract = counterContract;
    }
}
