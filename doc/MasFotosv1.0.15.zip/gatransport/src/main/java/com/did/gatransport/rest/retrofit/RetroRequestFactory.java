package com.did.gatransport.rest.retrofit;

import com.did.gatransport.rest.retrofit.request.BalanceRequest;
import com.did.gatransport.rest.retrofit.request.CheckProfileUpdateRequest;
import com.did.gatransport.rest.retrofit.request.ConfirmEnrollRequest;
import com.did.gatransport.rest.retrofit.request.ConfirmProfileUpdateRequest;
import com.did.gatransport.rest.retrofit.request.EnrollManageRequest;
import com.did.gatransport.rest.retrofit.request.EnrollRequest;
import com.did.gatransport.rest.retrofit.request.FinishEnrollRequest;
import com.did.gatransport.rest.retrofit.request.ManageRequest;
import com.did.gatransport.rest.retrofit.request.PendingPaymentRequest;
import com.did.gatransport.rest.retrofit.request.ProfileUpdateRequest;
import com.did.gatransport.rest.retrofit.request.RechargeRequest;
import com.did.gatransport.rest.retrofit.request.RegisterPushChannelRequest;
import com.did.gatransport.rest.retrofit.request.Request;
import com.did.gatransport.rest.retrofit.request.TokenCardRequest;
import com.did.gatransport.rest.retrofit.request.TransactionRequest;

final class RetroRequestFactory {
    // ACTIONS
    private static final String ACTION_PAN_ENROLLMENT = "request_pan"; // Registro mediante PAN
    private static final String ACTION_DNI_ENROLLMENT = "request_dni"; // Registro mediante DNI
    private static final String ACTION_OTP_ENROLLMENT = "enroll_otp"; // Registro de confirmación del mensaje OTP
    private static final String ACTION_USER_ENROLLMENT = "enroll_user"; // Registro de confirmación del mensaje OTP
    private static final String ACTION_BLOCK_CARD = "block_card"; // Finalización del proceso de registro mediante confirmación
    private static final String ACTION_CONFIRM_ENROLLMENT = "confirm"; // Finalización del proceso de registro mediante confirmación
    private static final String ACTION_PROFILE_CHECK = "profile_change_list"; // Obtener lista de cambios de perfil (10 últimos)
    private static final String ACTION_PROFILE_UPTATE = "profile_change_request"; // Petición de actualización de perfil
    private static final String ACTION_CONFIRM_PROFILE_UPTATE = "profile_change_confirm"; // Petición de actualización de perfil
    private static final String ACTION_RECHARGE = "refund"; // Recarga de saldo
    private static final String ACTION_REFUND_LIST = "pending_refund_list"; // Comprobación de abonos pendientes
    private static final String ACTION_TOKEN_CARD_LIST = "token_card_list"; // Comprobación de tarjetas tokenizadas
    private static final String ACTION_PENDING_RECHARGE = "pending_refund"; // Petición de recarga de abonos pendientes
    private static final String ACTION_BALANCE = "balance"; // Sincronización del saldo
    private static final String ACTION_TRANSACTIONS = "transaction"; // Sincronización de transacciones
    private static final String ACTION_CARD_MANAGEMENT = "card_mgmt"; // Gestión de la tarjeta
    private static final String ACTION_REGISTER_PUSH_CHANNEL = "dev_id_reg"; // Gestión de la tarjeta
    private static final String ACTION_FAKE_RECHARGE = "signature"; // Recarga fake

    // TYPES
    private static final String TYPE_ENROLL_REQUEST = "Enroll_Requests"; // Para peticiones de registro
    private static final String TYPE_ENROLLED_PHONES = "Enrolled_Phones"; // Para peticiones de dispositivos registrados
    private static final String TYPE_PHONE_TRANSACTIONS = "Phone_Transactions"; // Para peticiones de transacciones
    private static final String TYPE_TOKEN_PAYMENT = "token_payment"; // Para peticiones de pago con tarjeta tokenizada

    // PRODUCT
    private static final String PRODUCT_GALICIA = "GaliciaTransporte"; // Nombre del producto que ataca a CoB

    // USER
    private static final String USER_ENROLLMENT = "GtPnE"; // Usuario utilizado durante el registro

    private static void setRequest(Request request, String user, String type, String action) {
        if (request == null)
            return;
        request.setProduct(PRODUCT_GALICIA);
        request.setUser(user);
        request.setAction(action);
        request.setType(type);
    }

    static Request<EnrollRequest> panEnrollRequest(EnrollRequest value) {
        Request<EnrollRequest> request = new Request<>(value);
        setRequest(request, USER_ENROLLMENT, TYPE_ENROLL_REQUEST, ACTION_PAN_ENROLLMENT);

        return request;
    }

    static Request<EnrollRequest> dniEnrollRequest(EnrollRequest value) {
        Request<EnrollRequest> request = new Request<>(value);
        setRequest(request, USER_ENROLLMENT, TYPE_ENROLL_REQUEST, ACTION_DNI_ENROLLMENT);

        return request;
    }

    static Request<FinishEnrollRequest> otpFinishEnrollRequest(FinishEnrollRequest value) {
        Request<FinishEnrollRequest> request = new Request<>(value);
        setRequest(request, USER_ENROLLMENT, TYPE_ENROLL_REQUEST, ACTION_OTP_ENROLLMENT);

        return request;
    }

    static Request<FinishEnrollRequest> userFinishEnrollRequest(FinishEnrollRequest value) {
        Request<FinishEnrollRequest> request = new Request<>(value);
        setRequest(request, USER_ENROLLMENT, TYPE_ENROLL_REQUEST, ACTION_USER_ENROLLMENT);

        return request;
    }

    static Request<EnrollManageRequest> enrollManageCardRequest(EnrollManageRequest value) {
        Request<EnrollManageRequest> request = new Request<>(value);
        setRequest(request, USER_ENROLLMENT, TYPE_ENROLL_REQUEST, ACTION_BLOCK_CARD);

        return request;
    }

    static Request<ConfirmEnrollRequest> confirmEnrollRequestRequest(ConfirmEnrollRequest value) {
        Request<ConfirmEnrollRequest> request = new Request<>(value);
        setRequest(request, USER_ENROLLMENT, TYPE_ENROLL_REQUEST, ACTION_CONFIRM_ENROLLMENT);

        return request;
    }

    static Request<CheckProfileUpdateRequest> checkProfileUpdateRequest(String user, CheckProfileUpdateRequest value) {
        Request<CheckProfileUpdateRequest> request = new Request<>(value);
        setRequest(request, user, TYPE_ENROLLED_PHONES, ACTION_PROFILE_CHECK);

        return request;
    }

    static Request<ProfileUpdateRequest> profileUpdateRequest(String user, ProfileUpdateRequest value) {
        Request<ProfileUpdateRequest> request = new Request<>(value);
        setRequest(request, user, TYPE_ENROLLED_PHONES, ACTION_PROFILE_UPTATE);

        return request;
    }

    static Request<ConfirmProfileUpdateRequest> confirmProfileUpdateRequest(String user, ConfirmProfileUpdateRequest value) {
        Request<ConfirmProfileUpdateRequest> request = new Request<>(value);
        setRequest(request, user, TYPE_ENROLLED_PHONES, ACTION_CONFIRM_PROFILE_UPTATE);

        return request;
    }

    static Request<RechargeRequest> cardRechargeRequest(String user, RechargeRequest value) {
        Request<RechargeRequest> request = new Request<>(value);
        setRequest(request, user, TYPE_ENROLLED_PHONES, ACTION_RECHARGE);

        return request;
    }

    static Request<RechargeRequest> tokenCardFinishRechargeRequest(String user, RechargeRequest value) {
        Request<RechargeRequest> request = new Request<>(value);
        setRequest(request, user, TYPE_TOKEN_PAYMENT, ACTION_RECHARGE);

        return request;
    }

    static Request<RechargeRequest> pendingRechargeRequestRequest(String user, RechargeRequest value) {
        Request<RechargeRequest> request = new Request<>(value);
        setRequest(request, user, TYPE_ENROLLED_PHONES, ACTION_PENDING_RECHARGE);

        return request;
    }

    static Request<PendingPaymentRequest> pendingPaymentRequest(String user, PendingPaymentRequest value) {
        Request<PendingPaymentRequest> request = new Request<>(value);
        setRequest(request, user, TYPE_PHONE_TRANSACTIONS, ACTION_REFUND_LIST);

        return request;
    }

    static Request<TokenCardRequest> tokenCardRequest(String user, TokenCardRequest value) {
        Request<TokenCardRequest> request = new Request<>(value);
        setRequest(request, user, TYPE_ENROLLED_PHONES, ACTION_TOKEN_CARD_LIST);

        return request;
    }

    static Request<BalanceRequest> balanceRequest(String user, BalanceRequest value) {
        Request<BalanceRequest> request = new Request<>(value);
        setRequest(request, user, TYPE_ENROLLED_PHONES, ACTION_BALANCE);

        return request;
    }

    static Request<TransactionRequest> transactionRequest(String user, TransactionRequest value) {
        Request<TransactionRequest> request = new Request<>(value);
        setRequest(request, user, TYPE_PHONE_TRANSACTIONS, ACTION_TRANSACTIONS);

        return request;
    }

    static Request<ManageRequest> manageRequest(String user, ManageRequest value) {
        Request<ManageRequest> request = new Request<>(value);
        setRequest(request, user, TYPE_ENROLLED_PHONES, ACTION_CARD_MANAGEMENT);

        return request;
    }

    static Request<RegisterPushChannelRequest> registerPushChannelRequest(String user, RegisterPushChannelRequest value) {
        Request<RegisterPushChannelRequest> request = new Request<>(value);
        setRequest(request, user, TYPE_ENROLLED_PHONES, ACTION_REGISTER_PUSH_CHANNEL);

        return request;
    }

    // TODO ONLY FOR DEBUG
//    static Request<FakeRechargeRequest> fakeRechargeRequestRequest(String user, FakeRechargeRequest value) {
//        Request<FakeRechargeRequest> request = new Request<>(value);
//        setRequest(request, user, TYPE_ENROLLED_PHONES, ACTION_FAKE_RECHARGE);
//
//        return request;
//    }
}
