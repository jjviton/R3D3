package com.did.gacard.core.protocol;

import com.did.gacard.GaCard;
import com.did.gacard.ecard.core.iso7816.CommandApdu;
import com.did.gacard.ecard.core.iso7816.ResponseApdu;

import java.io.ByteArrayOutputStream;

public final class GaCommandFactory {
    private static final String TAG = "GaCommandFactory";

    // TOOLS

    private static boolean checkArray(byte[] bytes, int length) {
        return bytes != null && bytes.length == length;
    }

    // APDU

    // COMMON
    public static final byte CLA = (byte) 0x80;

    public static final byte MASK_B40 = (byte) 0x1F;

    public static final byte RATIFICATION_PENDING = (byte) 0x80;
    public static final byte RATIFICATION_DONE = (byte) 0x00;

    // INSTRUCTION
    public static final byte INS_26 = (byte) 0x26;
    public static final byte INS_28 = (byte) 0x28;
    public static final byte INS_2A = (byte) 0x2A;
    public static final byte INS_2C = (byte) 0x2C;
    public static final byte INS_2E = (byte) 0x2E;
    public static final byte INS_30 = (byte) 0x30;
    public static final byte INS_32 = (byte) 0x32;
    public static final byte INS_34 = (byte) 0x34;
    public static final byte INS_36 = (byte) 0x36;
    public static final byte INS_38 = (byte) 0x38;
    public static final byte INS_3A = (byte) 0x3A;
    public static final byte INS_88 = (byte) 0x88;
    public static final byte INS_C0 = (byte) 0xC0;

    public final static byte[] INS_READ_APPLET_VERSION = {CLA, (byte) 0xCA};
    public final static byte[] INS_SELECT_TRANSPORT_NETWORK = {CLA, INS_26};
    public final static byte[] INS_OPEN_VALIDATOR_SESSION = {CLA, INS_28};
    public final static byte[] INS_CLOSE_VALIDATOR_SESSION = {CLA, INS_2A};
    public final static byte[] INS_CLEAR_RATIFICATION_BIT = {CLA, INS_2C};
    public final static byte[] INS_READ_CONTRACT = {CLA, INS_2E};
    public final static byte[] INS_READ_EVENT = {CLA, INS_30};
    public final static byte[] INS_READ_ENV_HOLDER_TOKEN = {CLA, INS_32};
    public final static byte[] INS_WRITE_CONTRACT = {CLA, INS_34};
    public final static byte[] INS_WRITE_EVENT = {CLA, INS_36};
    public final static byte[] INS_WRITE_ENV_HOLDER_PROFILE = {CLA, INS_38};
    public final static byte[] INS_RELOAD_TOKEN_PURSE = {CLA, INS_3A};
    public final static byte[] INS_INTERNAL_AUTHENTICATE = {CLA, INS_88};
    public final static byte[] INS_GET_RESPONSE = {CLA, INS_C0};

    // P1
    private static final byte P1_00 = (byte) 0x00;

    // P2
    public static final byte P2_00 = (byte) 0x00;
    public static final byte P2_01 = (byte) 0x01;
    private static final byte P2_81 = (byte) 0x81;

    // LC
    public static final byte LC_04 = (byte) 0x04;
    public static final byte LC_24 = (byte) 0x24;
    private static final byte LC_28 = (byte) 0x28;
    private static final byte LC_1D = (byte) 0x1D;
    private static final byte LC_0B = (byte) 0x0B;
    private static final byte LC_08 = (byte) 0x08;

    // LE
    private static final byte LE_0A = (byte) 0x0A;
    private static final byte LE_3A = (byte) 0x3A;
    private static final byte LE_04 = (byte) 0x04;
    private static final byte LE_00 = (byte) 0x00;
    private static final byte LE_20 = (byte) 0x20;
    private static final byte LE_1D = (byte) 0x1D;
    private static final byte LE_18 = (byte) 0x18;

    // Command
    public static final short SELECT_TRANSPORT_NETWORK = 0;
    public static final short OPEN_VALIDATOR_SESSION = 1;
    public static final short CLOSE_VALIDATOR_SESSION = 2;
    public static final short CANCEL_VALIDATOR_SESSION = 3;
    public static final short CLEAR_RATIFICATION_BIT = 4;
    public static final short READ_CONTRACT = 5;
    public static final short READ_EVENT = 6;
    public static final short READ_ENV_HOL_TOK = 7;
    public static final short WRITE_CONTRACT = 8;
    public static final short WRITE_EVENT = 9;
    public static final short WRITE_ENV_HOL = 10;
    public static final short RELOAD_TOKEN_PURSE = 11;
    public static final short INTERNAL_AUTH = 12;
    public static final short GET_RESPONSE = 13;

    private static final CommandApdu APDU_SELECT_TRANSPORT_NETWORK = new CommandApdu.Builder().cla(CLA).id(SELECT_TRANSPORT_NETWORK).ins(INS_26).notLc().notData().le(LE_0A).build();

    private static final CommandApdu APDU_OPEN_VALIDATOR_SESSION = new CommandApdu.Builder().cla(CLA).id(OPEN_VALIDATOR_SESSION).ins(INS_28).p1(P1_00).p2(P2_00).lc(LC_04).le(LE_3A).build();

    private static final CommandApdu APDU_CLOSE_VALIDATOR_SESSION = new CommandApdu.Builder().cla(CLA).id(CLOSE_VALIDATOR_SESSION).ins(INS_2A).p2(P2_00).lc(LC_04).le(LE_04).build();
    private static final CommandApdu APDU_CLOSE_VALIDATOR_SESSION_2 = new CommandApdu.Builder().cla(CLA).id(CLOSE_VALIDATOR_SESSION).ins(INS_2A).p2(P2_00).lc(LC_24).le(LE_04).build();

    private static final CommandApdu APDU_CANCEL_VALIDATOR_SESSION = new CommandApdu.Builder().cla(CLA).id(CANCEL_VALIDATOR_SESSION).ins(INS_2A).p2(P2_01).lc(LC_24).le(LE_04).build();

    private static final CommandApdu APDU_CLEAR_RATIFICATION_BIT = new CommandApdu.Builder().cla(CLA).id(CLEAR_RATIFICATION_BIT).ins(INS_2C).p1(P1_00).p2(P2_00).notLc().notData().le(LE_00).build();

    private static final CommandApdu APDU_READ_CONTRACT = new CommandApdu.Builder().cla(CLA).id(READ_CONTRACT).ins(INS_2E).p2(P2_00).notLc().notData().le(LE_20).build();

    private static final CommandApdu APDU_READ_EVENT = new CommandApdu.Builder().cla(CLA).id(READ_EVENT).ins(INS_30).p2(P2_00).notLc().notData().le(LE_1D).build();

    private static final CommandApdu APDU_READ_ENV_HOL_TOK = new CommandApdu.Builder().cla(CLA).id(READ_ENV_HOL_TOK).ins(INS_32).p1(P1_00).p2(P2_00).notLc().notData().le(LE_18).build();

    private static final CommandApdu APDU_WRITE_CONTRACT = new CommandApdu.Builder().cla(CLA).id(WRITE_CONTRACT).ins(INS_34).lc(LC_28).notLe().build();

    private static final CommandApdu APDU_WRITE_EVENT = new CommandApdu.Builder().cla(CLA).id(WRITE_EVENT).ins(INS_36).p1(P1_00).p2(P2_00).lc(LC_28).notLe().build();

    private static final CommandApdu APDU_WRITE_ENV_HOL = new CommandApdu.Builder().cla(CLA).id(WRITE_ENV_HOL).ins(INS_38).p1(P1_00).lc(LC_1D).notLe().build();

    private static final CommandApdu APDU_RELOAD_TOKEN_PURSE = new CommandApdu.Builder().cla(CLA).id(RELOAD_TOKEN_PURSE).ins(INS_3A).p1(P1_00).lc(LC_0B).notLe().build();

    private static final CommandApdu APDU_INTERNAL_AUTH = new CommandApdu.Builder().cla(CLA).id(INTERNAL_AUTH).ins(INS_88).p1(P1_00).p2(P2_81).lc(LC_08).le(LE_0A).build();

    private static final CommandApdu APDU_GET_RESPONSE = new CommandApdu.Builder().cla(CLA).id(GET_RESPONSE).ins(INS_C0).p1(P1_00).p2(P2_00).notLc().notData().build();

    public static CommandApdu getCommand(byte[] apdu) {
        CommandApdu commandApdu;

        // SELECT_TRANSPORT_NETWORK
        commandApdu = APDU_SELECT_TRANSPORT_NETWORK;
        if (commandApdu.digest(apdu)) {
            return commandApdu;
        }

        // OPEN_VALIDATOR_SESSION
        commandApdu = APDU_OPEN_VALIDATOR_SESSION;
        if (commandApdu.digest(apdu)) {
            return commandApdu;
        }

        // CLOSE_VALIDATOR_SESSION
        commandApdu = APDU_CLOSE_VALIDATOR_SESSION;
        if (commandApdu.digest(apdu)) {
            return commandApdu;
        }

        // CLOSE_VALIDATOR_SESSION 2
        commandApdu = APDU_CLOSE_VALIDATOR_SESSION_2;
        if (commandApdu.digest(apdu)) {
            return commandApdu;
        }

        // CANCEL_VALIDATOR_SESSION
        commandApdu = APDU_CANCEL_VALIDATOR_SESSION;
        if (commandApdu.digest(apdu)) {
            return commandApdu;
        }

        // CLEAR_RATIFICATION_BIT
        commandApdu = APDU_CLEAR_RATIFICATION_BIT;
        if (commandApdu.digest(apdu)) {
            return commandApdu;
        }

        // READ_CONTRACT
        commandApdu = APDU_READ_CONTRACT;
        if (commandApdu.digest(apdu)) {
            return commandApdu;
        }

        // READ_EVENT
        commandApdu = APDU_READ_EVENT;
        if (commandApdu.digest(apdu)) {
            return commandApdu;
        }

        // READ_ENV_HOL_TOK
        commandApdu = APDU_READ_ENV_HOL_TOK;
        if (commandApdu.digest(apdu)) {
            return commandApdu;
        }

        // WRITE_CONTRACT
        commandApdu = APDU_WRITE_CONTRACT;
        if (commandApdu.digest(apdu)) {
            return commandApdu;
        }

        // WRITE_EVENT
        commandApdu = APDU_WRITE_EVENT;
        if (commandApdu.digest(apdu)) {
            return commandApdu;
        }

        // WRITE_ENV_HOL
        commandApdu = APDU_WRITE_ENV_HOL;
        if (commandApdu.digest(apdu)) {
            return commandApdu;
        }

        // RELOAD_TOKEN_PURSE
        commandApdu = APDU_RELOAD_TOKEN_PURSE;
        if (commandApdu.digest(apdu)) {
            return commandApdu;
        }

        // INTERNAL_AUTH
        commandApdu = APDU_INTERNAL_AUTH;
        if (commandApdu.digest(apdu)) {
            return commandApdu;
        }

        // GET_RESPONSE
        commandApdu = APDU_GET_RESPONSE;
        if (commandApdu.digest(apdu)) {
            return commandApdu;
        }

        return null;
    }

    // RESPONSES

    public static ResponseApdu buildResponseSelectTransportNetwork(byte[] nt, byte[] serialNumber, byte[] state, byte[] defaultState) {
        if (!checkArray(nt, 2)
                || !checkArray(serialNumber, 8)
                || !checkArray(state, 2)) {
            return new ResponseApdu(defaultState);
        }

        ByteArrayOutputStream outputStream = new ByteArrayOutputStream();
        try {
            outputStream.write(nt);
            outputStream.write(serialNumber);
        } catch (Throwable t) {
            GaCard.getInstance().getLogger().logError("GaCommandFactory::digest", "buildResponseSelectTransportNetwork()", t);
        }

        return new ResponseApdu(outputStream.toByteArray(), state);
    }

    public static ResponseApdu buildResponseOpenValidatorSession(byte[] nt, byte[] impEvent, byte[] balEvent, byte[] transEvent, byte[] eventStruct, byte[] envirStruct, byte[] holderStruct, byte[] purseValue, byte[] ratification, byte[] cardChallenge, byte[] state, byte[] defaultState) {
        if (!checkArray(nt, 2)
                || !checkArray(impEvent, 2)
                || !checkArray(balEvent, 3)
                || !checkArray(transEvent, 1)
                || !checkArray(eventStruct, 21)
                || !checkArray(envirStruct, 9)
                || !checkArray(holderStruct, 12)
                || !checkArray(purseValue, 3)
                || !checkArray(ratification, 1)
                || !checkArray(cardChallenge, 4)
                || !checkArray(state, 2)) {
            return new ResponseApdu(defaultState);
        }

        ByteArrayOutputStream outputStream = new ByteArrayOutputStream();
        try {
            outputStream.write(nt);
            outputStream.write(impEvent);
            outputStream.write(balEvent);
            outputStream.write(transEvent);
            outputStream.write(eventStruct);
            outputStream.write(envirStruct);
            outputStream.write(holderStruct);
            outputStream.write(purseValue);
            outputStream.write(ratification);
            outputStream.write(cardChallenge);
        } catch (Throwable t) {
            GaCard.getInstance().getLogger().logError("GaCommandFactory::buildResponseOpenValidatorSession", "buildResponseOpenValidatorSession()", t);
        }

        return new ResponseApdu(outputStream.toByteArray(), state);
    }

    public static ResponseApdu buildResponseCloseValidatorSession(byte[] certificateLo, byte[] state, byte[] defaultState) {
        if (!checkArray(certificateLo, 4)
                || !checkArray(state, 2)) {
            return new ResponseApdu(defaultState);
        }

        ByteArrayOutputStream outputStream = new ByteArrayOutputStream();
        try {
            outputStream.write(certificateLo);
        } catch (Throwable t) {
            GaCard.getInstance().getLogger().logError("GaCommandFactory::buildResponseCloseValidatorSession", "buildResponseCloseValidatorSession()", t);
        }

        return new ResponseApdu(outputStream.toByteArray(), state);
    }

    public static ResponseApdu buildResponseCancelValidatorSession(byte[] certificateLo, byte[] state, byte[] defaultState) {
        if (!checkArray(certificateLo, 4)
                || !checkArray(state, 2)) {
            return new ResponseApdu(defaultState);
        }

        ByteArrayOutputStream outputStream = new ByteArrayOutputStream();
        try {
            outputStream.write(certificateLo);
        } catch (Throwable t) {
            GaCard.getInstance().getLogger().logError("GaCommandFactory::buildResponseCancelValidatorSession", "buildResponseCancelValidatorSession()", t);
        }

        return new ResponseApdu(outputStream.toByteArray(), state);
    }

    public static ResponseApdu buildResponseClearRatificationBit(byte[] state, byte[] defaultState) {
        if (!checkArray(state, 2)) {
            return new ResponseApdu(defaultState);
        }

        return new ResponseApdu(state);
    }

    public static ResponseApdu buildResponseReadContact(byte[] contractStruct, byte[] counterVal, byte[] state, byte[] defaultState) {
        if (!checkArray(contractStruct, 29)
                || !checkArray(counterVal, 3)
                || !checkArray(state, 2)) {
            return new ResponseApdu(defaultState);
        }

        ByteArrayOutputStream outputStream = new ByteArrayOutputStream();
        try {
            outputStream.write(contractStruct);
            outputStream.write(counterVal);
        } catch (Throwable t) {
            GaCard.getInstance().getLogger().logError("GaCommandFactory::buildResponseReadContact", "buildResponseReadContact()", t);
        }

        return new ResponseApdu(outputStream.toByteArray(), state);
    }

    public static ResponseApdu buildResponseReadEvent(byte[] nt, byte[] impEvent, byte[] balEvent, byte[] transEvent, byte[] eventStruct, byte[] state, byte[] defaultState) {
        if (!checkArray(nt, 2)
                || !checkArray(impEvent, 2)
                || !checkArray(balEvent, 3)
                || !checkArray(transEvent, 1)
                || !checkArray(eventStruct, 21)
                || !checkArray(state, 2)) {
            return new ResponseApdu(defaultState);
        }

        ByteArrayOutputStream outputStream = new ByteArrayOutputStream();
        try {
            outputStream.write(nt);
            outputStream.write(impEvent);
            outputStream.write(balEvent);
            outputStream.write(transEvent);
            outputStream.write(eventStruct);
        } catch (Throwable t) {
            GaCard.getInstance().getLogger().logError("GaCommandFactory::buildResponseReadEvent", "buildResponseReadEvent()", t);
        }

        return new ResponseApdu(outputStream.toByteArray(), state);
    }

    public static ResponseApdu buildResponseReadEnvironmentHolderProfilesTokenPurse(byte[] envirStruct, byte[] holderStruct, byte[] purseValue, byte[] state, byte[] defaultState) {
        if (!checkArray(envirStruct, 9)
                || !checkArray(holderStruct, 12)
                || !checkArray(purseValue, 3)
                || !checkArray(state, 2)) {
            return new ResponseApdu(defaultState);
        }

        ByteArrayOutputStream outputStream = new ByteArrayOutputStream();
        try {
            outputStream.write(envirStruct);
            outputStream.write(holderStruct);
            outputStream.write(purseValue);
        } catch (Throwable t) {
            GaCard.getInstance().getLogger().logError("GaCommandFactory::buildResponseReadEnvironmentHolderProfilesTokenPurse", "buildResponseReadEnvironmentHolderProfilesTokenPurse()", t);
        }

        return new ResponseApdu(outputStream.toByteArray(), state);
    }

    public static ResponseApdu buildResponseWriteContract(byte[] state, byte[] defaultState) {
        if (!checkArray(state, 2)) {
            return new ResponseApdu(defaultState);
        }

        return new ResponseApdu(state);
    }

    public static ResponseApdu buildResponseWriteEvent(byte[] state, byte[] defaultState) {
        if (!checkArray(state, 2)) {
            return new ResponseApdu(defaultState);
        }

        return new ResponseApdu(state);
    }

    public static ResponseApdu buildResponseWriteEnvironmentHolderProfile(byte[] state, byte[] defaultState) {
        if (!checkArray(state, 2)) {
            return new ResponseApdu(defaultState);
        }

        return new ResponseApdu(state);
    }

    public static ResponseApdu buildResponseReloadTokenPurse(byte[] state, byte[] defaultState) {
        if (!checkArray(state, 2)) {
            return new ResponseApdu(defaultState);
        }

        return new ResponseApdu(state);
    }

    public static ResponseApdu buildResponseReadInternalAuth(byte[] nt, byte[] s1, byte[] state, byte[] defaultState) {
        if (!checkArray(nt, 2)
                || !checkArray(s1, 8)
                || !checkArray(state, 2)) {
            return new ResponseApdu(defaultState);
        }

        ByteArrayOutputStream outputStream = new ByteArrayOutputStream();
        try {
            outputStream.write(nt);
            outputStream.write(s1);
        } catch (Throwable t) {
            GaCard.getInstance().getLogger().logError("GaCommandFactory::buildResponseReadInternalAuth", "buildResponseReadContact()", t);
        }

        return new ResponseApdu(outputStream.toByteArray(), state);
    }

    public static ResponseApdu buildResponseGetResponse(byte[] data, int dataLength, byte[] state, byte[] defaultState) {
        if (!checkArray(data, dataLength)
                || !checkArray(state, 2)) {
            return new ResponseApdu(defaultState);
        }

        ByteArrayOutputStream outputStream = new ByteArrayOutputStream();
        try {
            outputStream.write(data);
        } catch (Throwable t) {
            GaCard.getInstance().getLogger().logError("GaCommandFactory::buildResponseGetResponse", "buildResponseReadContact()", t);
        }

        return new ResponseApdu(outputStream.toByteArray(), state);
    }
}
