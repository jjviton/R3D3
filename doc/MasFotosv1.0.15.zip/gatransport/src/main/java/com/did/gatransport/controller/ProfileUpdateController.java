package com.did.gatransport.controller;

import android.content.ContextWrapper;

import com.did.gacard.ecard.util.ByteArray;
import com.did.gacard.services.GaAppletManager;
import com.did.gatransport.R;
import com.did.gatransport.interfaces.CardHostErrorChainRequestListener;
import com.did.gatransport.interfaces.RequestListener;
import com.did.gatransport.mapper.ProfileUpdateMapper;
import com.did.gatransport.model.Error;
import com.did.gatransport.model.ProfileUpdate;
import com.did.gatransport.model.request.ProfileUpdateRequest;
import com.did.gatransport.rest.GaRestController;
import com.did.gatransport.rest.model.response.BaseResponse;
import com.did.gatransport.rest.model.response.ProfileUpdateListResponse;
import com.did.gatransport.rest.model.response.ProfileUpdateResponse;
import com.did.gatransport.services.GaAppletManagerFactory;
import com.did.gatransport.store.GaStoreManager;
import com.did.gatransport.store.model.ProfileUpdateConfirmRequest;
import com.did.gatransport.store.model.User;
import com.did.gatransport.store.realm.model.ProfileUpdateConfirmRequestRealm;
import com.did.gatransport.util.AmountConverter;
import com.did.gatransport.util.ErrorFactory;
import com.did.security.core.SecurityHelper;

import java.util.ArrayList;
import java.util.List;

public final class ProfileUpdateController {
    private static final int STATE_RUNNING = 0;
    private static final int STATE_WAITING = 1;

    private static int state = STATE_WAITING;

    private static boolean checkIsRunning(ContextWrapper context, RequestListener listener) {
        if (state == STATE_RUNNING) {
            finishKO(ErrorFactory.getWarnError(context, Error.GENERAL_PROCESS_IS_RUNNING), listener);
            return true;
        }
        return false;
    }

    private static void finishKO(Error error, RequestListener listener) {
        CoreController.getLogger().logDebug("ProfileUpdateController::finishKO", "ProfileUpdate KO END");
        CoreController.getLogger().logError("ProfileUpdateController::finishKO", error, "ProfileUpdate KO END");
        state = STATE_WAITING;
        if (listener != null)
            listener.onFailure(error);
    }

    static void getProfileUpdates(final ContextWrapper context, final String language, final GaStoreManager storeManager, final GaRestController restController, final SecurityHelper securityHelper, final RequestListener<List<ProfileUpdate>> listener) {
        CoreController.getLogger().logDebug("ProfileUpdateController::getProfileUpdates", "REST_Send ProfileUpdateListRequest");
        if (checkIsRunning(context, listener)) return;

        state = STATE_RUNNING;

        storeManager.getUser(new RequestListener<User>() {
            @Override
            public void onSuccess(User response) {
                String userToken = response.getToken();
                String user = response.getName();
                String phoneId = response.getPhoneId();
                String pan = response.getCardId();
                String paySolution = response.getPaySolutionType();
                String hwId = securityHelper.getHardwareIdentifier();
                String profile = response.getProfileType();
                String profileExpiration = response.getProfileExpiration();

                // (String userToken, String user, String hwId, String pan, String phoneId, String profile, String profileExpiration, String paySolution, String language, RequestListener<ProfileUpdateListResponse> listener);
                restController.getProfileUpdates(userToken, user, hwId, pan, phoneId, profile, profileExpiration, paySolution, language, new CardHostErrorChainRequestListener<>(context, storeManager, restController, securityHelper, new RequestListener<ProfileUpdateListResponse>() {
                    @Override
                    public void onSuccess(ProfileUpdateListResponse response) {
                        List<ProfileUpdate> profileUpdates;
                        if (response == null)
                            profileUpdates = new ArrayList<>();
                        else
                            profileUpdates = new ProfileUpdateMapper().restToUiList(response.getProfileUpdates());

                        state = STATE_WAITING;

                        CoreController.getLogger().logDebug("ProfileUpdateController::getProfileUpdates", "ProfileUpdateList Size: " + profileUpdates.size());

                        if (listener != null) listener.onSuccess(profileUpdates);
                    }

                    @Override
                    public void onFailure(Error error) {
                        finishKO(error, listener);
                    }
                }));
            }

            @Override
            public void onFailure(Error error) {
                finishKO(error, listener);
            }
        });
    }

    static void performProfileUpdate(final ContextWrapper context, final ProfileUpdateRequest request, final GaStoreManager storeManager, final GaRestController restController, final SecurityHelper securityHelper, final RequestListener<Void> listener) {
        CoreController.getLogger().logDebug("ProfileUpdateController::performProfileUpdate", "UpdateProfile START");
        if (checkIsRunning(context, listener)) return;

        if (request == null) {
            finishKO(ErrorFactory.getWarnError(context, Error.GENERAL_INVALID_INPUT), listener);
            return;
        }

        if (request.getUser() == null || request.getUser().trim().isEmpty()) {
            finishKO(ErrorFactory.getWarnError(context, Error.GENERAL_INVALID_INPUT, new Exception(String.format(context.getString(R.string.EXCEPTION_INVALID_INPUT), "user"))), listener);
            return;
        }

        if (request.getPwd() == null || request.getPwd().trim().isEmpty()) {
            finishKO(ErrorFactory.getWarnError(context, Error.GENERAL_INVALID_INPUT, new Exception(String.format(context.getString(R.string.EXCEPTION_INVALID_INPUT), "pwd"))), listener);
            return;
        }

        if (request.getProfileUpdate() == null) {
            finishKO(ErrorFactory.getWarnError(context, Error.GENERAL_INVALID_INPUT, new Exception(String.format(context.getString(R.string.EXCEPTION_INVALID_INPUT), "profileUpdate"))), listener);
            return;
        }

        state = STATE_RUNNING;

        // First syn
        CoreController.getLogger().logDebug("ProfileUpdateController::performProfileUpdate", "First, doLogin for Authorization refresh.");
        LoginController.login(context, storeManager, restController, request.getUser(), request.getPwd(), new RequestListener<Void>() {
            @Override
            public void onSuccess(Void response) {
                CoreController.getLogger().logDebug("ProfileUpdateController::performProfileUpdate", "Second, doSync.");
                SyncController.sync(context, storeManager, restController, securityHelper, new RequestListener<Void>() {
                    @Override
                    public void onSuccess(Void response) {
                        continueProfileUpdate(context, request.getProfileUpdate(), storeManager, restController, securityHelper, listener);
                    }

                    @Override
                    public void onFailure(Error error) {
                        finishKO(error, listener);
                    }
                });
            }

            @Override
            public void onFailure(Error error) {
                finishKO(error, listener);
            }
        });
    }


    private static void continueProfileUpdate(final ContextWrapper context, final ProfileUpdate profileUpdate, final GaStoreManager storeManager, final GaRestController restController, final SecurityHelper securityHelper, final RequestListener<Void> listener) {
        CoreController.getLogger().logDebug("ProfileUpdateController::continueProfileUpdate", "Third, REST_Send ProfileUpdateRequest.");
        storeManager.getUser(new RequestListener<User>() {
            @Override
            public void onSuccess(final User user) {
                String userToken = user.getToken();
                String userName = user.getName();
                String phoneId = user.getPhoneId();
                String pan = user.getCardId();
                String paySolution = user.getPaySolutionType();
                String hwId = securityHelper.getHardwareIdentifier();

                String type = profileUpdate.getType();

                final GaAppletManager gaAppletManager = GaAppletManagerFactory.getGaCardManager(context);
                String profileTimestamp = profileUpdate.getTimestamp();

                try {
                    String nt = String.valueOf(ByteArray.arrayByteToInt(gaAppletManager.getNt()));
                    String balance = AmountConverter.getDecimalAmountString(ByteArray.arrayByteToInt(gaAppletManager.getBalance()));
                    String structEnvironmentUser = ByteArray.byteArrayToHexString(gaAppletManager.getGenData());
                    String lastEvent = ByteArray.byteArrayToHexString(gaAppletManager.getLastEvent());

                    // String userToken, String user, String hwId, String pan, String phoneId, String profileTimestamp, String paySolution, String nt, String lastEvent, String structEnvironmentUser, String balance, RequestListener<ProfileUpdateResponse> listener
                    restController.performProfileUpdate(userToken, userName, hwId, pan, phoneId, type, profileTimestamp, paySolution, nt, lastEvent, structEnvironmentUser, balance, new CardHostErrorChainRequestListener<>(context, storeManager, restController, securityHelper, new RequestListener<ProfileUpdateResponse>() {
                        @Override
                        public void onSuccess(ProfileUpdateResponse response) {
                            final String oldProfile = profileUpdate.getCurrentProfile();
                            final String oldProfileExpiration = profileUpdate.getCurrentProfileExpiration();

                            final String newProfile = profileUpdate.getNewProfile();
                            final String newProfileExpiration = profileUpdate.getNewProfileExpiration();

                            final String timestamp = profileUpdate.getTimestamp();


                            try {
                                // Update card data
                                gaAppletManager.updateProfileUser(response.getNewStructEnvironmentUser(), response.getNewEvent());


                                // Update Signature
                                byte[] signature = response.getNewSignature();
                                securityHelper.saveSecret(SecurityHelper.FOUR_BYTES, signature);

                                // Update user data
                                storeManager.updateUserProfile(newProfile, newProfileExpiration, new RequestListener<Void>() {
                                    @Override
                                    public void onSuccess(Void response) {
                                        // Save confirmation request
                                        final ProfileUpdateConfirmRequest profileUpdateConfirmRequest = new ProfileUpdateConfirmRequestRealm();
                                        // Save old profile data
                                        profileUpdateConfirmRequest.setOldProfile(oldProfile);
                                        profileUpdateConfirmRequest.setOldProfileExpiration(oldProfileExpiration);
                                        // Save new profile data
                                        profileUpdateConfirmRequest.setNewProfile(newProfile);
                                        profileUpdateConfirmRequest.setNewProfileExpiration(newProfileExpiration);

                                        profileUpdateConfirmRequest.setTimestamp(timestamp);

                                        CoreController.getLogger().logDebug("ProfileUpdateController::continueProfileUpdate", "Fourth, DB_SAVE ProfileUpdateConfirm.");
                                        storeManager.insert(profileUpdateConfirmRequest, new RequestListener<Void>() {
                                            @Override
                                            public void onSuccess(Void response) {
                                                CoreController.getLogger().logDebug("ProfileUpdateController::continueProfileUpdate", "Fifth(Last), REST_SEND ProfileUpdateConfirm.");
                                                confirmProfileUpdate(context, user, profileUpdateConfirmRequest, storeManager, restController, securityHelper, gaAppletManager, listener);
                                            }

                                            @Override
                                            public void onFailure(Error error) {
                                                Error error2 = ErrorFactory.getFatalError(context, Error.ENROLL_CANNOT_UPDATE_PROFILE);
                                                error2.setPreviousError(error);
                                                finishKO(error2, listener);
                                            }
                                        });
                                    }

                                    @Override
                                    public void onFailure(Error error) {
                                        finishKO(error, listener);
                                    }
                                });
                            } catch (Exception e) {
                                Error error = ErrorFactory.getFatalError(context, Error.GENERAL_UNEXPECTED_EXCEPTION, e);
                                CoreController.getLogger().logError("ProfileUpdateController::continueProfileUpdate", error);
                                finishKO(error, listener);
                            }
                        }

                        @Override
                        public void onFailure(Error error) {
                            finishKO(error, listener);
                        }
                    }));
                } catch (Exception e) {
                    Error error = ErrorFactory.getFatalError(context, Error.GENERAL_UNEXPECTED_EXCEPTION, e);
                    CoreController.getLogger().logError("ProfileUpdateController::continueProfileUpdate", error);
                    finishKO(error, listener);
                }
            }

            @Override
            public void onFailure(Error error) {
                finishKO(error, listener);
            }
        });
    }

    private static void confirmProfileUpdate(ContextWrapper context, User user, ProfileUpdateConfirmRequest profileUpdateConfirmRequest, final GaStoreManager storeManager, final GaRestController restController, final SecurityHelper securityHelper, GaAppletManager gaAppletManager, final RequestListener<Void> listener) {
        try {
            String userToken = user.getToken();
            String userName = user.getName();
            String phoneId = user.getPhoneId();
            String pan = user.getCardId();
            String paySolution = user.getPaySolutionType();
            String hwId = securityHelper.getHardwareIdentifier();


            String oldProfile = profileUpdateConfirmRequest.getOldProfile();
            String oldProfileExpiration = profileUpdateConfirmRequest.getOldProfileExpiration();

            String newProfile = profileUpdateConfirmRequest.getNewProfile();
            String newProfileExpiration = profileUpdateConfirmRequest.getNewProfileExpiration();

            String timestamp = profileUpdateConfirmRequest.getTimestamp();

            String newNt = String.valueOf(ByteArray.arrayByteToInt(gaAppletManager.getNt()));

            // String userToken, String user, String hwId, String pan, String phoneId, String oldProfile, String oldProfileExpiration, String timestamp, String newProfile, String newProfileExpiration, String paySolution, String nt, RequestListener<BaseResponse> listener
            restController.confirmProfileUpdate(userToken, userName, hwId, pan, phoneId, oldProfile, oldProfileExpiration, timestamp, newProfile, newProfileExpiration, paySolution, newNt, new CardHostErrorChainRequestListener<>(context, storeManager, restController, securityHelper, new RequestListener<BaseResponse>() {
                @Override
                public void onSuccess(BaseResponse response) {
                    storeManager.deleteAll(GaStoreManager.TABLE_UPDATE_PROFILE_CONFIRM, new RequestListener<Void>() {
                        @Override
                        public void onSuccess(Void response) {
                            state = STATE_WAITING;

                            CoreController.getLogger().logDebug("ProfileUpdateController::confirmProfileUpdate", "ProfileUpdate Process OK END");

                            if (listener != null) listener.onSuccess(null);
                        }

                        @Override
                        public void onFailure(Error error) {
                            finishKO(error, listener);
                        }
                    });
                }

                @Override
                public void onFailure(Error error) {
                    finishKO(error, listener);
                }
            }));
        } catch (Exception e) {
            Error error = ErrorFactory.getFatalError(context, Error.GENERAL_UNEXPECTED_EXCEPTION, e);
            CoreController.getLogger().logError("ProfileUpdateController::confirmProfileUpdate", error);
            finishKO(error, listener);
        }
    }

    static void confirmProfileUpdate(final ContextWrapper context, final GaStoreManager storeManager, final GaRestController restController, final SecurityHelper securityHelper, final RequestListener<Void> listener) {
        CoreController.getLogger().logDebug("ProfileUpdateController::confirmProfileUpdate", "ConfirmProfileUpdate Process START");
        if (checkIsRunning(context, listener)) return;

        state = STATE_RUNNING;

        storeManager.getUser(new RequestListener<User>() {
            @Override
            public void onSuccess(final User user) {
                storeManager.getProfileUpdateConfirmRequest(new RequestListener<ProfileUpdateConfirmRequest>() {
                    @Override
                    public void onSuccess(ProfileUpdateConfirmRequest profileUpdateConfirmRequest) {
                        confirmProfileUpdate(context, user, profileUpdateConfirmRequest, storeManager, restController, securityHelper, GaAppletManagerFactory.getGaCardManager(context), listener);
                    }

                    @Override
                    public void onFailure(Error error) {
                        finishKO(error, listener);
                    }
                });
            }

            @Override
            public void onFailure(Error error) {
                finishKO(error, listener);
            }
        });
    }
}
