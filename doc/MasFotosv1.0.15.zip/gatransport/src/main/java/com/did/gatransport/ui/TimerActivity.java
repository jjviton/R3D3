package com.did.gatransport.ui;

import android.support.v7.app.AppCompatActivity;

import com.did.gatransport.controller.PreferencesController;

import java.util.Timer;
import java.util.TimerTask;

abstract class TimerActivity extends AppCompatActivity {

    private long TIME = 120 * 60 * 1000; //2 horas
    private Timer timer;

    @Override
    public final void onUserInteraction() {
        super.onUserInteraction();
        launchTimer();
    }

    @Override
    protected void onStart() {
        super.onStart();
        launchTimer();
    }

    @Override
    protected void onStop() {
        super.onStop();
        if (timer != null)
            timer.cancel();
    }

    protected void setInactivityTime(int mins) {
        if (mins < 0)
            throw new IllegalArgumentException("Minutes argument must be greater or equal than 0");
        TIME = mins * 60 * 1000;
    }

    private void launchTimer() {
        if (timer != null)
            timer.cancel();

        if (TIME == 0) return;

        TimerTask task = new TimerTask() {
            @Override
            public void run() {
                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        onUserInactivityEvent();
                    }
                });
            }
        };

        // Simulate a long loading process on application startup.
        timer = new Timer();
        timer.schedule(task, TIME);
    }

    /**
     * This event will be launched when inactivity time is reached
     */
    protected abstract void onUserInactivityEvent();

    @Override
    protected void onResume() {
        super.onResume();
        if (!PreferencesController.getInstance(this).isLogged())
            onUserInactivityEvent();
    }
}
