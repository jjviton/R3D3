package com.did.gatransport.services;

import android.content.Context;
import android.content.ContextWrapper;
import android.content.res.XmlResourceParser;
import android.os.Build;
import android.os.VibrationEffect;
import android.os.Vibrator;

import com.did.gacard.ecard.core.NFCFieldStateListener;
import com.did.gacard.services.GaAppletService;
import com.did.gatransport.controller.CoreController;
import com.did.gatransport.controller.PreferencesController;
import com.did.gatransport.controller.ProcessController;
import com.did.gatransport.controller.SyncController;
import com.did.gatransport.interfaces.TripListener;
import com.did.gatransport.model.Error;
import com.did.gatransport.store.GaStoreFactory;
import com.did.gatransport.store.GaStoreManager;
import com.did.gatransport.util.ErrorFactory;
import com.did.security.core.SecurityHelper;

public abstract class GaCardService extends GaAppletService {

    private static final int VIB_DURATION = 1000; // milliseconds

    private GaStoreManager gaStoreManager;
    private SecurityHelper securityHelper;

    @Override
    public final void onCreate() {
        super.onCreate();
        setManager(new GaCardManager(this, CoreController.getTripListener()));
        securityHelper = new SecurityHelper(this);
        gaStoreManager = GaStoreFactory.getRealmGaStoreManager(this, securityHelper);
    }

    @Override
    public final void onDestroy() {
        super.onDestroy();
        gaStoreManager.close();
    }

    private void vibrate() {
        if (!PreferencesController.getInstance(this).isVibrateEnabled()) return;
        Vibrator v = (Vibrator) this.getSystemService(Context.VIBRATOR_SERVICE);
        if (v == null) return;

        // Vibrate for x milliseconds
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            v.vibrate(VibrationEffect.createOneShot(VIB_DURATION, VibrationEffect.DEFAULT_AMPLITUDE));
        } else {
            //deprecated in API 26
            v.vibrate(VIB_DURATION);
        }
    }

    private Error verifyDevice() {
        int devCode = securityHelper.verifyDevice();
        if (devCode != SecurityHelper.OK) {
            int errorCode;
            switch (devCode) {
                case SecurityHelper.IS_ROOT:
                    errorCode = Error.SECURITY_ROOTED;
                    break;
                case SecurityHelper.DEVICE_NOT_ENCRYPTED:
                    errorCode = Error.SECURITY_NO_SYSTEM_ENCRYPT;
                    break;
                case SecurityHelper.WITHOUT_LOCK:
                    errorCode = Error.SECURITY_NO_LOCK;
                    break;
                default:
                    errorCode = Error.SECURITY_UKN_ERROR;
                    break;
            }
            return ErrorFactory.getFatalError(this, errorCode);
        }
        return null;
    }

    private boolean isEnabled(TripListener listener) {
        boolean enabled = false;

        if (!gaStoreManager.checkGaCard()) {
            CoreController.getLogger().logDebug("GaCardService::isEnabled", "Enabled: " + enabled);
            // No Vibrate
            if (listener != null)
                listener.onFailure(ErrorFactory.getWarnError(this, Error.CARD_LOCKED_NO_DATA));
            return enabled;
        }

        isLocked = PreferencesController.getInstance(this).isLockedCard();
        if (isLocked) {
            CoreController.getLogger().logDebug("GaCardService::isEnabled", "Enabled: " + enabled);
            // No Vibrate
            if (listener != null)
                listener.onFailure(ErrorFactory.getWarnError(this, Error.CARD_LOCKED_MANUALLY));
            return enabled;
        }

        isLocked = !PreferencesController.getInstance(this).isLogged();
        if (isLocked) {
            CoreController.getLogger().logDebug("GaCardService::isEnabled", "Enabled: " + enabled);
            vibrate();
            if (listener != null)
                listener.onFailure(ErrorFactory.getWarnError(this, Error.CARD_LOCKED_NEED_LOGIN));
            return enabled;
        }

        Error notSecureDeviceError = verifyDevice();
        if (notSecureDeviceError != null) {
            CoreController.getLogger().logDebug("GaCardService::isEnabled", "Enabled: " + enabled);
            vibrate();
            if (listener != null)
                listener.onFailure(notSecureDeviceError);
            return enabled;
        }

        boolean maxPendingTransactionsReached = gaStoreManager.checkMaxPendingTransactionsReached();
        if (maxPendingTransactionsReached) {
            CoreController.getLogger().logDebug("GaCardService::isEnabled", "Enabled: " + enabled);
            vibrate();
            SyncController.scheduleSync(this);
            if (listener != null)
                listener.onFailure(ErrorFactory.getWarnError(this, Error.CARD_LOCKED_NEED_SYNC));
            return enabled;
        }

        // Check RechargeProcess scheduleSync if There is PendingRechargeConfirm because can break RechargeProcess
        if (ProcessController.isRpIsRunning()) {
            CoreController.getLogger().logDebug("GaCardService::isEnabled", "Enabled: " + enabled);
            vibrate();
            if (listener != null)
                listener.onFailure(ErrorFactory.getWarnError(this, Error.CARD_LOCKED, new IllegalStateException("Processing recharge.")));
            return enabled;
        }

        boolean pendingRechargeConfirmRequest = gaStoreManager.checkPendingRechargeConfirmRequest();
        if (pendingRechargeConfirmRequest) {
            CoreController.getLogger().logDebug("GaCardService::isEnabled", "Enabled: " + enabled);
            vibrate();
            SyncController.scheduleSync(this);
            if (listener != null)
                listener.onFailure(ErrorFactory.getWarnError(this, Error.CARD_LOCKED_NEED_CONFIRM_RECHARGE));
            return enabled;
        }

        boolean pendingProfileUpdateConfirmRequest = gaStoreManager.checkPendingProfileUpdateConfirmRequest();
        if (pendingProfileUpdateConfirmRequest) {
            CoreController.getLogger().logDebug("GaCardService::isEnabled", "Enabled: " + enabled);
            vibrate();
            SyncController.scheduleSync(this);
            if (listener != null)
                listener.onFailure(ErrorFactory.getWarnError(this, Error.CARD_NEED_CONFIRM_PROFILE_UPDATE));
            return enabled;
        }

//        enabled = !ProcessController.isStIsRunning() &&
        enabled = !ProcessController.isRkIsRunning();
        CoreController.getLogger().logDebug("GaCardService::isEnabled", "Enabled: " + enabled);
        if (!enabled) {
            vibrate();
            if (listener != null)
                listener.onFailure(ErrorFactory.getWarnError(this, Error.CARD_LOCKED));
        }
        return enabled;
    }

    @Override
    public final boolean isEnabled() {
        return isEnabled(CoreController.getTripListener());
    }

    @Override
    public final XmlResourceParser getAidXmlParser(ContextWrapper context) {
        return null;
    }

    @Override
    public NFCFieldStateListener getNFCFieldStateListener() {
        return new NFCFieldStateListener() {
            @Override
            public void onFieldDetected() {
                ProcessController.setCoIsRunning(true);
                TripListener listener = CoreController.getTripListener();
                if (listener != null)
                    listener.onFieldDetected();
            }

            @Override
            public void onFieldLost(int reason) {
                ProcessController.setCoIsRunning(false);
                TripListener listener = CoreController.getTripListener();
                if (listener != null)
                    listener.onFieldLost(reason);
            }
        };
    }

}
