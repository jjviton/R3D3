package com.did.gatransport.ui;

import android.annotation.SuppressLint;
import android.os.Bundle;
import android.os.Handler;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.webkit.JavascriptInterface;
import android.webkit.WebChromeClient;
import android.webkit.WebView;
import android.webkit.WebViewClient;

import com.did.gatransport.R;
import com.did.gatransport.controller.CoreController;

import java.net.URI;

public final class RechargeGatewayWebViewFragment extends Fragment {

    public static final String BUNDLE_URL = "URL";
    public static final String BUNDLE_POST_DATA = "POST_DATA";
    public static final String BUNDLE_URL_OK = "URL_OK";
    public static final String BUNDLE_URL_NOK = "URL_NOK";

    public static RechargeGatewayWebViewFragment create(RechargeActivityController.BadResourcesListener badResourcesListener, MyListener listener) {
        if (badResourcesListener == null) {
            return null;
        }

        RechargeGatewayWebViewFragment fragment = new RechargeGatewayWebViewFragment();
        fragment.setListener(listener);
        fragment.badResourcesListener = badResourcesListener;
        return fragment;
    }

    public interface MyListener {
        void onLoaded();

        void onAccepted();

        void onRejected();

        void onGateWayProblems(Exception e);

        void onFinished();

        void onClosed();
    }

    private MyListener listener;

    private RechargeActivityController.BadResourcesListener badResourcesListener;

    private GatWebView webView;
    private View gateWayCloseButton;

    private String urlOK;
    private String urlKO;

    boolean hasFinished = false;

    public RechargeGatewayWebViewFragment() {
        super();
    }

    public void setListener(MyListener listener) {
        this.listener = listener;
    }

    @Override
    @SuppressLint({"SetJavaScriptEnabled"})
    public View onCreateView(@Nullable LayoutInflater inflater, @Nullable ViewGroup container, Bundle savedInstanceState) {
        View rootView = null;
        try {
            if (inflater != null) {
                rootView = inflater.inflate(R.layout.gatdefault_layout_gateway, container, false);
            }
        } catch (Exception e) {
            CoreController.getLogger().logError("RechargeGatewayWebViewFragment::onCreateView", "Error inflating layout.", e);
        }
        if (rootView == null) {
            if (badResourcesListener != null)
                badResourcesListener.onBadResources();
            return null;
        }

        gateWayCloseButton = rootView.findViewById(R.id.gatdefault_header_cancel_button);
        if (gateWayCloseButton == null) {
            if (badResourcesListener != null)
                badResourcesListener.onBadResources();
            return null;
        }

        View gateWay = rootView.findViewById(R.id.default_gateway_webview);
        if (!(gateWay instanceof GatWebView) || gateWay.getClass() != GatWebView.class) {
            if (badResourcesListener != null)
                badResourcesListener.onBadResources();
            return null;
        }


        if (getArguments() == null) {
            return null;
        }

        String url = getArguments().getString(BUNDLE_URL);
        byte[] postData = getArguments().getByteArray(BUNDLE_POST_DATA);
        urlOK = getArguments().getString(BUNDLE_URL_OK);
        urlKO = getArguments().getString(BUNDLE_URL_NOK);

        gateWayCloseButton.setFocusable(true);
        gateWayCloseButton.setClickable(true);
        gateWayCloseButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (CoreController.getLogger() != null)
                    CoreController.getLogger().logDebug("RechargeGatewayWebViewFragment::onCloseClicked", "Closed");
                hasFinished = true;
                if (webView != null)
                    webView.stopLoading();
                closed();
            }
        });

        webView = (GatWebView) gateWay;
        webView.getSettings().setJavaScriptEnabled(true);
        webView.setWebChromeClient(new WebChromeClient() {
        });
        webView.addJavascriptInterface(new HtmlProcessor(), "HtmlProcessor");
        webView.setWebViewClient(new WebViewClient() {
            @Override
            public void onReceivedError(WebView view, int errorCode, String description, String failingUrl) {
                Exception e = new Exception("Error loading url. Code: " + errorCode + " failingUrl: " + failingUrl + " description: " + description);
                if (CoreController.getLogger() != null)
                    CoreController.getLogger().logError("RechargeGatewayWebViewFragment::onReceivedError", "Exception", e);
                gateWayProblems(e);
            }

            @Override
            public boolean shouldOverrideUrlLoading(WebView view, String url) {
                if (hasFinished)
                    return true;
                if (urlOK != null && !urlOK.isEmpty() && checkURls(urlOK, url)) {
                    hasFinished = true;
                    finished();
                    return true;
                } else if (urlKO != null && !urlKO.isEmpty() && checkURls(urlKO, url)) {
                    hasFinished = true;
                    finished();
                    return true;
                } else {
                    view.loadUrl(url);
                    return false;
                }
            }

            @Override
            public void onPageFinished(WebView view, String url) {
                if (CoreController.getLogger() != null)
                    CoreController.getLogger().logDebug("RechargeGatewayWebViewFragment::onPageFinished", "NewUrl: " + url);

                loaded();
                if (!hasFinished) {
                    processResponse(view);
                }
            }
        });

        webView.postUrl(url, postData);

        return rootView;
    }

    private Handler mHandler = new Handler();

    class HtmlProcessor {
        @JavascriptInterface
        public void processHTML(String html) {
            final int nUrlOK = count(html, urlOK); // No need to clean URL because in HTML they are equals
            final int nUrlKO = count(html, urlKO); // No need to clean URL because in HTML they are equals
            CoreController.getLogger().logDebug("HtmlProcessor::processHTML", "Html contains urlOK: " + nUrlOK + " urlKO: " + nUrlKO + ".So, its ok? " + (nUrlOK > nUrlKO));
//            CoreController.getLogger().log("THIS IS HTML CONTENT: " + html);
            mHandler.post(new Runnable() {
                @Override
                public void run() {
                    if (nUrlOK > nUrlKO) {
                        accepted();
                    } else if (nUrlOK < nUrlKO) {
                        rejected();
                    } // if nUrlOK == nUrlKO then continue
                }
            });
        }
    }

    private String cleanUrl(String url) {
        if (url == null) return "";
        return URI.create(url.replace("\\", "")).normalize().toString();
    }

    private boolean checkURls(String url1, String url2) {
        return cleanUrl(url1).equals(cleanUrl(url2));
    }

    private void processResponse(WebView view) {
        view.loadUrl("javascript:window.HtmlProcessor.processHTML('<html>'+document.getElementsByTagName('html')[0].innerHTML+'</html>');");
    }

    private int count(String s, String c) {
        String[] split = s.split(" ");
        int count = 0;
        for (String sp : split) {
            if (sp.contains(c)) count++;
        }
        return count;
    }

    private void accepted() {
        if (gateWayCloseButton != null) gateWayCloseButton.setVisibility(View.INVISIBLE);
        if (this.listener != null) this.listener.onAccepted();
    }

    private void rejected() {
        if (gateWayCloseButton != null) gateWayCloseButton.setVisibility(View.INVISIBLE);
        if (listener != null) this.listener.onRejected();
    }

    private void gateWayProblems(Exception e) {
        if (this.listener != null) this.listener.onGateWayProblems(e);
    }

    private void finished() {
        if (this.listener != null) this.listener.onFinished();
    }

    private void closed() {
        if (this.listener != null) this.listener.onClosed();
    }

    private void loaded() {
        if (listener != null) listener.onLoaded();
    }
}
