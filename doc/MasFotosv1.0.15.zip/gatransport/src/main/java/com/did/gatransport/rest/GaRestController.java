package com.did.gatransport.rest;

import com.did.gatransport.interfaces.CustomRequestListener;
import com.did.gatransport.interfaces.RequestListener;
import com.did.gatransport.model.ErrorResponse;
import com.did.gatransport.rest.model.TransactionLine;
import com.did.gatransport.rest.model.response.BalanceResponse;
import com.did.gatransport.rest.model.response.BaseResponse;
import com.did.gatransport.rest.model.response.EnrollResponse;
import com.did.gatransport.rest.model.response.FinishEnrollResponse;
import com.did.gatransport.rest.model.response.GenericResponse;
import com.did.gatransport.rest.model.response.LoginResponse;
import com.did.gatransport.rest.model.response.PendingPaymentResponse;
import com.did.gatransport.rest.model.response.ProfileUpdateListResponse;
import com.did.gatransport.rest.model.response.ProfileUpdateResponse;
import com.did.gatransport.rest.model.response.RechargeResponse;
import com.did.gatransport.rest.model.response.TokenCardResponse;

import java.util.List;

public interface GaRestController {
    void performLogin(String userToken, String user, String pwd, RequestListener<LoginResponse> listener);

    void performDNIEnroll(String hwId, String cardType, String profile, String dni, RequestListener<EnrollResponse> listener);

    void performPANEnroll(String hwId, String cardType, String profile, String pan, RequestListener<EnrollResponse> listener);

    void performOtpFinishEnroll(String pwd, String mail, String phone, String hwId, String profile, String profileExpiration, String paySolution, String tokenId, String requestId, String otp, RequestListener<FinishEnrollResponse> listener);

    void performUserFinishEnroll(String pwd, String mail, String phone, String hwId, String cardType, String profile, String profileExpiration, String paySolution, String userId, RequestListener<FinishEnrollResponse> listener);

    void performClientFinishEnroll(String pwd, String mail, String phone, String hwId, String cardType, String profile, String profileExpiration, String paySolution, String clientId, RequestListener<FinishEnrollResponse> listener);

    void confirmEnrollment(String hwId, String pan, String tokenId, String phoneId, RequestListener<BaseResponse> listener);

    void getProfileUpdates(String userToken, String user, String hwId, String pan, String phoneId, String profile, String profileExpiration, String paySolution, String language, RequestListener<ProfileUpdateListResponse> listener);

    void performProfileUpdate(String userToken, String user, String hwId, String pan, String phoneId, String type, String profileTimestamp, String paySolution, String nt, String lastEvent, String structEnvironmentUser, String balance, RequestListener<ProfileUpdateResponse> listener);

    void confirmProfileUpdate(String userToken, String user, String hwId, String pan, String phoneId, String oldProfile, String oldProfileExpiration, String timestamp, String newProfile, String newProfileExpiration, String paySolution, String nt, RequestListener<BaseResponse> listener);

    void performCardRecharge(String userToken, String user, String userId, String phoneId, String hwId, String amount, String bin, String lastDig, String cardType, RequestListener<RechargeResponse> listener);

    void performTokenCardRecharge(String userToken, String user, String userId, String phoneId, String hwId, String amount, String bin, String lastDig, String cardType, String cardId, RequestListener<RechargeResponse> listener);

    void performTokenCardFinishRecharge(String userToken, String user, String userId, String phoneId, String hwId, String amount, String bin, String lastDig, String cardType, String cardId, String refundId, String fee, RequestListener<Void> listener);

    void performPendingRecharge(String userToken, String user, String phoneId, String hwId, String amount, String refKey, String refType, RequestListener<RechargeResponse> listener);

    void getPendingPayments(String userToken, String user, String phoneId, String hwId, String language, RequestListener<PendingPaymentResponse> listener);

    void getCardRechargeBalance(String userToken, String user, String phoneId, String hwId, String amount, String balance, String signature, String nt, String date, String refId, String status, CustomRequestListener<BalanceResponse, ErrorResponse<BalanceResponse>> listener);

    void getTokenCardRechargeBalance(String userToken, String user, String phoneId, String hwId, String amount, String balance, String signature, String nt, String date, String refId, CustomRequestListener<BalanceResponse, ErrorResponse<BalanceResponse>> listener);

    void getPendingRechargeBalance(String userToken, String user, String phoneId, String hwId, String amount, String balance, String signature, String nt, String date, String refId, CustomRequestListener<BalanceResponse, ErrorResponse<BalanceResponse>> listener);

    void getTokenCards(String userToken, String user, String userId, String phoneId, String hwId, RequestListener<TokenCardResponse> listener);

    void sendTransactions(String userToken, String user, String phoneId, String hwId, String signature, List<TransactionLine> transactions, CustomRequestListener<GenericResponse, ErrorResponse<GenericResponse>> listener);

    void manageCard(String userToken, String user, String phoneId, String hwId, String status, String cause, String indicator, String method, RequestListener<BaseResponse> listener);

    void enrollManageCard(String tokenId, String hwId, String pan, String status, String indicator, String method, RequestListener<BaseResponse> listener);

    void enrollManageCard(String tokenId, String hwId, String pan, RequestListener<BaseResponse> listener);

    void registerPushChannel(String userToken, String user, String phoneId, String hwId, String pan, String deviceId, String connector, String osVersion, String appVersion, RequestListener<BaseResponse> listener);

    // TODO ONLY FOR DEBUG
//    void doFakeRecharge(String userToken, String user, String phoneId, String hwId, String nt, String amount, String balance, RequestListener<FakeRechargeResponse> listener);
}
