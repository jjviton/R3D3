package com.did.gatransport.controller;

import android.content.ContextWrapper;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.text.Editable;
import android.text.InputFilter;
import android.text.Spanned;
import android.text.TextUtils;
import android.text.TextWatcher;
import android.widget.EditText;

import com.did.gacard.ecard.util.ByteArray;
import com.did.gacard.services.GaAppletManager;
import com.did.gatransport.R;
import com.did.gatransport.interfaces.CardHostErrorChainRequestListener;
import com.did.gatransport.interfaces.CustomRequestListener;
import com.did.gatransport.interfaces.RequestListener;
import com.did.gatransport.mapper.PendingPaymentMapper;
import com.did.gatransport.mapper.TokenCardPaymentMapper;
import com.did.gatransport.model.CardPayment;
import com.did.gatransport.model.Error;
import com.did.gatransport.model.ErrorResponse;
import com.did.gatransport.model.PendingPayment;
import com.did.gatransport.model.Recharge;
import com.did.gatransport.model.TokenCardPayment;
import com.did.gatransport.model.response.CardRechargeResponse;
import com.did.gatransport.model.response.TokenCardRechargeResponse;
import com.did.gatransport.rest.GaRestController;
import com.did.gatransport.rest.model.response.BalanceResponse;
import com.did.gatransport.rest.model.response.PendingPaymentResponse;
import com.did.gatransport.rest.model.response.RechargeResponse;
import com.did.gatransport.rest.model.response.TokenCardResponse;
import com.did.gatransport.rest.retrofit.request.BalanceRequest;
import com.did.gatransport.services.GaAppletManagerFactory;
import com.did.gatransport.store.GaStoreManager;
import com.did.gatransport.store.model.RechargeConfirmRequest;
import com.did.gatransport.store.model.User;
import com.did.gatransport.store.realm.model.RechargeConfirmRequestRealm;
import com.did.gatransport.store.realm.model.RechargeRealm;
import com.did.gatransport.util.AmountConverter;
import com.did.gatransport.util.ErrorFactory;
import com.did.security.core.SecurityHelper;
import com.google.gson.Gson;

import java.security.InvalidParameterException;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;
import java.util.regex.Pattern;

public final class RechargeController {

    static class DecimalDigitsInputFilter implements InputFilter {
        private final Pattern mPattern;

        private DecimalDigitsInputFilter(int digitsBeforeZero, int digitsAfterZero) {
            mPattern = Pattern.compile("[0-9]{0," + (digitsBeforeZero - 1) + "}+((\\.[0-9]{0," + (digitsAfterZero - 1) + "})?)||(\\.)?");
        }

        @Override
        public CharSequence filter(CharSequence source, int start, int end, Spanned dest,
                                   int dstart, int dend) {
            if (!mPattern.matcher(dest).matches())
                return "";
            return null;
        }

    }

    static class DecimalDigitsTextWatcher implements TextWatcher {
        private final EditText input;
        private final double maxValue;

        private DecimalDigitsTextWatcher(@NonNull EditText input, double maxValue) {
            this.input = input;
            this.maxValue = maxValue;
        }

        @Override
        public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {

        }

        @Override
        public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {

        }

        @Override
        public void afterTextChanged(Editable editable) {
            String text = input.getText().toString();
            if (text.equals(".")) {
                input.setText("0.");
                input.setSelection(input.length());// cursor at the end
            } else if (text.length() > 0 && Double.parseDouble(text.replace(",", ".").trim()) > maxValue) {
                input.setText(Double.toString(maxValue));
                input.setSelection(input.length());// cursor at the end
            }
        }

    }

    static class IntegerTextWatcher implements TextWatcher {
        private final EditText input;

        private IntegerTextWatcher(@NonNull EditText input) {
            this.input = input;
        }

        @Override
        public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {

        }

        @Override
        public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {

        }

        @Override
        public void afterTextChanged(Editable editable) {
            String text = input.getText().toString();
            boolean hasChanged = false;
            if (text.contains(".")) {
                text = text.replace(".", "");
                hasChanged = true;
            }
            if (text.contains("-")) {
                text = text.replace("-", "");
                hasChanged = true;
            }
            if (hasChanged) {
                input.setText(text);
                input.setSelection(input.length());// cursor at the end
            }
        }

    }

    private static RechargeConfirmRequest rechargeConfirmRequest;

    @Deprecated
    private static InputFilter getAmountInputFilter(int digitsBeforeZero, int digitsAfterZero) {
        return new DecimalDigitsInputFilter(digitsBeforeZero, digitsAfterZero);
    }

    @Deprecated
    public static void setupAmountTextInput(@NonNull final EditText input, int digitsBeforeZero, int digitsAfterZero, double maxValue) {
        input.setFilters(new InputFilter[]{getAmountInputFilter(digitsBeforeZero, digitsAfterZero)}); // only two decimals
        input.addTextChangedListener(new DecimalDigitsTextWatcher(input, maxValue));
    }

    @Deprecated
    public static void setupIntegerTextInput(@NonNull final EditText input, int maxLength) {
        input.setFilters(new InputFilter[]{new InputFilter.LengthFilter(maxLength)}); // only two decimals
        input.addTextChangedListener(new IntegerTextWatcher(input));
    }

    public static boolean validateMinAmount(int amount) {
        return amount >= 0;
    }

    public static boolean validatePan(String pan) {
        return pan != null && !pan.trim().isEmpty() && TextUtils.isDigitsOnly(pan);
    }

    public static boolean validatePanLength(String pan) {
        return pan != null && pan.trim().length() >= 12 && pan.trim().length() <= 19;
    }

    public static boolean validateMoth(String month) {
        return month != null && !month.isEmpty() && TextUtils.isDigitsOnly(month) && Integer.valueOf(month) > 0 && Integer.valueOf(month) <= 12;

    }

    public static boolean validateYear(String year) {
        return year != null && !year.isEmpty() && year.length() == 4 && TextUtils.isDigitsOnly(year) && Integer.valueOf(year) >= Calendar.getInstance().get(Calendar.YEAR);

    }

    public static boolean validateCvv(String cvv) {
        return cvv != null && !cvv.trim().isEmpty() && TextUtils.isDigitsOnly(cvv) && Integer.valueOf(cvv) >= 0;
    }

    public static boolean validateCvvLength(String cvv) {
        return cvv != null && cvv.trim().length() == 3;
    }

    public static boolean validateTokenCardId(String id) {
        return id != null && !id.trim().isEmpty();
    }

    public static Bundle bundleForm(String form) {
        Bundle bundle = new Bundle();
        bundle.putString("form", form);
        return bundle;
    }

    public static String unBundleForm(Bundle bundle) {
        return bundle != null ? bundle.getString("form", "") : "";
    }

    private static String wrapForm(@NonNull CardPayment request, @NonNull RechargeResponse response, boolean addPan) {
        String cad = request.getYear().concat(request.getMonth());
        String cvv2 = request.getCvv();
        String form = response.getForm();
        form = form.replace("{<_%VAL_CAD%_>}", cad);
        form = form.replace("{<_%VAL_CVV2%_>}", cvv2);
        if (addPan)
            form = form.replace("{<_%VAL_PAN%_>}", request.getPan());
        return form;
    }

    private static String getYearLastDigits(String year) {
        if (year == null || year.length() < 2) return "";
        return year.substring(year.length() - 2, year.length());
    }

    private static String getBin(String pan) {
        if (pan == null || pan.length() < 6) return "";
        return pan.substring(0, 6);
    }

    private static String getLastDig(String pan) {
        if (pan == null || pan.length() < 4) return "";
        return pan.substring(pan.length() - 4, pan.length());
    }

    private static void finishOK(RequestListener listener) {
        ProcessController.setReIsRunning(false);
        if (listener != null)
            listener.onSuccess(null);
    }

    private static void finishKO(Error error, RequestListener listener) {
        ProcessController.setReIsRunning(false);

        CoreController.getLogger().logDebug("RechargeController:finisKO", "Finishing recharge process due to an Error.");
        CoreController.getLogger().logError("RechargeController:finisKO", error, "Finishing recharge process due to an Error.");

        if (listener != null)
            listener.onFailure(error);
    }

    public static void getPendingPayments(@NonNull final ContextWrapper context, @NonNull final String language, @NonNull final GaStoreManager storeManager, @NonNull final GaRestController restController, @NonNull final SecurityHelper securityHelper, @NonNull final RequestListener<List<PendingPayment>> listener) {
        storeManager.getUser(new RequestListener<User>() {
            @Override
            public void onSuccess(User response) {
                if (response != null) {
                    restController.getPendingPayments(response.getToken(), response.getName(), response.getPhoneId(), securityHelper.getHardwareIdentifier(), language, new CardHostErrorChainRequestListener<>(context, storeManager, restController, securityHelper, new RequestListener<PendingPaymentResponse>() {
                        @Override
                        public void onSuccess(PendingPaymentResponse response) {
                            if (response != null)
                                listener.onSuccess(new PendingPaymentMapper().listRestToUi(response.getPendingPayments()));
                            else
                                listener.onSuccess(new ArrayList<PendingPayment>());
                        }

                        @Override
                        public void onFailure(Error error) {
                            listener.onFailure(error);
                        }
                    }
                    ));
                } else
                    listener.onFailure(ErrorFactory.getWarnError(context, Error.GENERAL_USER_NOT_EXISTS));
            }

            @Override
            public void onFailure(Error error) {
                listener.onFailure(error);
            }
        });
    }

    public static void getTokenCardPayments(@NonNull final ContextWrapper context, @NonNull final GaStoreManager storeManager, @NonNull final GaRestController restController, @NonNull final SecurityHelper securityHelper, @NonNull final RequestListener<List<TokenCardPayment>> listener) {
        storeManager.getUser(new RequestListener<User>() {
            @Override
            public void onSuccess(User response) {
                if (response != null) {
                    // String userToken, String userId, String phoneId, String hwId, RequestListener<TokenCardResponse> listener
                    restController.getTokenCards(response.getToken(), response.getName(), response.getUserId(), response.getPhoneId(), securityHelper.getHardwareIdentifier(), new CardHostErrorChainRequestListener<>(context, storeManager, restController, securityHelper, new RequestListener<TokenCardResponse>() {
                        @Override
                        public void onSuccess(TokenCardResponse response) {
                            if (response != null && response.getTokenCards() != null) {
                                listener.onSuccess(new TokenCardPaymentMapper().restToUiList(response.getTokenCards()));
                            } else {
                                listener.onSuccess(new ArrayList<TokenCardPayment>());
                            }
                        }

                        @Override
                        public void onFailure(Error error) {
                            listener.onFailure(error);
                        }
                    }));
                } else
                    listener.onFailure(ErrorFactory.getWarnError(context, Error.GENERAL_USER_NOT_EXISTS));
            }

            @Override
            public void onFailure(Error error) {
                listener.onFailure(error);
            }
        });
    }

    public static void doLogin(@NonNull final ContextWrapper context, @NonNull final GaStoreManager storeManager, @NonNull final GaRestController restController, @NonNull final SecurityHelper securityHelper, final String pwd, final RequestListener<Void> listener) {
        CoreController.getLogger().logDebug("RechargeController::doLogin", "Login START");
        if (checkIsRunning(context, listener)) return;

        ProcessController.setReIsRunning(true);

        storeManager.getUser(new RequestListener<User>() {
            @Override
            public void onSuccess(User response) {
                if (response != null) {
                    LoginController.login(context, storeManager, restController, response.getName(), pwd, new RequestListener<Void>() {
                        @Override
                        public void onSuccess(Void response) {
                            ProcessController.setReIsRunning(false);
                            CoreController.getLogger().logDebug("RechargeController::doLogin", "Sync START");
                            SyncController.sync(context, storeManager, restController, securityHelper, new RequestListener<Void>() {
                                @Override
                                public void onSuccess(Void response) {
                                    CoreController.getLogger().logDebug("RechargeController::doLogin", "Sync DONE");
                                    CoreController.getLogger().logDebug("RechargeController::doLogin", "Login DONE");
                                    finishOK(listener);
                                }

                                @Override
                                public void onFailure(Error error) {
                                    finishKO(error, listener);
                                }
                            });
                        }

                        @Override
                        public void onFailure(Error error) {
                            finishKO(error, listener);
                        }
                    });
                } else {
                    finishKO(ErrorFactory.getWarnError(context, Error.GENERAL_USER_NOT_EXISTS), listener);
                }
            }

            @Override
            public void onFailure(Error error) {
                finishKO(error, listener);
            }
        });
    }

    public static void doCardRecharge(@NonNull final ContextWrapper context, @NonNull final GaStoreManager storeManager, @NonNull final GaRestController restController, @NonNull final SecurityHelper securityHelper, @NonNull final CardPayment request, final RequestListener<CardRechargeResponse> listener) {
        CoreController.getLogger().logDebug("RechargeController::doCardRecharge", "CardRecharge START");
        if (checkIsRunning(context, listener)) {
            return;
        }

        if (!validateMinAmount(request.getAmount())) {
            finishKO(ErrorFactory.getWarnError(context, Error.GENERAL_INVALID_INPUT, new InvalidParameterException(context.getString(R.string.EXCEPTION_BAD_AMOUNT_MIN))), listener);
            return;
        }

        if (request.getPan() == null || request.getPan().isEmpty()) {
            finishKO(ErrorFactory.getWarnError(context, Error.GENERAL_INVALID_INPUT, new InvalidParameterException(String.format(context.getString(R.string.EXCEPTION_INVALID_INPUT), "pan"))), listener);
            return;
        }
        if (request.getCvv() == null || request.getCvv().isEmpty()) {
            finishKO(ErrorFactory.getWarnError(context, Error.GENERAL_INVALID_INPUT, new InvalidParameterException(String.format(context.getString(R.string.EXCEPTION_INVALID_INPUT), "cvv"))), listener);
            return;
        }
        if (request.getMonth() == null || request.getMonth().isEmpty()) {
            finishKO(ErrorFactory.getWarnError(context, Error.GENERAL_INVALID_INPUT, new InvalidParameterException(String.format(context.getString(R.string.EXCEPTION_INVALID_INPUT), "month"))), listener);
            return;
        }
        if (request.getYear() == null || request.getYear().isEmpty()) {
            finishKO(ErrorFactory.getWarnError(context, Error.GENERAL_INVALID_INPUT, new InvalidParameterException(String.format(context.getString(R.string.EXCEPTION_INVALID_INPUT), "year"))), listener);
            return;
        }

        ProcessController.setReIsRunning(true);

        storeManager.getUser(new RequestListener<User>() {
            @Override
            public void onSuccess(User response) {
                if (response != null) {
                    String user = response.getName();
                    String userId = request.isTokenize() ? response.getUserId() : null;
                    String userToken = response.getToken();
                    String phoneId = response.getPhoneId();
                    String hwId = securityHelper.getHardwareIdentifier();
                    String amount = AmountConverter.getDecimalAmountString(request.getAmount());
                    String bin = getBin(request.getPan());
                    String lastDig = getLastDig(request.getPan());
                    String cardType = response.getCardType();


                    // String userToken, String user, String phoneId, String hwId, String amount, String date, String bin, String lastDig, RequestListener<CardRechargeResponse> listener
                    restController.performCardRecharge(userToken, user, userId, phoneId, hwId, amount, bin, lastDig, cardType, new CardHostErrorChainRequestListener<>(context, storeManager, restController, securityHelper, new RequestListener<RechargeResponse>() {
                        @Override
                        public void onSuccess(RechargeResponse response) {
                            // Set pending confirm
                            rechargeConfirmRequest = new RechargeConfirmRequestRealm();
                            rechargeConfirmRequest.setType(Recharge.CARD);
                            rechargeConfirmRequest.setDate(System.currentTimeMillis());
                            rechargeConfirmRequest.setAmount(request.getAmount());
                            rechargeConfirmRequest.setLastDig(getLastDig(request.getPan()));
                            rechargeConfirmRequest.setRefId(response.getRefundId());
                            rechargeConfirmRequest.setStatus(BalanceRequest.NO_RESPONSE);

                            CardRechargeResponse cardRechargeResponse = new CardRechargeResponse();
                            cardRechargeResponse.setForm(wrapForm(request, response, true));
                            cardRechargeResponse.setFee(AmountConverter.reverseDecimalAmount(response.getFee()));

                            ProcessController.setReIsRunning(false);

                            CoreController.getLogger().logDebug("RechargeController::doCardRecharge", "CardRecharge DONE");

                            if (listener != null)
                                listener.onSuccess(cardRechargeResponse);
                        }

                        @Override
                        public void onFailure(Error error) {
                            finishKO((error), listener);
                        }
                    }));
                } else {
                    finishKO(ErrorFactory.getWarnError(context, Error.GENERAL_USER_NOT_EXISTS), listener);
                }
            }

            @Override
            public void onFailure(Error error) {
                finishKO(error, listener);
            }
        });
    }

    public static void doTokenCardRecharge(@NonNull final ContextWrapper context, @NonNull final GaStoreManager storeManager, @NonNull final GaRestController restController, @NonNull final SecurityHelper securityHelper, @NonNull final TokenCardPayment request, final RequestListener<TokenCardRechargeResponse> listener) {
        CoreController.getLogger().logDebug("RechargeController::doTokenCardRecharge", "TokenCardRecharge START");
        if (checkIsRunning(context, listener)) {
            return;
        }

        if (!validateMinAmount(request.getAmount())) {
            finishKO(ErrorFactory.getWarnError(context, Error.GENERAL_INVALID_INPUT, new InvalidParameterException(context.getString(R.string.EXCEPTION_BAD_AMOUNT_MIN))), listener);
            return;
        }
        if (request.getId() == null || request.getId().isEmpty()) {
            finishKO(ErrorFactory.getWarnError(context, Error.GENERAL_INVALID_INPUT, new InvalidParameterException(String.format(context.getString(R.string.EXCEPTION_INVALID_INPUT), "id"))), listener);
            return;
        }
        if (request.getBin() == null || request.getBin().isEmpty()) {
            finishKO(ErrorFactory.getWarnError(context, Error.GENERAL_INVALID_INPUT, new InvalidParameterException(String.format(context.getString(R.string.EXCEPTION_INVALID_INPUT), "bin"))), listener);
            return;
        }
        if (request.getLast() == null || request.getLast().isEmpty()) {
            finishKO(ErrorFactory.getWarnError(context, Error.GENERAL_INVALID_INPUT, new InvalidParameterException(String.format(context.getString(R.string.EXCEPTION_INVALID_INPUT), "last"))), listener);
            return;
        }

        ProcessController.setReIsRunning(true);

        storeManager.getUser(new RequestListener<User>() {
            @Override
            public void onSuccess(User response) {
                if (response != null) {
                    String user = response.getName();
                    String userId = response.getUserId();
                    String userToken = response.getToken();
                    String phoneId = response.getPhoneId();
                    String hwId = securityHelper.getHardwareIdentifier();
                    String amount = AmountConverter.getDecimalAmountString(request.getAmount());
                    String bin = request.getBin();
                    String lastDig = request.getLast();
                    String cardType = response.getCardType();
                    String cardId = request.getId();

                    // String userToken, String user, String userId, String phoneId, String hwId, String amount, String bin, String lastDig, String cardType, String cardId, String refundId, String fee, RequestListener<RechargeResponse> listener
                    restController.performTokenCardRecharge(userToken, user, userId, phoneId, hwId, amount, bin, lastDig, cardType, cardId, new CardHostErrorChainRequestListener<>(context, storeManager, restController, securityHelper, new RequestListener<RechargeResponse>() {
                        @Override
                        public void onSuccess(RechargeResponse response) {
                            TokenCardRechargeResponse cardRechargeResponse = new TokenCardRechargeResponse();
                            cardRechargeResponse.setPayment(request);
                            cardRechargeResponse.setRefundId(response.getRefundId());
                            cardRechargeResponse.setFee(AmountConverter.reverseDecimalAmount(response.getFee()));

                            ProcessController.setReIsRunning(false);

                            CoreController.getLogger().logDebug("RechargeController::doTokenCardRecharge", "TokenCardRecharge DONE");

                            if (listener != null)
                                listener.onSuccess(cardRechargeResponse);
                        }

                        @Override
                        public void onFailure(Error error) {
                            finishKO((error), listener);
                        }
                    }));
                } else {
                    finishKO(ErrorFactory.getWarnError(context, Error.GENERAL_USER_NOT_EXISTS), listener);
                }
            }

            @Override
            public void onFailure(Error error) {
                finishKO(error, listener);
            }
        });
    }

    public static void doTokenCardFinishRecharge(@NonNull final ContextWrapper context, @NonNull final GaStoreManager storeManager, @NonNull final GaRestController restController, @NonNull final SecurityHelper securityHelper, @NonNull final TokenCardRechargeResponse request, final RequestListener<Void> listener) {
        CoreController.getLogger().logDebug("RechargeController::doTokenCardFinishRecharge", "TokenCardFinishRecharge START");
        if (checkIsRunning(context, listener)) {
            return;
        }

        if (request.getRefundId() == null || request.getRefundId().isEmpty()) {
            finishKO(ErrorFactory.getWarnError(context, Error.GENERAL_INVALID_INPUT, new InvalidParameterException(String.format(context.getString(R.string.EXCEPTION_INVALID_INPUT), "refundId"))), listener);
            return;
        }

        if (request.getPayment() == null) {
            finishKO(ErrorFactory.getWarnError(context, Error.GENERAL_INVALID_INPUT, new InvalidParameterException(String.format(context.getString(R.string.EXCEPTION_INVALID_INPUT), "payment"))), listener);
            return;
        }

        if (!validateMinAmount(request.getPayment().getAmount())) {
            finishKO(ErrorFactory.getWarnError(context, Error.GENERAL_INVALID_INPUT, new InvalidParameterException(context.getString(R.string.EXCEPTION_BAD_AMOUNT_MIN))), listener);
            return;
        }

        if (request.getPayment().getId() == null || request.getPayment().getId().isEmpty()) {
            finishKO(ErrorFactory.getWarnError(context, Error.GENERAL_INVALID_INPUT, new InvalidParameterException(String.format(context.getString(R.string.EXCEPTION_INVALID_INPUT), "id"))), listener);
            return;
        }
        if (request.getPayment().getBin() == null || request.getPayment().getBin().isEmpty()) {
            finishKO(ErrorFactory.getWarnError(context, Error.GENERAL_INVALID_INPUT, new InvalidParameterException(String.format(context.getString(R.string.EXCEPTION_INVALID_INPUT), "bin"))), listener);
            return;
        }
        if (request.getPayment().getLast() == null || request.getPayment().getLast().isEmpty()) {
            finishKO(ErrorFactory.getWarnError(context, Error.GENERAL_INVALID_INPUT, new InvalidParameterException(String.format(context.getString(R.string.EXCEPTION_INVALID_INPUT), "last"))), listener);
            return;
        }


        ProcessController.setReIsRunning(true);


        storeManager.getUser(new RequestListener<User>() {
            @Override
            public void onSuccess(final User user) {
                if (user != null) {
                    // Set pending confirm
                    RechargeConfirmRequest rechargeConfirmRequest = new RechargeConfirmRequestRealm();
                    rechargeConfirmRequest.setType(Recharge.TOKEN_CARD);
                    rechargeConfirmRequest.setDate(System.currentTimeMillis());
                    rechargeConfirmRequest.setAmount(request.getPayment().getAmount());
                    rechargeConfirmRequest.setLastDig(request.getPayment().getLast());
                    rechargeConfirmRequest.setRefId(request.getRefundId());
                    rechargeConfirmRequest.setStatus(BalanceRequest.OK);

                    storeManager.insert(rechargeConfirmRequest, new RequestListener<Void>() {
                        @Override
                        public void onSuccess(Void response) {
                            String userName = user.getName();
                            String userId = user.getUserId();
                            String userToken = user.getToken();
                            String phoneId = user.getPhoneId();
                            String hwId = securityHelper.getHardwareIdentifier();
                            String amount = AmountConverter.getDecimalAmountString(request.getPayment().getAmount());
                            String bin = request.getPayment().getBin();
                            String lastDig = request.getPayment().getLast();
                            String cardType = user.getCardType();
                            String cardId = request.getPayment().getId();
                            String refundId = request.getRefundId();
                            String fee = AmountConverter.getDecimalAmountString(request.getFee());

                            // String userToken, String user, String userId, String phoneId, String hwId, String amount, String bin, String lastDig, String cardType, String cardId, String refundId, String fee, RequestListener<RechargeResponse> listener
                            restController.performTokenCardFinishRecharge(userToken, userName, userId, phoneId, hwId, amount, bin, lastDig, cardType, cardId, refundId, fee, new CardHostErrorChainRequestListener<>(context, storeManager, restController, securityHelper, new RequestListener<Void>() {
                                @Override
                                public void onSuccess(Void response) {
                                    CoreController.getLogger().logDebug("RechargeController::doTokenCardFinishRecharge", "TokenCardFinishRecharge DONE");

                                    finishOK(listener);
                                }

                                @Override
                                public void onFailure(Error error) {
                                    finishKO((error), listener);
                                }
                            }));
                        }

                        @Override
                        public void onFailure(Error error) {
                            finishKO(error, listener);
                        }
                    });
                } else {
                    finishKO(ErrorFactory.getWarnError(context, Error.GENERAL_USER_NOT_EXISTS), listener);
                }
            }

            @Override
            public void onFailure(Error error) {
                finishKO(error, listener);
            }
        });

    }

    public static void doPendingRecharge(@NonNull final ContextWrapper context, @NonNull final GaStoreManager storeManager, @NonNull final GaRestController restController, @NonNull final SecurityHelper securityHelper, final PendingPayment request, final RequestListener<Void> listener) {
        CoreController.getLogger().logDebug("RechargeController::doPendingRecharge", "PendingRechargeConfirm START");
        if (checkIsRunning(context, listener)) return;

        if (request == null) {
            finishKO(ErrorFactory.getWarnError(context, Error.GENERAL_INVALID_INPUT, new InvalidParameterException(String.format(context.getString(R.string.EXCEPTION_INVALID_INPUT), "request"))), listener);
            return;
        }

        ProcessController.setReIsRunning(true);

        storeManager.getUser(new RequestListener<User>() {
            @Override
            public void onSuccess(final User user) {
                if (user != null) {

                    // Generate and save confirmation previous sending request wit refid = null
                    RechargeConfirmRequest rechargeConfirmRequest = new RechargeConfirmRequestRealm();
                    rechargeConfirmRequest.setType(Recharge.PENDING);
                    rechargeConfirmRequest.setDate(System.currentTimeMillis());
                    rechargeConfirmRequest.setAmount(request.getAmount());
                    rechargeConfirmRequest.setLastDig(getLastDig(request.getPan()));
                    rechargeConfirmRequest.setRefId(null);
                    rechargeConfirmRequest.setStatus(BalanceRequest.OK);

                    storeManager.insert(rechargeConfirmRequest, new RequestListener<Void>() {
                        @Override
                        public void onSuccess(Void response) {
                            String userToken = user.getToken();
                            String userName = user.getName();
                            String phoneId = user.getPhoneId();
                            String hwId = securityHelper.getHardwareIdentifier();
                            String amount = AmountConverter.getDecimalAmountString(request.getAmount());
                            String refKey = request.getKey();
                            String refType = request.getType();
                            // (String userToken, String user, String phoneId, String hwId, String amount, String refKey, String refType, RequestListener<RechargeResponse> listener)
                            restController.performPendingRecharge(userToken, userName, phoneId, hwId, amount, refKey, refType, new CardHostErrorChainRequestListener<>(context, storeManager, restController, securityHelper, new RequestListener<RechargeResponse>() {
                                @Override
                                public void onSuccess(RechargeResponse response) {
                                    storeManager.updateRechargeConfirmRequestId(response.getRefundId(), new RequestListener<RechargeConfirmRequest>() {
                                        @Override
                                        public void onSuccess(RechargeConfirmRequest response) {
                                            CoreController.getLogger().logDebug("RechargeController::doPendingRecharge", "confirmRecharge updated with new id and resend");

                                            CoreController.getLogger().logDebug("RechargeController::doPendingRecharge", "PendingRechargeConfirm DONE");

                                            finishOK(listener);
                                        }

                                        @Override
                                        public void onFailure(Error error) {
                                            finishKO(error, listener);
                                        }
                                    });
                                }

                                @Override
                                public void onFailure(Error error) {
                                    finishKO((error), listener);
                                }
                            }));
                        }

                        @Override
                        public void onFailure(Error error) {
                            finishKO(error, listener);
                        }
                    });
                } else {
                    finishKO(ErrorFactory.getWarnError(context, Error.GENERAL_USER_NOT_EXISTS), listener);
                }
            }

            @Override
            public void onFailure(Error error) {
                finishKO(error, listener);
            }
        });
    }

    public static void doCommitRechargeConfirmRequest(final ContextWrapper context, @NonNull final GaStoreManager storeManager, final RequestListener<Void> listener) {
        CoreController.getLogger().logDebug("RechargeController::doCommitRechargeConfirmRequest", "CommitRechargeConfirmRequest START");
        if (checkIsRunning(context, listener)) return;

        if (rechargeConfirmRequest == null) {
            finishKO(ErrorFactory.getWarnError(context, Error.GENERAL_PENDING_RECHARGE_CONFIRM_NOT_EXISTS), listener);
            return;
        }

        ProcessController.setReIsRunning(true);

        storeManager.insert(rechargeConfirmRequest, new RequestListener<Void>() {
            @Override
            public void onSuccess(Void response) {
                rechargeConfirmRequest = null;

                CoreController.getLogger().logDebug("RechargeController::doCommitRechargeConfirmRequest", "CommitRechargeConfirmRequest DONE");

                finishOK(listener);
            }

            @Override
            public void onFailure(Error error) {
                finishKO(error, listener);
            }
        });
    }

    public static void doDiscardRechargeConfirmRequest(final ContextWrapper context, final RequestListener<Void> listener) {
        CoreController.getLogger().logDebug("RechargeController::doDiscardRechargeConfirmRequest", "DiscardRechargeConfirmRequest START");
        if (checkIsRunning(context, listener)) return;

        ProcessController.setReIsRunning(true);

        rechargeConfirmRequest = null;

        CoreController.getLogger().logDebug("RechargeController::doDiscardRechargeConfirmRequest", "DiscardRechargeConfirmRequest DONE");

        finishOK(listener);
    }

    private static boolean checkIsRunning(ContextWrapper context, RequestListener listener) {
        if (ProcessController.isReIsRunning() || ProcessController.isCoIsRunning()) {
            finishKO(ErrorFactory.getWarnError(context, Error.GENERAL_PROCESS_IS_RUNNING), listener);
            return true;
        }
        return false;
    }

    public static void doUpdateConfirmRecharge(@NonNull final ContextWrapper context, @NonNull final GaStoreManager storeManager, @NonNull final GaRestController restController, @NonNull final SecurityHelper securityHelper, final RequestListener<Void> listener, String newStatus) {
        CoreController.getLogger().logDebug("RechargeController::doUpdateConfirmRecharge", "UpdateConfirmRecharge START");
        if (checkIsRunning(context, listener)) return;

        ProcessController.setReIsRunning(true);

        if (newStatus != null) {
            storeManager.updateRechargeConfirmRequest(newStatus, new RequestListener<Void>() {
                @Override
                public void onSuccess(Void response) {
                    CoreController.getLogger().logDebug("RechargeController::doUpdateConfirmRecharge", "UpdateConfirmRecharge END");

                    finishOK(listener);
                }

                @Override
                public void onFailure(Error error) {
                    finishKO(error, listener);
                }
            });
        } else {
            CoreController.getLogger().logDebug("RechargeController::doUpdateConfirmRecharge", "UpdateConfirmRecharge END");
            finishOK(listener);
        }
    }

    public static void doConfirmRecharge(@NonNull final ContextWrapper context, @NonNull final GaStoreManager storeManager, @NonNull final GaRestController restController, @NonNull final SecurityHelper securityHelper, final RequestListener<Void> listener) {
        CoreController.getLogger().logDebug("RechargeController::doConfirmRecharge", "ConfirmRecharge START");
        if (checkIsRunning(context, listener)) return;

        ProcessController.setReIsRunning(true);


        storeManager.getRechargeConfirmRequest(new RequestListener<RechargeConfirmRequest>() {
            @Override
            public void onSuccess(final RechargeConfirmRequest pendingBalance) {
                finishConfirmRecharge(context, pendingBalance, storeManager, restController, securityHelper, listener);
            }

            @Override
            public void onFailure(Error error) {
                finishKO(error, listener);
            }
        });
    }

    private static void finishConfirmRecharge(@NonNull final ContextWrapper context, final RechargeConfirmRequest pendingBalance, @NonNull final GaStoreManager storeManager, @NonNull final GaRestController restController, @NonNull final SecurityHelper securityHelper, final RequestListener<Void> listener) {
        if (pendingBalance == null) {
            finishKO(ErrorFactory.getWarnError(context, Error.GENERAL_PENDING_RECHARGE_CONFIRM_NOT_EXISTS), listener);
            return;
        }

        try {
            final GaAppletManager gaAppletManager = GaAppletManagerFactory.getGaCardManager(context);
            final String balance = AmountConverter.getDecimalAmountString(ByteArray.arrayByteToInt(gaAppletManager.getBalance()));
            final String nt = String.valueOf(ByteArray.arrayByteToInt(gaAppletManager.getNt()));
            storeManager.getUser(new RequestListener<User>() {
                @Override
                public void onSuccess(User response) {
                    if (response == null) {
                        finishKO(ErrorFactory.getWarnError(context, Error.GENERAL_USER_NOT_EXISTS), listener);
                    } else {
                        String userToken = response.getToken();
                        String user = response.getName();
                        String phoneId = response.getPhoneId();
                        String hwId = securityHelper.getHardwareIdentifier();
                        final String amount = AmountConverter.getDecimalAmountString(pendingBalance.getAmount());
                        String date = String.valueOf(pendingBalance.getDate());
                        final String refId = pendingBalance.getRefId();
                        String signature = new Gson().toJson(securityHelper.getSecretBytes(4));
                        String status = pendingBalance.getStatus();

                        CustomRequestListener<BalanceResponse, ErrorResponse<BalanceResponse>> confirmListener = new CustomRequestListener<BalanceResponse, ErrorResponse<BalanceResponse>>() {
                            @Override
                            public void onSuccess(BalanceResponse response) {
                                try {
                                    // Update Card
                                    int newNt = Integer.parseInt(response.getNt());
                                    int newBalance = AmountConverter.reverseDecimalAmount(response.getBalance());
                                    int recharge = pendingBalance.getAmount();

                                    gaAppletManager.rechargeBalance(newNt, newBalance, recharge);

                                    // Update Signature
                                    byte[] signature = response.getSignature();
                                    securityHelper.saveSecret(SecurityHelper.FOUR_BYTES, signature);

                                    // Generate Recharge Store
                                    RechargeRealm rechargeRealm = new RechargeRealm();
                                    rechargeRealm.setAmount(pendingBalance.getAmount());
                                    rechargeRealm.setDate(pendingBalance.getDate());
                                    rechargeRealm.setType(pendingBalance.getType());
                                    rechargeRealm.setCardLastDig(pendingBalance.getLastDig());
                                    storeManager.insert(rechargeRealm, new RequestListener<Void>() {
                                        @Override
                                        public void onSuccess(Void response) {
                                            storeManager.deleteAll(GaStoreManager.TABLE_RECHARGE_CONFIRM, new RequestListener<Void>() {
                                                @Override
                                                public void onSuccess(Void response) {
                                                    CoreController.getLogger().logDebug("RechargeController::finishConfirmRecharge", "rk start!");
                                                    storeManager.refreshKey(new RequestListener<Void>() {
                                                        @Override
                                                        public void onSuccess(Void response) {
                                                            CoreController.getLogger().logDebug("RechargeController::finishConfirmRecharge", "rk ok!");

                                                            CoreController.getLogger().logDebug("RechargeController::finishConfirmRecharge", "ConfirmRecharge DONE");

                                                            finishOK(listener);
                                                        }

                                                        @Override
                                                        public void onFailure(Error error) {
                                                            CoreController.getLogger().logDebug("RechargeController::finishConfirmRecharge", "rk ko!");
                                                            CoreController.getLogger().logError("RechargeController::finishConfirmRecharge", error, "rk ko!");

                                                            CoreController.getLogger().logDebug("RechargeController::finishConfirmRecharge", "ConfirmRecharge DONE");

                                                            finishOK(listener);
                                                        }
                                                    });
                                                }

                                                @Override
                                                public void onFailure(Error error) {
                                                    CoreController.getLogger().logDebug("RechargeController::finishConfirmRecharge", "Can not delete confirmRecharge");
                                                    CoreController.getLogger().logError("RechargeController::finishConfirmRecharge", error, "Can not delete confirmRecharge");
                                                    finishKO(error, listener);
                                                }
                                            });
                                        }

                                        @Override
                                        public void onFailure(Error error) {
                                            finishKO(error, listener);
                                        }
                                    });
                                } catch (Exception e) {
                                    finishKO(ErrorFactory.getFatalError(context, Error.GENERAL_UNEXPECTED_EXCEPTION, e), listener);
                                }
                            }

                            @Override
                            public void onFailure(final ErrorResponse<BalanceResponse> error) {
                                CoreController.getLogger().logDebug("RechargeController::finishConfirmRecharge", "Error: " + (new Gson().toJson(error)));

                                if (ErrorFactory.isCardLockedUnsubscribedError(error)) {
                                    SyncController.sync(context, storeManager, restController, securityHelper, new RequestListener<Void>() {
                                        @Override
                                        public void onSuccess(Void response) {
                                            finishKO(error, listener);
                                        }

                                        @Override
                                        public void onFailure(Error error) {
                                            finishKO(error, listener);
                                        }
                                    }, error.getError());
                                } else if (ErrorFactory.isBadRefundIdError(error)
                                        && refId == null) {
                                    // Re confirm with newRefId
                                    final Error errorRetry = ErrorFactory.getWarnError(context, Error.RECHARGE_CANNOT_CONFIRM);
                                    String newRefId = error.getResponse().getLastRefundId();
                                    storeManager.updateRechargeConfirmRequestId(newRefId, new RequestListener<RechargeConfirmRequest>() {
                                        @Override
                                        public void onSuccess(RechargeConfirmRequest response) {
                                            CoreController.getLogger().logDebug("RechargeController::finishConfirmRecharge", "confirmRecharge updated with new id and resend");
                                            finishConfirmRecharge(context, pendingBalance, storeManager, restController, securityHelper, listener);
                                        }

                                        @Override
                                        public void onFailure(Error error2) {
                                            errorRetry.setPreviousError(error2);
                                            error2.setPreviousError(error.getError());
                                            CoreController.getLogger().logDebug("RechargeController::finishConfirmRecharge", "Can not update confirmRecharge with new id");
                                            CoreController.getLogger().logError("RechargeController::finishConfirmRecharge", error2, "Can not update confirmRecharge with new id");

                                            finishKO(errorRetry, listener);
                                        }
                                    });
                                } else if (ErrorFactory.isBadRefundIdError(error)
                                        && !error.getResponse().getLastRefundId().equalsIgnoreCase(refId)) {
                                    final Error errorRejected = ErrorFactory.getWarnError(context, Error.RECHARGE_REJECTED);
                                    // Operation rejected, not same refId
                                    errorRejected.setPreviousError(error.getError());
                                    storeManager.deleteAll(GaStoreManager.TABLE_RECHARGE_CONFIRM, new RequestListener<Void>() {
                                        @Override
                                        public void onSuccess(Void response) {
                                            CoreController.getLogger().logDebug("RechargeController::finishConfirmRecharge", "rk start!");
                                            storeManager.refreshKey(new RequestListener<Void>() {
                                                @Override
                                                public void onSuccess(Void response) {
                                                    CoreController.getLogger().logDebug("RechargeController::finishConfirmRecharge", "rk ok!");

                                                    finishKO(errorRejected, listener);
                                                }

                                                @Override
                                                public void onFailure(Error error2) {
                                                    CoreController.getLogger().logDebug("RechargeController::finishConfirmRecharge", "rk ko!");
                                                    CoreController.getLogger().logError("RechargeController::finishConfirmRecharge", error2, "rk ko!");

                                                    finishKO(errorRejected, listener);
                                                }
                                            });
                                        }

                                        @Override
                                        public void onFailure(Error error2) {
                                            CoreController.getLogger().logDebug("RechargeController::finishConfirmRecharge", "Can not delete confirmRecharge");
                                            CoreController.getLogger().logError("RechargeController::finishConfirmRecharge", error2, "Can not delete confirmRecharge");

                                            finishKO(errorRejected, listener);
                                        }
                                    });
                                } else {
                                    Error errorCannotConfirm = ErrorFactory.getWarnError(context, Error.RECHARGE_CANNOT_CONFIRM);
                                    if (error != null)
                                        errorCannotConfirm.setPreviousError(error.getError());
                                    finishKO(errorCannotConfirm, listener);
                                }
                            }
                        };

                        switch (pendingBalance.getType()) {
                            case Recharge.CARD:
                            default:
                                // String userToken, String user, String phoneId, String hwId, String amount, String balance, String signature, String nt, String date, String refId, String status, RequestListener<BalanceResponse> listener
                                restController.getCardRechargeBalance(userToken, user, phoneId, hwId, amount, balance, signature, nt, date, refId, status, confirmListener);
                                break;
                            case Recharge.PENDING:
                                // String userToken, String user, String phoneId, String hwId, String amount, String balance, String signature, String nt, String date, String refId, RequestListener<BalanceResponse> listener
                                restController.getPendingRechargeBalance(userToken, user, phoneId, hwId, amount, balance, signature, nt, date, refId, confirmListener);
                                break;
                            case Recharge.TOKEN_CARD:
                                // String userToken, String user, String phoneId, String hwId, String amount, String balance, String signature, String nt, String date, String refId, RequestListener<BalanceResponse> listener
                                restController.getTokenCardRechargeBalance(userToken, user, phoneId, hwId, amount, balance, signature, nt, date, refId, confirmListener);
                                break;
                        }
                    }
                }

                @Override
                public void onFailure(Error error) {
                    finishKO(error, listener);
                }
            });
        } catch (Exception e) {
            finishKO(ErrorFactory.getFatalError(context, Error.GENERAL_UNEXPECTED_EXCEPTION, e), listener);
        }
    }

}