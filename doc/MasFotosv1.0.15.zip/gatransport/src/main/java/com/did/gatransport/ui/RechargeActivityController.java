package com.did.gatransport.ui;

import com.did.gatransport.model.Error;

public interface RechargeActivityController {
    interface RechargeActivityControllerListener {
        void onFinishOK();

        void onFinishKO(Error error);
    }

    interface BadResourcesListener {
        void onBadResources();
    }

    void startProcess();

    boolean isFinishedOK();

    Error getConfirmRechargeError();

    void destroy();
}
