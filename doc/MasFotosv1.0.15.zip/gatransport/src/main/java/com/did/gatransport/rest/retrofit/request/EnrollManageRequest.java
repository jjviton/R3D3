package com.did.gatransport.rest.retrofit.request;

import com.google.gson.annotations.SerializedName;

public class EnrollManageRequest {

    // Status
    public static final String STATUS_LOCK = "01";
    public static final String STATUS_UNSUBSCRIBE = "03";

    // Indicator
    public static final String INDICATOR_MONEDERO = "01";
    public static final String INDICATOR_FINANCIERA = "02";
    public static final String INDICATOR_IBAN = "03";

    @SerializedName("Token_ID")
    private String tokenId;
    @SerializedName("HW_ID")
    private String hwId;
    @SerializedName("PAN")
    private String pan;
    @SerializedName("Status")
    private String status;
    @SerializedName("Indicator")
    private String indicator;
    @SerializedName("Method")
    private String method;

    public EnrollManageRequest() {
    }

    public String getTokenId() {
        return tokenId;
    }

    public void setTokenId(String tokenId) {
        this.tokenId = tokenId;
    }

    public String getHwId() {
        return hwId;
    }

    public void setHwId(String hwId) {
        this.hwId = hwId;
    }

    public String getPan() {
        return pan;
    }

    public void setPan(String pan) {
        this.pan = pan;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getIndicator() {
        return indicator;
    }

    public void setIndicator(String indicator) {
        this.indicator = indicator;
    }

    public String getMethod() {
        return method;
    }

    public void setMethod(String method) {
        this.method = method;
    }
}
