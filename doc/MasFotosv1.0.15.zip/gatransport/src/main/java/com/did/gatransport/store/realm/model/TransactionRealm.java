package com.did.gatransport.store.realm.model;

import android.support.annotation.IntRange;

import com.did.gatransport.store.model.Transaction;

import java.security.InvalidParameterException;

import io.realm.RealmObject;

public class TransactionRealm extends RealmObject implements Transaction {

    private int balance;
    private int amount;
    private long date;
    private int state;
    private int nt;
    private String type;

    public TransactionRealm() {
    }

    @Override
    public void setBalance(int balance) {
        this.balance = balance;
    }

    @Override
    public int getBalance() {
        return this.balance;
    }

    @Override
    public void setDate(long date) {
        this.date = date;
    }

    @Override
    public long getDate() {
        return this.date;
    }

    @Override
    public void setState(@IntRange(from = STATE_PENDING, to = STATE_SENT) int state) {
        if (state < STATE_PENDING || state > STATE_SENT)
            throw new InvalidParameterException();
        this.state = state;
    }

    @Override
    public int getState() {
        return this.state;
    }

    @Override
    public void setNt(int nt) {
        this.nt = nt;
    }

    @Override
    public int getNt() {
        return this.nt;
    }

    @Override
    public int getAmount() {
        return amount;
    }

    @Override
    public void setAmount(int amount) {
        this.amount = amount;
    }

    @Override
    public String getType() {
        return type;
    }

    @Override
    public void setType(String type) {
        this.type = type;
    }
}
