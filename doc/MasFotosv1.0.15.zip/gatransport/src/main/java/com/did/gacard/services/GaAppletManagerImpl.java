package com.did.gacard.services;

import com.did.gacard.GaCard;
import com.did.gacard.core.files.GaAppFileManager;
import com.did.gacard.core.files.model.StructUser;
import com.did.gacard.ecard.util.ByteArray;
import com.did.gacard.util.GaCardException;

public abstract class GaAppletManagerImpl implements GaAppletManager {

    @Override
    public final byte[] getNt() throws GaCardException {
        return new GaAppFileManager(this).getNt();
    }

    @Override
    public final byte[] getBalance() throws GaCardException {
        return new GaAppFileManager(this).getContract(1).getCounterContract();
    }

    private StructUser getStructUser(GaAppFileManager gaAppFileManager) {
        try {
            return new StructUser(gaAppFileManager.getStructUser());
        } catch (Exception e) {
            GaCard.getInstance().getLogger().logError("GaAppletManagerImpl::getStructUser", "Bad StructUser", e);
        }
        return null;
    }

    @Override
    public final byte getGroupCode() throws GaCardException {
        StructUser structUser = getStructUser(new GaAppFileManager(this));
        if (structUser == null) return (byte) 0x00;
        return structUser.getGroupCode();
    }

    @Override
    public byte[] getProfileInitialization() throws GaCardException {
        StructUser structUser = getStructUser(new GaAppFileManager(this));
        if (structUser == null) return new byte[0];
        return structUser.getProfileInitialization();
    }

    @Override
    public byte[] getProfileExpiration() throws GaCardException {
        StructUser structUser = getStructUser(new GaAppFileManager(this));
        if (structUser == null) return new byte[0];
        return structUser.getProfileExpiration();
    }

    @Override
    public byte[] getGenData() throws GaCardException {
        GaAppFileManager gaAppFileManager = new GaAppFileManager(this);
        byte[] structEnvironment = gaAppFileManager.getStructEnvironment();
        byte[] structUser = gaAppFileManager.getStructUser();
        return ByteArray.merge(structEnvironment, structUser);
    }

    @Override
    public final byte[] getLastEvent() throws GaCardException {
        return new GaAppFileManager(this).getLastEventBytesNoBitRatificationNoRfu();
    }

    @Override
    public final void rechargeBalance(int newNt, int newBalance, int recharge) throws GaCardException {
        GaAppFileManager fileManager = new GaAppFileManager(this);
        if (ByteArray.toIntArrayByte(newNt).length > 2) throw new GaCardException("NT overflow.");
        if (ByteArray.toIntArrayByte(newBalance).length > 3)
            throw new GaCardException("CounterContract overflow.");
        if (ByteArray.toIntArrayByte(recharge).length > 2)
            throw new GaCardException("RechargeValue overflow.");
        if (fileManager.setNt(ByteArray.toIntArrayByte(newNt)).updateContract(1, ByteArray.toIntArrayByte(newNt), ByteArray.toIntArrayByte(newBalance), ByteArray.toIntArrayByte(recharge)) != null)
            fileManager.commit();
        else
            throw new GaCardException("Recharging Problem.");
    }

    @Override
    public final void updateProfileUser(String newStructEnvironmentUser, String newEvent) throws GaCardException {
        GaAppFileManager fileManager = new GaAppFileManager(this);
        if (newStructEnvironmentUser.length() != (21 * 2))
            throw new GaCardException("StructEnvironmentUser bad length.");
        if (newEvent.length() != (32 * 2) && newEvent.length() != (30 * 2) && newEvent.length() != (29 * 2))
            throw new GaCardException("Event bad length.");
        if (fileManager.incrementNt().updateGenDataWithEvent(ByteArray.hexStringToByteArray(newStructEnvironmentUser.substring(0, 18)), ByteArray.hexStringToByteArray(newStructEnvironmentUser.substring(18, newStructEnvironmentUser.length())), ByteArray.hexStringToByteArray(newEvent)) != null)
            fileManager.commit();
        else
            throw new GaCardException("Updating Profile Problem");
    }

    // TODO ONLY FOR DEBUG
//    @Override
//    public void resetState() throws GaCardException {
//        if (!BuildConfig.DEBUG)
//            throw new GaCardException("NO no no...");
//        GaAppFileManager fileManager = new GaAppFileManager(this);
//        if (fileManager.resetState() != null)
//            fileManager.commit();
//        else
//            throw new GaCardException("Reset State Problem");
//    }
}
