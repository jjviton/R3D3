package com.did.gacard.util;

public interface Logger {

    void setLevel(int level);

    int getLevel();

    void logDebug(String log);

    void logError(String log, Throwable tr);

    void logDebug(String classFunction, String log);

    void logError(String classFunction, String log, Throwable tr);
}
