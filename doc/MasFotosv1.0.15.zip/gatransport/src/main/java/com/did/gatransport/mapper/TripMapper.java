package com.did.gatransport.mapper;

import com.did.gatransport.model.Trip;
import com.did.gatransport.store.realm.model.TripRealm;

import java.util.ArrayList;
import java.util.List;

public final class TripMapper extends Mapper<Trip, TripRealm, Void> {

    @Override
    public Trip storeToUi(TripRealm obj) {
        Trip trip = new Trip();

        trip.setTime(obj.getDate());
        trip.setLine(obj.getLine());
        trip.setAmount(obj.getAmount());
        trip.setType(obj.getType());

        return trip;
    }


    public List<Trip> listStoreToUi(List<TripRealm> tripRealmList) {
        List<Trip> trips = new ArrayList<>();
        if (tripRealmList != null) {
            for (TripRealm tripRealm : tripRealmList) {
                trips.add(storeToUi(tripRealm));
            }
        }

        return trips;
    }
}
