package com.did.gatransport.rest.model.response;

import com.google.gson.annotations.SerializedName;

import java.util.Map;

public final class RechargeResponse extends BaseResponse {
    private transient static final String KEY_REFUNDID = "Refund_id";
    private transient static final String KEY_FORM = "Form";
    private transient static final String KEY_FEE = "Fee";

    @SerializedName(KEY_REFUNDID)
    private String refundId;

    @SerializedName(KEY_FORM)
    private String form;

    @SerializedName(KEY_FEE)
    private String fee;

    public RechargeResponse() {
    }

    public RechargeResponse(Map<String, String> map) {
        super(map);
        if (map != null) {
            this.refundId = map.get(KEY_REFUNDID);
            this.form = map.get(KEY_FORM);
            this.fee = map.get(KEY_FEE);
        }
    }

    public String getRefundId() {
        return refundId;
    }

    public void setRefundId(String refundId) {
        this.refundId = refundId;
    }

    public String getForm() {
        return form;
    }

    public void setForm(String form) {
        this.form = form;
    }

    public String getFee() {
        return fee;
    }

    public void setFee(String fee) {
        this.fee = fee;
    }

    public static String[] getKeys() {
        String[] parentKeys = BaseResponse.getKeys();
        String[] childKeys = new String[]{KEY_REFUNDID, KEY_FORM, KEY_FEE};
        String[] keys = new String[parentKeys.length + childKeys.length];
        System.arraycopy(parentKeys, 0, keys, 0, parentKeys.length);
        System.arraycopy(childKeys, 0, keys, parentKeys.length, childKeys.length);
        return keys;
    }
}
