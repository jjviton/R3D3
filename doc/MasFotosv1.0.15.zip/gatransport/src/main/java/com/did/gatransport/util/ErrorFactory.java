package com.did.gatransport.util;

import android.content.ContextWrapper;

import com.did.gatransport.R;
import com.did.gatransport.model.Error;
import com.did.gatransport.model.ErrorResponse;
import com.did.gatransport.rest.model.response.BalanceResponse;
import com.did.gatransport.rest.model.response.BaseResponse;

import java.security.InvalidParameterException;

import okhttp3.ResponseBody;

public final class ErrorFactory {

    public static boolean isHTTPError(Error error) {
        return error != null && error.getCode() < Error.BASE;
    }

    private static int parseHTTPErrorCode(int httpErrorCode) {
        return httpErrorCode;
    }

    private static int parseBaseErrorCode(int errorCode) {
        return errorCode < Error.BASE ? Error.BASE + errorCode : errorCode;
    }

    private static int deparseBaseErrorCode(int errorCode) {
        return errorCode < Error.BASE ? errorCode : errorCode - Error.BASE;
    }

    public static boolean checkBaseErrorCode(int errorCode, int baseErrorCode) {
        return errorCode == parseBaseErrorCode(baseErrorCode);
    }

    private static boolean checkErrorStatus(Error error, String status) {
        return error != null && checkBaseErrorCode(error.getCode(), Error.REST_RESPONSE) && error.getMsg() != null && error.getMsg().length() >= status.length() && error.getMsg().substring(0, status.length()).equalsIgnoreCase(status);
    }

    private static boolean checkErrorStatusCode(Error error, String statusCode) {
        return error != null && checkBaseErrorCode(error.getCode(), Error.REST_RESPONSE) && error.getMsg() != null && error.getMsg().length() >= statusCode.length() && error.getMsg().substring(0, statusCode.length()).equalsIgnoreCase(statusCode);
    }

    public static boolean isCardLockedUnsubscribedError(Error error) {
        return checkErrorStatusCode(error, "0004:0212") || checkErrorStatusCode(error, "0004:0213")
                || (error != null && checkBaseErrorCode(error.getCode(), Error.GENERAL_CARD_LOCKED_BY_HOST))
                || (error != null && checkBaseErrorCode(error.getCode(), Error.GENERAL_CARD_UNSUBSCRIBED_BY_HOST));
    }

    public static boolean isBadRefundIdError(ErrorResponse<BalanceResponse> error) {
        return error != null && error.getResponse() != null
                && error.getResponse().getLastRefundId() != null
                && !error.getResponse().getLastRefundId().isEmpty();
    }

    public static boolean isRechargeCannotConfirmError(Error error) {
        return error != null && ErrorFactory.checkBaseErrorCode(error.getCode(), Error.RECHARGE_CANNOT_CONFIRM);
    }

    public static Error getCardLockedUnsubscribedError(ContextWrapper context, Error prevError) {
        Error error = prevError;
        if (checkErrorStatusCode(prevError, "0004:0212")) {
            error = getWarnError(context, Error.GENERAL_CARD_LOCKED_BY_HOST);
            error.setPreviousError(prevError);
        } else if (checkErrorStatusCode(prevError, "0004:0213")) {
            error = getWarnError(context, Error.GENERAL_CARD_UNSUBSCRIBED_BY_HOST);
            error.setPreviousError(prevError);
        }
        return error;
    }

    private static String getErrorMessage(ContextWrapper context, int errorCode) {
        if (context != null) {
            switch (errorCode) {
                case Error.GENERAL_NEED_INITIALIZE:
                    return context.getString(R.string.GENERAL_NEED_INITIALIZE);
                case Error.GENERAL_INVALID_CONTEXT:
                    return context.getString(R.string.GENERAL_INVALID_CONTEXT);
                case Error.GENERAL_NO_PERMISSIONS_GRANTED:
                    return context.getString(R.string.GENERAL_NO_PERMISSIONS_GRANTED);
                case Error.GENERAL_USER_NOT_EXISTS:
                    return context.getString(R.string.GENERAL_USER_NOT_EXISTS);
                case Error.GENERAL_INVALID_USER:
                    return context.getString(R.string.GENERAL_INVALID_USER);
                case Error.GENERAL_INVALID_INPUT:
                    return context.getString(R.string.GENERAL_INVALID_INPUT);
                case Error.GENERAL_PROCESS_IS_RUNNING:
                    return context.getString(R.string.GENERAL_PROCESS_IS_RUNNING);
                case Error.GENERAL_CARD_LOCKED_BY_HOST:
                    return context.getString(R.string.GENERAL_CARD_LOCKED_BY_HOST);
                case Error.GENERAL_CARD_UNSUBSCRIBED_BY_HOST:
                    return context.getString(R.string.GENERAL_CARD_UNSUBSCRIBED_BY_HOST);
                case Error.GENERAL_UNEXPECTED_EXCEPTION:
                    return context.getString(R.string.GENERAL_UNEXPECTED_EXCEPTION);
                case Error.GENERAL_INVALID_RESOURCES:
                    return context.getString(R.string.GENERAL_INVALID_RESOURCES);
                case Error.GENERAL_PENDING_RECHARGE_CONFIRM_NOT_EXISTS:
                    return context.getString(R.string.GENERAL_PENDING_RECHARGE_CONFIRM_NOT_EXISTS);


                case Error.SECURITY_UKN_ERROR:
                    return context.getString(R.string.SECURITY_UKN_ERROR);
                case Error.SECURITY_ROOTED:
                    return context.getString(R.string.SECURITY_ROOTED);
                case Error.SECURITY_NO_SYSTEM_ENCRYPT:
                    return context.getString(R.string.SECURITY_NO_SYSTEM_ENCRYPT);
                case Error.SECURITY_NO_LOCK:
                    return context.getString(R.string.SECURITY_NO_LOCK);
                case Error.SECURITY_NO_HW_ID:
                    return context.getString(R.string.SECURITY_NO_HW_ID);
                case Error.SECURITY_BAD_DATE:
                    return context.getString(R.string.SECURITY_BAD_DATE);

                case Error.ENROLL_USER_ENROLLED:
                    return context.getString(R.string.ENROLL_USER_ENROLLED);
                case Error.ENROLL_NO_DNI_PAN_ENROLLMENT:
                    return context.getString(R.string.ENROLL_NO_DNI_PAN_ENROLLMENT);
                case Error.ENROLL_BAD_RESPONSE_1:
                    return context.getString(R.string.ENROLL_BAD_RESPONSE_1);
                case Error.ENROLL_BAD_RESPONSE_2:
                    return context.getString(R.string.ENROLL_BAD_RESPONSE_2);
                case Error.ENROLL_USER_HAS_OLD_CARD:
                    return context.getString(R.string.ENROLL_USER_HAS_OLD_CARD);
                case Error.ENROLL_CANNOT_UPDATE_PROFILE:
                    return context.getString(R.string.ENROLL_CANNOT_UPDATE_PROFILE);

                case Error.RECHARGE_INACTIVE:
                    return context.getString(R.string.RECHARGE_INACTIVE);
                case Error.RECHARGE_REJECTED:
                    return context.getString(R.string.RECHARGE_REJECTED);
                case Error.RECHARGE_CANCELED:
                    return context.getString(R.string.RECHARGE_CANCELED);
                case Error.RECHARGE_BAD_GATEWAY_FORM:
                    return context.getString(R.string.RECHARGE_BAD_GATEWAY_FORM);
                case Error.RECHARGE_GATEWAY_PROBLEMS:
                    return context.getString(R.string.RECHARGE_GATEWAY_PROBLEMS);
                case Error.RECHARGE_CANNOT_CONFIRM:
                    return context.getString(R.string.RECHARGE_CANNOT_CONFIRM);

                case Error.CARD_LOCKED:
                    return context.getString(R.string.CARD_LOCKED);
                case Error.CARD_LOCKED_NEED_SYNC:
                    return context.getString(R.string.CARD_LOCKED_NEED_SYNC);
                case Error.CARD_LOCKED_MANUALLY:
                    return context.getString(R.string.CARD_LOCKED_MANUALLY);
                case Error.CARD_LOCKED_NEED_LOGIN:
                    return context.getString(R.string.CARD_LOCKED_NEED_LOGIN);
                case Error.CARD_LOCKED_NEED_CONFIRM_RECHARGE:
                    return context.getString(R.string.CARD_LOCKED_NEED_CONFIRM_RECHARGE);
                case Error.CARD_NEED_CONFIRM_PROFILE_UPDATE:
                    return context.getString(R.string.CARD_NEED_CONFIRM_PROFILE_UPDATE);
                case Error.CARD_LOCKED_NO_DATA:
                    return context.getString(R.string.CARD_LOCKED_NO_DATA);

                case Error.STORE_NOT_SECURE:
                    return context.getString(R.string.STORE_NOT_SECURE);
                case Error.STORE_ERROR_INSERTING_TRANSACTION:
                    return context.getString(R.string.STORE_ERROR_INSERTING_TRANSACTION);
                case Error.STORE_REFRESHING_KEYS:
                    return context.getString(R.string.STORE_ERROR_REFRESHING_KEYS);
                case Error.STORE_NOT_VALID_TABLE:
                    return context.getString(R.string.STORE_NOT_VALID_TABLE);
                case Error.STORE_BAD_MIGRATION:
                    return context.getString(R.string.STORE_BAD_MIGRATION);
                case Error.STORE_CANNOT_OPEN:
                    return context.getString(R.string.STORE_CANNOT_OPEN);


                default:
                    return "Unknown";
            }
        }

        return "";
    }

    private static Error geError(ContextWrapper context, int level, int errorCode, Throwable t) {
        Error error = new Error();
        error.setLevel(Error.LEVEL_WARN);
        error.setCode(parseBaseErrorCode(errorCode));
        error.setMsg(getErrorMessage(context, errorCode));
        error.setTime(System.currentTimeMillis());
        error.setException(t);
        return error;
    }

    public static Error getNonFatalError(ContextWrapper context, int errorCode, Throwable t) {
        return geError(context, Error.LEVEL_NON_FATAL, errorCode, t);
    }

    public static Error getNonFatalError(ContextWrapper context, int errorCode) {
        return getNonFatalError(context, errorCode, null);
    }

    public static Error getWarnError(ContextWrapper context, int errorCode, Throwable t) {
        return geError(context, Error.LEVEL_WARN, errorCode, t);
    }

    public static Error getWarnError(ContextWrapper context, int errorCode) {
        return getWarnError(context, errorCode, null);
    }

    public static Error getHttpError(ContextWrapper context, int errorCode, Throwable t) {
        return geError(context, Error.LEVEL_HTTP, errorCode, t);
    }

    public static Error getHttpError(ContextWrapper context, int errorCode) {
        return getHttpError(context, errorCode, null);
    }

    public static Error getFatalError(ContextWrapper context, int errorCode, Throwable t) {
        return geError(context, Error.LEVEL_FATAL, errorCode, t);
    }

    public static Error getFatalError(ContextWrapper context, int errorCode) {
        return getFatalError(context, errorCode, null);
    }

    public static Error getGeneralContextError() {
        return new Error(Error.LEVEL_FATAL, parseBaseErrorCode(Error.GENERAL_INVALID_CONTEXT), "Contexto no puede ser nulo.", new InvalidParameterException("Context can't be NULL"), System.currentTimeMillis());
    }

    public static Error getStoreBadMigration(String msg, Throwable t) {
        return new Error(Error.LEVEL_FATAL, parseBaseErrorCode(Error.STORE_BAD_MIGRATION), msg, t, System.currentTimeMillis());
    }

    public static Error getRestThrowableError(Throwable t) {
        Error error = new Error();
        error.setLevel(Error.LEVEL_FATAL);
        error.setCode(parseBaseErrorCode(Error.REST_THROWABLE));
        error.setException(t);
        error.setTime(System.currentTimeMillis());
        return error;
    }

    public static Error getRestConnectionError(Throwable t) {
        Error error = new Error();
        error.setLevel(Error.LEVEL_WARN);
        error.setCode(parseBaseErrorCode(Error.REST_CONNECTION));
        error.setException(t);
        error.setTime(System.currentTimeMillis());
        return error;
    }

    public static Error getRestSessionError(int httpErrorCode) {
        Error error = new Error();
        error.setLevel(Error.LEVEL_HTTP);
        error.setCode(parseHTTPErrorCode(httpErrorCode));
        error.setMsg("Bad data or Expired session.");
        error.setTime(System.currentTimeMillis());
        return error;
    }

    public static Error getRestResponseError(Object response, Exception e) {
        Error error = new Error();
        error.setLevel(Error.LEVEL_FATAL);
        error.setCode(parseBaseErrorCode(Error.REST_RESPONSE));
        if (response == null) {
            error.setMsg("Malformed body. No body.");
        } else if (response instanceof BaseResponse) {
            BaseResponse baseResponse = (BaseResponse) response;
            if (baseResponse != null) {
                String status = baseResponse.getStatus() == null ? "UKN" : baseResponse.getStatus();
                String msg = baseResponse.getError() == null ? "UKN" : baseResponse.getError();
                error.setMsg(status + ":" + msg);
            } else {
                error.setMsg("No body.");
            }
        } else if (response instanceof ResponseBody) {
            ResponseBody responseBody = (ResponseBody) response;
            String body = "";
            //noinspection CatchMayIgnoreException
            try {
                body = responseBody.string();
            } catch (Exception ex) {
            }
            if (!body.isEmpty()) {
                error.setMsg("Malformed body: " + body);
            } else {
                error.setMsg("Malformed body. No body.");
            }
        } else {
            error.setMsg("Malformed body: " + response.toString());
        }
        error.setException(e);
        error.setTime(System.currentTimeMillis());
        return error;
    }

    public static Error getRestServerError(int httpErrorCode, String msg) {
        Error error = new Error();
        error.setLevel(Error.LEVEL_HTTP);
        error.setCode(parseHTTPErrorCode(httpErrorCode));
        error.setMsg(msg);
        error.setTime(System.currentTimeMillis());
        return error;
    }
}
