package com.did.gacard;

import android.support.annotation.IntRange;
import android.util.Log;

import com.did.gacard.util.Logger;

import java.security.InvalidParameterException;

public final class GaCard {

    public static final int NONE = 0;
    public static final int FULL = 1;

    private final static Logger DEFAULT = new Logger() {
        private static final String TAG = "GaCard";

        private int level = BuildConfig.DEBUG ? FULL : NONE;

        @Override
        public void setLevel(@IntRange(from = NONE, to = FULL) int level) {
            if (level < NONE || level > FULL)
                throw new InvalidParameterException();
            this.level = level;
        }

        @Override
        public int getLevel() {
            return level;
        }

        @Override
        public void logDebug(String log) {
            if (level == FULL && BuildConfig.DEBUG)
                Log.e(TAG, "<" + BuildConfig.VERSION_NAME + ">[D] " + log);
        }

        @Override
        public void logError(String log, Throwable tr) {
            if (level == FULL && BuildConfig.DEBUG)
                Log.e(TAG, "<" + BuildConfig.VERSION_NAME + ">[E] " + log, tr);
        }

        @Override
        public void logDebug(String classFunction, String log) {
            logDebug(classFunction + " - " + log);
        }

        @Override
        public void logError(String classFunction, String log, Throwable tr) {
            logError(classFunction + " - " + log, tr);
        }
    };

    private static GaCard instance;

    public static GaCard getInstance() {
        if (instance == null) {
            instance = new GaCard();
        }
        return instance;
    }

    private GaCard() {
    }

    public Logger getLogger() {
        return DEFAULT;
    }

    public void setLogLevel(@IntRange(from = NONE, to = FULL) int logLevel) {
        getLogger().setLevel(logLevel);
    }

}
