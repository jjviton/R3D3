package com.did.gatransport.store.realm.model;

import com.did.gatransport.store.model.Recharge;

import io.realm.RealmObject;

public class RechargeRealm extends RealmObject implements Recharge {

    private int amount;
    private long date;
    private int type;
    private String cardLastDig;

    @Override
    public void setAmount(int amount) {
        this.amount = amount;
    }

    @Override
    public int getAmount() {
        return this.amount;
    }

    @Override
    public void setDate(long date) {
        this.date = date;
    }

    @Override
    public long getDate() {
        return this.date;
    }

    @Override
    public void setType(int type) {
        this.type = type;
    }

    @Override
    public int getType() {
        return this.type;
    }

    @Override
    public void setCardLastDig(String cardLastDig) {
        this.cardLastDig = cardLastDig;
    }

    @Override
    public String getCardLastDig() {
        return cardLastDig;
    }
}
