package com.did.gatransport.rest.model.response;

import com.did.gatransport.rest.model.PendingPayment;
import com.google.gson.annotations.SerializedName;

import java.util.ArrayList;

public final class PendingPaymentResponse extends BaseResponse {

    @SerializedName("Refund_list")
    private ArrayList<PendingPayment> pendingPayments;

    public PendingPaymentResponse() {
    }

    public ArrayList<PendingPayment> getPendingPayments() {
        return pendingPayments;
    }

    public void setPendingPayments(ArrayList<PendingPayment> pendingPayments) {
        this.pendingPayments = pendingPayments;
    }
}
