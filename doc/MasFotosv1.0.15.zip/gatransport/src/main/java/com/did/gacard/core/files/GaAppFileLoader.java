package com.did.gacard.core.files;

import com.did.gacard.core.files.model.GaAppFile;

public interface GaAppFileLoader {

    void save(GaAppFile gaAppFile);

    GaAppFile recover();

}
