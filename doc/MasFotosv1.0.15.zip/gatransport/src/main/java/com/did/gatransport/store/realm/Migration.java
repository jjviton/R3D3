package com.did.gatransport.store.realm;

import android.support.annotation.NonNull;

import com.did.gatransport.controller.CoreController;
import com.did.gatransport.model.Error;
import com.did.gatransport.store.realm.model.EnrollConfirmRequestRealm;
import com.did.gatransport.store.realm.model.ProfileUpdateConfirmRequestRealm;
import com.did.gatransport.store.realm.model.RechargeConfirmRequestRealm;
import com.did.gatransport.store.realm.model.RechargeRealm;
import com.did.gatransport.store.realm.model.TransactionRealm;
import com.did.gatransport.store.realm.model.TripRealm;
import com.did.gatransport.store.realm.model.UserRealm;
import com.did.gatransport.util.ErrorFactory;

import io.realm.DynamicRealm;
import io.realm.DynamicRealmObject;
import io.realm.FieldAttribute;
import io.realm.RealmMigration;
import io.realm.RealmObjectSchema;
import io.realm.RealmSchema;

final class Migration implements RealmMigration {

    private RealmGaStoreManager.RealmLifeListener lifeListener;

    Migration(RealmGaStoreManager.RealmLifeListener lifeListener) {
        this.lifeListener = lifeListener;
    }

    @Override
    public int hashCode() {
        return 42;
    }

    @Override
    public boolean equals(Object o) {
        return (o instanceof Migration);
    }

    @Override
    public void migrate(@NonNull DynamicRealm realm, long oldVersion, long newVersion) {
        CoreController.getLogger().logDebug("Migration::migrate", "Migration from : " + oldVersion + " to: " + newVersion + " version");

        boolean isMigrationRequired = oldVersion < newVersion;
        if (!isMigrationRequired) {
            CoreController.getLogger().logDebug("Migration::migrate", "DB is up to date.");
            return;
        }

        RealmSchema schema = realm.getSchema();

        Error error = null;
        if (oldVersion == 0) {
            error = from0to1(schema);
            if (error == null)
                oldVersion++;
        }

        if (oldVersion == 1) {
            error = from1to2(schema);
            if (error == null)
                oldVersion++;
        }

        if (oldVersion == 2) {
            error = from2to3(schema);
            if (error == null)
                oldVersion++;
        }

        if (oldVersion == 3) {
            error = from3to4(schema);
            if (error == null)
                oldVersion++;
        }

        if (oldVersion == 4) {
            error = from4to5(schema);
            if (error == null)
                oldVersion++;
        }

        if (oldVersion == 5) {
            error = from5to6(schema);
            if (error == null)
                oldVersion++;
        }

        if (oldVersion == 6) {
            error = from6to7(schema);
            if (error == null)
                oldVersion++;
        }

        if (lifeListener != null) lifeListener.onMigrate();
        if (oldVersion == newVersion) {
            CoreController.getLogger().logDebug("Migration::migrate", "Migration done!");
        } else {
            String msg = "Migration stopped on : " + oldVersion;
            if (error == null) {
                error = ErrorFactory.getStoreBadMigration(msg + ". No migration available.", null);
            } else {
                error.setMsg(msg + ".Reason: " + error.getMsg());
            }
            if (lifeListener != null)
                lifeListener.onError(error);
        }
    }

    private Error from0to1(RealmSchema schema) {
        /************************************************
         //  Version 1
         class RechargeConfirmRequestRealm    // add a new model class
         @PrimaryKey long id;

         int type;
         long date;
         String refId;
         int amount;
         String pan;
         ************************************************/

        // Add model
        schema.create(RechargeConfirmRequestRealm.class.getSimpleName())
                .addField("id", long.class, FieldAttribute.PRIMARY_KEY)
                .addField("type", int.class)
                .addField("date", long.class)
                .addField("refId", String.class)
                .addField("amount", int.class)
                .addField("pan", String.class);

        return null;
    }

    private Error from1to2(RealmSchema schema) {
        /************************************************
         //  Version 2
         class EnrollConfirmRequestRealm    // add a new model class
         @PrimaryKey long id;

         String hwId;
         String cardId;
         String tokenId;
         String phoneId;
         ************************************************/

        // Add model
        schema.create(EnrollConfirmRequestRealm.class.getSimpleName())
                .addField("id", long.class, FieldAttribute.PRIMARY_KEY)
                .addField("hwId", String.class)
                .addField("cardId", String.class)
                .addField("tokenId", String.class)
                .addField("phoneId", String.class);
        return null;
    }

    private Error from2to3(RealmSchema schema) {
        /************************************************
         //  Version 3
         class RechargeConfirmRequestRealm    // modify model class

         FROM
         String pan
         TO
         String lastDig

         class RechargeRealm // modify model class

         FROM
         String card
         TO
         String cardLastDig
         ************************************************/

        // Modify model class
        Error error = null;
        try {
            schema.get(RechargeConfirmRequestRealm.class.getSimpleName())
                    .renameField("pan", "lastDig");
            schema.get(RechargeRealm.class.getSimpleName())
                    .renameField("card", "cardLastDig");
        } catch (Exception e) {
            error = ErrorFactory.getStoreBadMigration("Problem when migration version from: 2 to: 3", e);
        }

        return error;
    }

    private Error from3to4(RealmSchema schema) {
        /************************************************
         //  Version 4
         class UserRealm    // modify model class

         ADD
         String paySolutionType;
         ************************************************/

        // Modify model class
        Error error = null;
        try {
            schema.get(UserRealm.class.getSimpleName())
                    .addField("paySolutionType", String.class);
        } catch (Exception e) {
            error = ErrorFactory.getStoreBadMigration("Problem when migration version from: 3 to: 4", e);
        }

        return error;
    }

    // 1.0.7v
    private Error from4to5(RealmSchema schema) {
        /************************************************
         //  Version 5
         class ProfileUpdateConfirmRequestRealm    // add a new model class
         @PrimaryKey long id;

         private String oldProfile;
         private String oldProfileExpiration;

         private String newProfile;
         private String newProfileExpiration;

         private String timestamp;

         class UserRealm    // modify model class

         ADD
         String profileExpiration;

         class RechargeConfirmRequestRealm    // modify model class

         ADD
         String status;
         ************************************************/

        // Add model
        // ProfileUpdateConfirmRequestRealm
        schema.create(ProfileUpdateConfirmRequestRealm.class.getSimpleName())
                .addField("id", long.class, FieldAttribute.PRIMARY_KEY)
                .addField("oldProfile", String.class)
                .addField("oldProfileExpiration", String.class)
                .addField("newProfile", String.class)
                .addField("newProfileExpiration", String.class)
                .addField("timestamp", String.class);


        // Modify model class:
        // UserRealm
        Error error = null;
        try {
            schema.get(UserRealm.class.getSimpleName())
                    .addField("profileExpiration", String.class);
        } catch (Exception e) {
            error = ErrorFactory.getStoreBadMigration("Problem when migration version from: 4 to: 5", e);
        }
        // RechargeConfirmRequestRealm
        try {
            schema.get(RechargeConfirmRequestRealm.class.getSimpleName())
                    .addField("status", String.class);
        } catch (Exception e) {
            error = ErrorFactory.getStoreBadMigration("Problem when migration version from: 4 to: 5", e);
        }

        return error;
    }

    // 1.0.9v
    private Error from5to6(RealmSchema schema) {
        /************************************************
         //  Version 6
         class TransactionRealm    // modify model class

         ADD
         String type;

         class TripRealm    // modify model class

         ADD
         String type;
         ************************************************/


        // Modify model class:
        // TransactionRealm
        Error error = null;
        try {
            schema.get(TransactionRealm.class.getSimpleName())
                    .addField("type", String.class);

            schema.get(TransactionRealm.class.getSimpleName()).transform(new RealmObjectSchema.Function() {
                @Override
                public void apply(DynamicRealmObject obj) {
                    int amount = obj.getInt("amount");
                    boolean isDebit = amount >= 0;
//                    obj.setInt("amount", (isDebit? 1 : -1) * amount);
                    obj.setString("type", isDebit ? TransactionRealm.TYPE_DEBIT : TransactionRealm.TYPE_CANCEL);
                }
            });
        } catch (Exception e) {
            error = ErrorFactory.getStoreBadMigration("Problem when migration version from: 5 to: 6", e);
        }
        // TripRealm
        try {
            schema.get(TripRealm.class.getSimpleName())
                    .addField("type", String.class);

            schema.get(TripRealm.class.getSimpleName()).transform(new RealmObjectSchema.Function() {
                @Override
                public void apply(DynamicRealmObject obj) {
                    int amount = obj.getInt("amount");
                    boolean isDebit = amount >= 0;
//                    obj.setInt("amount", (isDebit? 1 : -1) * amount);
                    obj.setString("type", isDebit ? TripRealm.TYPE_DEBIT : TripRealm.TYPE_CANCEL);
                }
            });
        } catch (Exception e) {
            error = ErrorFactory.getStoreBadMigration("Problem when migration version from: 5 to: 6", e);
        }

        return error;
    }

    // 1.0.15v
    private Error from6to7(RealmSchema schema) {
        /************************************************
         //  Version 7
         class EnrollConfirmRequestRealm    // delete model class
         ************************************************/


        // Modify model class:
        // TransactionRealm
        Error error = null;
        try {
            schema.remove(EnrollConfirmRequestRealm.class.getSimpleName());
        } catch (Exception e) {
            error = ErrorFactory.getStoreBadMigration("Problem when migration version from: 6 to: 7", e);
        }

        return error;
    }
}
