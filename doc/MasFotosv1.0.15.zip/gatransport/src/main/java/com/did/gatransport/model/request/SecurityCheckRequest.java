package com.did.gatransport.model.request;

import java.util.List;

public final class SecurityCheckRequest {

    private List<String> appSignatureList;

    public SecurityCheckRequest() {
    }

    public SecurityCheckRequest(List<String> appSignatureList) {
        this.appSignatureList = appSignatureList;
    }

    public List<String> getAppSignatureList() {
        return appSignatureList;
    }

    public void setAppSignatureList(List<String> appSignatureList) {
        this.appSignatureList = appSignatureList;
    }
}
