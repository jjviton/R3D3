package com.did.gatransport.store.model;

public interface Recharge {

    void setAmount(int amount);

    int getAmount();

    void setDate(long date);

    long getDate();

    void setType(int type);

    int getType();

    void setCardLastDig(String cardLastDig);

    String getCardLastDig();
}
