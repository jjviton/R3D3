package com.did.gatransport.model;

import android.os.Parcel;
import android.os.Parcelable;

public final class PendingPayment extends Payment implements Parcelable {

    private String msg;

    private String pan;

    private String expDate;

    private String type;

    private String key;

    public PendingPayment() {
    }

    public PendingPayment(Parcel in) {
        super(in);
        this.msg = in.readString();
        this.pan = in.readString();
        this.expDate = in.readString();
        this.type = in.readString();
        this.key = in.readString();
    }

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel out, int flags) {
        out.writeInt(getAmount());
        out.writeString(msg);
        out.writeString(pan);
        out.writeString(expDate);
        out.writeString(type);
        out.writeString(key);
    }

    public static final Parcelable.Creator<PendingPayment> CREATOR
            = new Parcelable.Creator<PendingPayment>() {
        public PendingPayment createFromParcel(Parcel in) {
            return new PendingPayment(in);
        }

        public PendingPayment[] newArray(int size) {
            return new PendingPayment[size];
        }
    };

    public String getMsg() {
        return msg;
    }

    public void setMsg(String msg) {
        this.msg = msg;
    }

    public String getPan() {
        return pan;
    }

    public void setPan(String pan) {
        this.pan = pan;
    }

    public String getExpDate() {
        return expDate;
    }

    public void setExpDate(String expDate) {
        this.expDate = expDate;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public String getKey() {
        return key;
    }

    public void setKey(String key) {
        this.key = key;
    }
}
