package com.did.gatransport.rest.retrofit.request;

import com.google.gson.annotations.SerializedName;

public final class PendingRechargeRequest extends BaseRechargeRequest implements RechargeRequest {

    @SerializedName("Ref_key")
    private String refKey;
    @SerializedName("Ref_type")
    private String refType;

    public PendingRechargeRequest() {
    }

    public String getRefKey() {
        return refKey;
    }

    public void setRefKey(String refKey) {
        this.refKey = refKey;
    }

    public String getRefType() {
        return refType;
    }

    public void setRefType(String refType) {
        this.refType = refType;
    }
}
