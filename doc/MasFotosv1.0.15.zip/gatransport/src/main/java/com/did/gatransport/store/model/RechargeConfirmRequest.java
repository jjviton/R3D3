package com.did.gatransport.store.model;

public interface RechargeConfirmRequest {
    int getType();

    void setType(int type);

    long getDate();

    void setDate(long date);

    String getRefId();

    void setRefId(String refId);

    int getAmount();

    void setAmount(int amount);

    String getLastDig();

    void setLastDig(String lastDig);

    String getStatus();

    void setStatus(String status);
}
