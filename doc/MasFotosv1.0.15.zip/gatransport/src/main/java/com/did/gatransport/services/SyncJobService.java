package com.did.gatransport.services;

import android.app.job.JobParameters;
import android.app.job.JobService;
import android.content.ContextWrapper;
import android.os.Build;
import android.support.annotation.RequiresApi;

import com.did.gatransport.R;
import com.did.gatransport.controller.CoreController;
import com.did.gatransport.controller.PreferencesController;
import com.did.gatransport.controller.ProcessController;
import com.did.gatransport.controller.SyncController;
import com.did.gatransport.interfaces.RequestListener;
import com.did.gatransport.interfaces.SynchronizationListener;
import com.did.gatransport.model.Error;
import com.did.gatransport.rest.GaRestController;
import com.did.gatransport.rest.GaRestFactory;
import com.did.gatransport.store.GaStoreFactory;
import com.did.gatransport.store.GaStoreManager;
import com.did.gatransport.util.ErrorFactory;
import com.did.security.core.SecurityHelper;

import java.net.URL;
import java.security.InvalidParameterException;


@RequiresApi(api = Build.VERSION_CODES.LOLLIPOP)
public abstract class SyncJobService extends JobService {

//    private class JobTask extends AsyncTask<JobParameters, Void, JobParameters> {
//        private final ContextWrapper context;
//
//        private JobTask(ContextWrapper context) {
//            this.context = context;
//        }
//
//
//        @Override
//        protected JobParameters doInBackground(JobParameters... params) {
//            doJob(context, null, CoreController.getSyncListener(), false);
//            return params[0];
//        }
//
//        @Override
//        protected void onPostExecute(JobParameters params) {
//            finish(params);
//        }
//    }


    @Override
    public final boolean onStopJob(JobParameters jobParameters) {
        CoreController.getLogger().logDebug("SyncJobService::onStopJob", "Stopping");
        ProcessController.setStIsRunning(false);
        return true;
    }

    @Override
    public final boolean onStartJob(final JobParameters jobParameters) {
        CoreController.getLogger().logDebug("SyncJobService::onStartJob", "Starting");
        doJob(this, jobParameters, CoreController.getSyncListener(), true);
//        new JobTask(this).execute(jobParameters);
        return true;
    }

    private void doJob(final ContextWrapper context, final JobParameters jobParameters, SynchronizationListener synchronizationListener, final boolean finish) {
        URL host = PreferencesController.getInstance(context).getHostUrl();
        if (host == null) {
            if (synchronizationListener != null)
                synchronizationListener.onFailure(ErrorFactory.getWarnError(context, Error.GENERAL_INVALID_INPUT, new InvalidParameterException(String.format(context.getString(R.string.EXCEPTION_INVALID_INPUT), "host"))));
            if (finish)
                finish(jobParameters, true);
            return;
        }
        SecurityHelper securityHelper = new SecurityHelper(this);
        final GaStoreManager storeManager = GaStoreFactory.getRealmGaStoreManager(this, securityHelper);
        GaRestController restController = GaRestFactory.getRetrofitGaRestController(host);
        SyncController.sync(context, storeManager, restController, securityHelper, new RequestListener<Void>() {
            @Override
            public void onSuccess(Void response) {
                storeManager.close();
                if (finish)
                    finish(jobParameters, false);
            }

            @Override
            public void onFailure(Error error) {
                storeManager.close();
                if (finish)
                    finish(jobParameters, true);
            }
        }, synchronizationListener);
    }

    private void finish(JobParameters jobParameters, boolean reschedule) {
        CoreController.getLogger().logDebug("SyncJobService::jobFinished", "Finishing");
        jobFinished(jobParameters, reschedule);
    }
}
