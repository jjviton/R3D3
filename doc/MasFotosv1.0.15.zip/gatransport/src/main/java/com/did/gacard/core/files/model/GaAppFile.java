package com.did.gacard.core.files.model;

import com.did.gacard.ecard.core.iso7816.files.AppFile;
import com.google.gson.annotations.SerializedName;

public final class GaAppFile extends AppFile {

    @SerializedName("ef_nt")
    private NtEFile ef2NT = new NtEFile();
    @SerializedName("ef_key")
    private KeyEFile ef2Key = new KeyEFile();
    //    @SerializedName("ef_response")
//    private ResponseEFile ef2Response = new ResponseEFile();
    @SerializedName("ef_info")
    private InfoEFile ef2Info = new InfoEFile();
    @SerializedName("ef_gendata")
    private GenDataEFile ef2GenData = new GenDataEFile();
    @SerializedName("ef_contract")
    private ContractsEFile ef2Contract = new ContractsEFile();
    @SerializedName("ef_event")
    private EventsEFile ef2Event = new EventsEFile();
    @SerializedName("ef_bal")
    private BalEFile ef2Bal = new BalEFile();

    public GaAppFile() {
        super();
    }

    public GaAppFile(GaAppFile other) {
        super(other);
        if (other == null) return;
        this.ef2NT = new NtEFile(other.ef2NT);
        this.ef2Key = new KeyEFile(other.ef2Key);
        this.ef2Info = new InfoEFile(other.ef2Info);
        this.ef2GenData = new GenDataEFile(other.ef2GenData);
        this.ef2Contract = new ContractsEFile(other.ef2Contract);
        this.ef2Event = new EventsEFile(other.ef2Event);
        this.ef2Bal = new BalEFile(other.ef2Bal);
    }

    public NtEFile getEfNT() {
        return ef2NT;
    }

    public void setEfNT(NtEFile ef2NT) {
        this.ef2NT = ef2NT;
    }

    public KeyEFile getEfKey() {
        return ef2Key;
    }

    public void setEfKey(KeyEFile ef2Key) {
        this.ef2Key = ef2Key;
    }

//    public ResponseEFile getEfResponse() {
//        return ef2Response;
//    }
//
//    public void setEfResponse(ResponseEFile ef2Response) {
//        this.ef2Response = ef2Response;
//    }

    public InfoEFile getEfInfo() {
        return ef2Info;
    }

    public void setEfInfo(InfoEFile ef2Info) {
        this.ef2Info = ef2Info;
    }

    public GenDataEFile getEfGenData() {
        return ef2GenData;
    }

    public void setEfGenData(GenDataEFile ef2GenData) {
        this.ef2GenData = ef2GenData;
    }

    public ContractsEFile getEfContract() {
        return ef2Contract;
    }

    public void setEfContract(ContractsEFile ef2Contract) {
        this.ef2Contract = ef2Contract;
    }

    public EventsEFile getEfEvent() {
        return ef2Event;
    }

    public void setEfEvent(EventsEFile ef2Event) {
        this.ef2Event = ef2Event;
    }

    public BalEFile getEfBal() {
        return ef2Bal;
    }

    public void setEfBal(BalEFile ef2Bal) {
        this.ef2Bal = ef2Bal;
    }
}
