package com.did.gatransport.model.request;

import android.support.annotation.IntRange;
import android.support.annotation.NonNull;

import java.security.InvalidParameterException;

public final class EnrollRequest {

    public static final int ENROLL_TYPE_DNI = 0;
    public static final int ENROLL_TYPE_PAN = 1;
    public static final int ENROLL_TYPE_USER = 2;
    public static final int ENROLL_TYPE_CLIENT = 3;

    public static final int PROFILE_INFORMATION_DEFAULT_VALUE = 0;

    private int enrollType;
    private String enrollData;
    private String pwd;
    private String phone;   // Optional
    private String email;   // Optional
    private String cardType;
    private String profileType;
    private String paySolutionType;
    private long profileExpiration = PROFILE_INFORMATION_DEFAULT_VALUE; // Optional

    public EnrollRequest() {
    }

    public EnrollRequest(@IntRange(from = ENROLL_TYPE_DNI, to = ENROLL_TYPE_CLIENT) int enrollType, String enrollData, String pwd, String phone, String email, @NonNull String cardType, @NonNull String profileType, long profileExpiration, @NonNull String paySolutionType) {
        if (enrollType < ENROLL_TYPE_DNI || enrollType > ENROLL_TYPE_CLIENT)
            throw new InvalidParameterException();
        if (cardType == null)
            throw new InvalidParameterException();
        if (profileType == null)
            throw new InvalidParameterException();
        if (paySolutionType == null)
            throw new InvalidParameterException();
        this.enrollData = enrollData;
        this.pwd = pwd;
        this.phone = phone;
        this.email = email;
        this.cardType = cardType;
        this.enrollType = enrollType;
        this.profileType = profileType;
        this.profileExpiration = profileExpiration;
        this.paySolutionType = paySolutionType;
    }

    public int getEnrollType() {
        return enrollType;
    }

    public void setEnrollType(@IntRange(from = ENROLL_TYPE_DNI, to = ENROLL_TYPE_CLIENT) int enrollType) {
        if (enrollType < ENROLL_TYPE_DNI || enrollType > ENROLL_TYPE_CLIENT)
            throw new InvalidParameterException();
        this.enrollType = enrollType;
    }

    public String getEnrollData() {
        return enrollData;
    }

    public void setEnrollData(String enrollData) {
        this.enrollData = enrollData;
    }

    public String getPwd() {
        return pwd;
    }

    public void setPwd(String pwd) {
        this.pwd = pwd;
    }

    public String getPhone() {
        return phone;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getCardType() {
        return cardType;
    }

    public void setCardType(@NonNull String cardType) {
        if (cardType == null)
            throw new InvalidParameterException();
        this.cardType = cardType;
    }

    public String getProfileType() {
        return profileType;
    }

    public void setProfileType(@NonNull String profileType) {
        if (profileType == null)
            throw new InvalidParameterException();
        this.profileType = profileType;
    }

    public long getProfileExpiration() {
        return profileExpiration;
    }

    public void setProfileExpiration(long profileExpiration) {
        this.profileExpiration = profileExpiration;
    }

    public String getPaySolutionType() {
        return paySolutionType;
    }

    public void setPaySolutionType(String paySolutionType) {
        this.paySolutionType = paySolutionType;
    }
}
