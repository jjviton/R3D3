package com.did.gatransport.rest.retrofit.request;

import com.google.gson.annotations.SerializedName;

public final class ProfileUpdateRequest {

    @SerializedName("Phone_ID")
    private String phoneId;
    @SerializedName("HW_ID")
    private String hwId;
    @SerializedName("PAN")
    private String pan;
    @SerializedName("Order_type")
    private String type;
    @SerializedName("Profile_tsmp")
    private String profileTimestamp;
    @SerializedName("Pay_Sol")
    private String paySolution;
    @SerializedName("NT")
    private String nt;
    @SerializedName("Cur_Event")
    private String lastEvent;
    @SerializedName("User_struct")
    private String structEnvironmentUser;
    @SerializedName("Balance")
    private String balance;

    public ProfileUpdateRequest() {
    }

    public String getPhoneId() {
        return phoneId;
    }

    public void setPhoneId(String phoneId) {
        this.phoneId = phoneId;
    }

    public String getHwId() {
        return hwId;
    }

    public void setHwId(String hwId) {
        this.hwId = hwId;
    }

    public String getPan() {
        return pan;
    }

    public void setPan(String pan) {
        this.pan = pan;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public String getProfileTimestamp() {
        return profileTimestamp;
    }

    public void setProfileTimestamp(String profileTimestamp) {
        this.profileTimestamp = profileTimestamp;
    }

    public String getPaySolution() {
        return paySolution;
    }

    public void setPaySolution(String paySolution) {
        this.paySolution = paySolution;
    }

    public String getNt() {
        return nt;
    }

    public void setNt(String nt) {
        this.nt = nt;
    }

    public String getLastEvent() {
        return lastEvent;
    }

    public void setLastEvent(String lastEvent) {
        this.lastEvent = lastEvent;
    }

    public String getStructEnvironmentUser() {
        return structEnvironmentUser;
    }

    public void setStructEnvironmentUser(String structEnvironmentUser) {
        this.structEnvironmentUser = structEnvironmentUser;
    }

    public String getBalance() {
        return balance;
    }

    public void setBalance(String balance) {
        this.balance = balance;
    }
}
