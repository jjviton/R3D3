package com.did.gatransport.store.realm.model;

import com.did.gatransport.store.model.ProfileUpdateConfirmRequest;

import io.realm.RealmObject;
import io.realm.annotations.PrimaryKey;

public class ProfileUpdateConfirmRequestRealm extends RealmObject implements ProfileUpdateConfirmRequest {

    @PrimaryKey
    private long id;
    private String oldProfile;
    private String oldProfileExpiration;

    private String newProfile;
    private String newProfileExpiration;

    private String timestamp;

    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    @Override
    public String getOldProfile() {
        return oldProfile;
    }

    @Override
    public void setOldProfile(String oldProfile) {
        this.oldProfile = oldProfile;
    }

    @Override
    public String getOldProfileExpiration() {
        return oldProfileExpiration;
    }

    @Override
    public void setOldProfileExpiration(String oldProfileExpiration) {
        this.oldProfileExpiration = oldProfileExpiration;
    }

    @Override
    public String getNewProfile() {
        return newProfile;
    }

    @Override
    public void setNewProfile(String newProfile) {
        this.newProfile = newProfile;
    }

    @Override
    public String getNewProfileExpiration() {
        return newProfileExpiration;
    }

    @Override
    public void setNewProfileExpiration(String newProfileExpiration) {
        this.newProfileExpiration = newProfileExpiration;
    }

    @Override
    public String getTimestamp() {
        return timestamp;
    }

    @Override
    public void setTimestamp(String timestamp) {
        this.timestamp = timestamp;
    }
}
