package com.did.gatransport.rest.retrofit.request;

public interface RechargeRequest {

    String getPhoneId();

    void setPhoneId(String phoneId);

    String getHwId();

    void setHwId(String hwId);

    String getAmount();

    void setAmount(String amount);

    String getDate();

    void setDate(String date);
}
