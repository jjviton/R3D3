package com.did.gatransport.model.request;

import com.did.gatransport.model.ProfileUpdate;

public final class ProfileUpdateRequest {

    private String user;
    private String pwd;
    private ProfileUpdate profileUpdate;

    public String getUser() {
        return user;
    }

    public void setUser(String user) {
        this.user = user;
    }

    public String getPwd() {
        return pwd;
    }

    public void setPwd(String pwd) {
        this.pwd = pwd;
    }

    public ProfileUpdate getProfileUpdate() {
        return profileUpdate;
    }

    public void setProfileUpdate(ProfileUpdate profileUpdate) {
        this.profileUpdate = profileUpdate;
    }
}
