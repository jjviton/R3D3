package com.did.gatransport.rest.retrofit.request;

import com.google.gson.annotations.SerializedName;

public final class ClientFinishEnrollRequest extends BaseFinishEnrollRequest implements FinishEnrollRequest {

    @SerializedName("Client_ID")
    private String clientId;

    public ClientFinishEnrollRequest() {
    }

    public String getClientId() {
        return clientId;
    }

    public void setClientId(String clientId) {
        this.clientId = clientId;
    }
}
