package com.did.gacard.services;

import com.did.gacard.GaCard;
import com.did.gacard.core.GaApplet;
import com.did.gacard.ecard.core.Applet;
import com.did.gacard.ecard.core.AppletService;

public abstract class GaAppletService extends AppletService {

    protected GaAppletManager manager;

    protected final void setManager(GaAppletManager manager) {
        this.manager = manager;
    }

    @Override
    public final boolean isSelectApdu(byte[] commandApdu) {
        return GaApplet.isPreSelectApdu(commandApdu);
    }

    @Override
    public final Applet selectApplet(byte[] commandApdu) {
        Applet applet = null;
        if (GaApplet.isPreSelectApdu(commandApdu)) {
            try {
                applet = new GaApplet(manager, manager, manager);
            } catch (Exception e) {
                GaCard.getInstance().getLogger().logError("GaAppletService::selectApplet", "Cannot create GaApplet instance.", e);
            }
        }
        return applet;
    }

}
