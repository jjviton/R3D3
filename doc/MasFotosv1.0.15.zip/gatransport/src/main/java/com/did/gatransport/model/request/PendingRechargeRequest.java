package com.did.gatransport.model.request;

import android.os.Parcel;
import android.os.Parcelable;

import com.did.gatransport.model.PendingPayment;

public final class PendingRechargeRequest extends RechargeRequest<PendingPayment> implements Parcelable {

    public PendingRechargeRequest() {
    }

    public PendingRechargeRequest(String pwd, PendingPayment payment) {
        super(pwd, payment);
    }

    public PendingRechargeRequest(Parcel in) {
        super(in);
    }

    @Override
    PendingPayment getPaymentFromParcel(Parcel in) {
        return in.readParcelable(PendingPayment.class.getClassLoader());
    }

    public static final Creator<PendingRechargeRequest> CREATOR
            = new Creator<PendingRechargeRequest>() {
        public PendingRechargeRequest createFromParcel(Parcel in) {
            return new PendingRechargeRequest(in);
        }

        public PendingRechargeRequest[] newArray(int size) {
            return new PendingRechargeRequest[size];
        }
    };

}
