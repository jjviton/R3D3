package com.did.gatransport.rest.model.response;

import com.google.gson.annotations.SerializedName;

public final class BalanceResponse extends BaseResponse {

    @SerializedName("NT")
    private String nt;
    @SerializedName("Balance")
    private String balance;
    @SerializedName("Signature")
    private byte[] signature;
    @SerializedName("Last_Refund")
    private String lastRefundId;

    public BalanceResponse() {
    }

    public String getNt() {
        return nt;
    }

    public void setNt(String nt) {
        this.nt = nt;
    }

    public String getBalance() {
        return balance;
    }

    public void setBalance(String balance) {
        this.balance = balance;
    }

    public byte[] getSignature() {
        return signature;
    }

    public void setSignature(byte[] signature) {
        this.signature = signature;
    }

    public String getLastRefundId() {
        return lastRefundId;
    }

    public void setLastRefundId(String lastRefundId) {
        this.lastRefundId = lastRefundId;
    }
}
