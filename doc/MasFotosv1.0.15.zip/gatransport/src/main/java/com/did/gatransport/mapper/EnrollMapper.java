package com.did.gatransport.mapper;

public final class EnrollMapper implements DataMapper {
    @Override
    public void uiToStore() {

    }

    @Override
    public void storeToUi() {

    }

    @Override
    public void restToStore() {

    }

    @Override
    public void storeToRest() {

    }

    @Override
    public void uiToRest() {

    }

    @Override
    public void restToUi() {

    }
}
