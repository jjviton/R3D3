package com.did.gatransport.rest.retrofit.request;

import com.google.gson.annotations.SerializedName;

public final class ManageRequest {

    // Status
    public static final String STATUS_LOCK = "01";
    public static final String STATUS_UNLOCK = "02";
    public static final String STATUS_UNSUBSCRIBE = "03";

    // Cause
    public static final String CAUSE_LOCK = "10";
    public static final String CAUSE_UNLOCK = "50";
    public static final String CAUSE_UNSUBSCRIBE = "25";

    // Indicator
    public static final String INDICATOR_MONEDERO = "01";
    public static final String INDICATOR_FINANCIERA = "02";
    public static final String INDICATOR_IBAN = "03";

    @SerializedName("Phone_ID")
    private String phoneId = "";
    @SerializedName("HW_ID")
    private String hwId = "";
    @SerializedName("Status")
    private String status = "";
    @SerializedName("Cause")
    private String cause = "";
    @SerializedName("Indicator")
    private String indicator = "";
    @SerializedName("Method")
    private String method = "";

    public ManageRequest() {
    }

    public String getPhoneId() {
        return phoneId;
    }

    public void setPhoneId(String phoneId) {
        this.phoneId = phoneId;
    }

    public String getHwId() {
        return hwId;
    }

    public void setHwId(String hwId) {
        this.hwId = hwId;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status != null ? status : "";
    }

    public String getCause() {
        return cause;
    }

    public void setCause(String cause) {
        this.cause = cause != null ? cause : "";
    }

    public String getIndicator() {
        return indicator;
    }

    public void setIndicator(String indicator) {
        this.indicator = indicator != null ? indicator : "";
    }

    public String getMethod() {
        return method;
    }

    public void setMethod(String method) {
        this.method = method != null ? method : "";
    }
}
