package com.did.gatransport.store.model;

@Deprecated
public interface EnrollConfirmRequest {

    String getHwId();

    void setHwId(String hwId);

    String getCardId();

    void setCardId(String cardId);

    String getTokenId();

    void setTokenId(String tokenId);

    String getPhoneId();

    void setPhoneId(String phoneId);

}
