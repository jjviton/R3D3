package com.did.gacard.core.files.model;

import com.did.gacard.ecard.util.ByteArray;
import com.google.gson.annotations.SerializedName;

public final class EventEFile {

    public transient static final byte[] FILE_ID = {(byte) 0x00, (byte) 0x15};
    public transient static final short FILE_SIZE = (short) 0x20;

    // File: 0x0015 [32]
    // [NT  | IMP_EVENT | BAL_EVENT | TRANS_EVENT   | STRUCT_EVENT  | BIT_RATIFICATION  | RFU]
    // [2   |   2       | 3         | 1             | 21            | 1                 | 2]

    public transient static final int FILE_OFFSET_NT = (short) 0x00;
    public transient static final short FILE_SIZE_NT = (short) 0x02;

    public transient static final int FILE_OFFSET_IMP_EVENT = FILE_OFFSET_NT + FILE_SIZE_NT;
    public transient static final short FILE_SIZE_IMP_EVENT = (short) 0x02;

    public transient static final int FILE_OFFSET_BAL_EVENT = FILE_OFFSET_IMP_EVENT + FILE_SIZE_IMP_EVENT;
    public transient static final short FILE_SIZE_BAL_EVENT = (short) 0x03;

    public transient static final int FILE_OFFSET_TRANS_EVENT = FILE_OFFSET_BAL_EVENT + FILE_SIZE_BAL_EVENT;
    public transient static final short FILE_SIZE_TRANS_EVENT = (short) 0x01;

    public transient static final int FILE_OFFSET_STRUCT_EVENT = FILE_OFFSET_TRANS_EVENT + FILE_SIZE_TRANS_EVENT;
    public transient static final short FILE_SIZE_STRUCT_EVENT = (short) 0x15;

    public transient static final int FILE_OFFSET_BIT_RATIFICATION = FILE_OFFSET_STRUCT_EVENT + FILE_SIZE_STRUCT_EVENT;
    public transient static final short FILE_SIZE_BIT_RATIFICATION = (short) 0x01;

    public transient static final int FILE_OFFSET_RFU = FILE_OFFSET_BIT_RATIFICATION + FILE_SIZE_BIT_RATIFICATION;
    public transient static final short FILE_SIZE_RFU = (short) 0x02;


    private static final int LENGTH = FILE_OFFSET_RFU + FILE_SIZE_RFU;

    @SerializedName("nt")
    private byte[] nt;
    @SerializedName("imp")
    private byte[] impEvent;
    @SerializedName("bal")
    private byte[] balEvent;
    @SerializedName("trans")
    private byte transEvent;
    @SerializedName("struct_event")
    private byte[] structEvent;
    @SerializedName("ratification")
    private byte bitRatification;
    @SerializedName("rfu")
    private byte[] rfu;

    public EventEFile() {
        super();
    }

    public EventEFile(EventEFile other) {
        if (other == null) return;
        this.nt = ByteArray.copyOf(other.nt);
        this.impEvent = ByteArray.copyOf(other.impEvent);
        this.balEvent = ByteArray.copyOf(other.balEvent);
        this.transEvent = other.transEvent;
        this.structEvent = ByteArray.copyOf(other.structEvent);
        this.bitRatification = other.bitRatification;
        this.rfu = ByteArray.copyOf(other.rfu);
    }

    public EventEFile(byte[] data) {
        if (data == null || data.length <= 0) {
            data = new byte[LENGTH];
        }
        this.nt = ByteArray.getBytes(data, FILE_OFFSET_NT, FILE_SIZE_NT);
        this.impEvent = ByteArray.getBytes(data, FILE_OFFSET_IMP_EVENT, FILE_SIZE_IMP_EVENT);
        this.balEvent = ByteArray.getBytes(data, FILE_OFFSET_BAL_EVENT, FILE_SIZE_BAL_EVENT);
        this.transEvent = ByteArray.getByte(data, FILE_OFFSET_TRANS_EVENT);
        this.structEvent = ByteArray.getBytes(data, FILE_OFFSET_STRUCT_EVENT, FILE_SIZE_STRUCT_EVENT);
        if (data.length > FILE_OFFSET_BIT_RATIFICATION) {
            this.bitRatification = ByteArray.getByte(data, FILE_OFFSET_BIT_RATIFICATION);
        } else {
            this.bitRatification = (byte) 0x00;
        }
        if (data.length == LENGTH) {
            this.rfu = ByteArray.getBytes(data, FILE_OFFSET_RFU, FILE_SIZE_RFU);
        } else {
            this.rfu = new byte[]{0x00, 0x00};
        }
    }

    public byte[] getNt() {
        return nt;
    }

    public void setNt(byte[] nt) {
        this.nt = nt;
    }

    public byte[] getImpEvent() {
        return impEvent;
    }

    public void setImpEvent(byte[] impEvent) {
        this.impEvent = impEvent;
    }

    public byte[] getBalEvent() {
        return balEvent;
    }

    public void setBalEvent(byte[] balEvent) {
        this.balEvent = balEvent;
    }

    public byte getTransEvent() {
        return transEvent;
    }

    public void setTransEvent(byte transEvent) {
        this.transEvent = transEvent;
    }

    public byte[] getStructEvent() {
        return structEvent;
    }

    public void setStructEvent(byte[] structEvent) {
        this.structEvent = structEvent;
    }

    public byte getBitRatification() {
        return bitRatification;
    }

    public void setBitRatification(byte bitRatification) {
        this.bitRatification = bitRatification;
    }

    public byte[] getRfu() {
        return rfu;
    }

    public void setRfu(byte[] rfu) {
        this.rfu = rfu;
    }

    public byte[] getBytes() {
        byte[] eventEFileBytes = ByteArray.merge(nt, impEvent);
        eventEFileBytes = ByteArray.merge(eventEFileBytes, balEvent);
        eventEFileBytes = ByteArray.merge(eventEFileBytes, transEvent);
        eventEFileBytes = ByteArray.merge(eventEFileBytes, structEvent);
        eventEFileBytes = ByteArray.merge(eventEFileBytes, bitRatification);
        eventEFileBytes = ByteArray.merge(eventEFileBytes, rfu);

        return eventEFileBytes;
    }

    public byte[] getBytesNoBitRatificationNoRfu() {
        byte[] eventEFileBytes = ByteArray.merge(nt, impEvent);
        eventEFileBytes = ByteArray.merge(eventEFileBytes, balEvent);
        eventEFileBytes = ByteArray.merge(eventEFileBytes, transEvent);
        eventEFileBytes = ByteArray.merge(eventEFileBytes, structEvent);

        return eventEFileBytes;
    }
}
