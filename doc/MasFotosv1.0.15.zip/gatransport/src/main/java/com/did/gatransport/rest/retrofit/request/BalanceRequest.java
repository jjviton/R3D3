package com.did.gatransport.rest.retrofit.request;

import com.google.gson.annotations.SerializedName;

public final class BalanceRequest {

    // Refund Types
    public static final String FINANCIAL = "01";
    public static final String PENDING = "05";

    // Refund Status
    public static final String OK = "0";
    public static final String NOK = "1";
    public static final String NO_RESPONSE = "2";

    @SerializedName("Phone_ID")
    private String phoneId;
    @SerializedName("HW_ID")
    private String hwId;
    @SerializedName("amount")
    private String amount;
    @SerializedName("Balance")
    private String balance;
    @SerializedName("Signature")
    private String signature;
    @SerializedName("NT")
    private String nt;
    @SerializedName("Date")
    private String date;
    @SerializedName("Refund_type")
    private String refType;
    @SerializedName("Refund_id")
    private String refId;
    @SerializedName("Refund_status")
    private String refStatus;

    public BalanceRequest() {
    }

    public String getPhoneId() {
        return phoneId;
    }

    public void setPhoneId(String phoneId) {
        this.phoneId = phoneId;
    }

    public String getHwId() {
        return hwId;
    }

    public void setHwId(String hwId) {
        this.hwId = hwId;
    }

    public String getAmount() {
        return amount;
    }

    public void setAmount(String amount) {
        this.amount = amount;
    }

    public String getBalance() {
        return balance;
    }

    public void setBalance(String balance) {
        this.balance = balance;
    }

    public String getSignature() {
        return signature;
    }

    public void setSignature(String signature) {
        this.signature = signature;
    }

    public String getNt() {
        return nt;
    }

    public void setNt(String nt) {
        this.nt = nt;
    }

    public String getDate() {
        return date;
    }

    public void setDate(String date) {
        this.date = date;
    }

    public String getRefType() {
        return refType;
    }

    public void setRefType(String refType) {
        this.refType = refType;
    }

    public String getRefId() {
        return refId;
    }

    public void setRefId(String refId) {
        this.refId = refId;
    }

    public String getRefStatus() {
        return refStatus;
    }

    public void setRefStatus(String refStatus) {
        this.refStatus = refStatus;
    }
}
