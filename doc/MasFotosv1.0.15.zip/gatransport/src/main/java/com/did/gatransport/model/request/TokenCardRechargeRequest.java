package com.did.gatransport.model.request;

import android.os.Parcel;
import android.os.Parcelable;

import com.did.gatransport.model.TokenCardPayment;

public final class TokenCardRechargeRequest extends RechargeRequest<TokenCardPayment> implements Parcelable {

    public TokenCardRechargeRequest() {
    }

    public TokenCardRechargeRequest(String pwd, TokenCardPayment payment) {
        super(pwd, payment);
    }

    public TokenCardRechargeRequest(Parcel in) {
        super(in);
    }

    @Override
    TokenCardPayment getPaymentFromParcel(Parcel in) {
        return in.readParcelable(TokenCardPayment.class.getClassLoader());
    }

    public static final Creator<TokenCardRechargeRequest> CREATOR
            = new Creator<TokenCardRechargeRequest>() {
        public TokenCardRechargeRequest createFromParcel(Parcel in) {
            return new TokenCardRechargeRequest(in);
        }

        public TokenCardRechargeRequest[] newArray(int size) {
            return new TokenCardRechargeRequest[size];
        }
    };

}
