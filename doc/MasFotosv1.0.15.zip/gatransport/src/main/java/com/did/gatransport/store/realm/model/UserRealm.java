package com.did.gatransport.store.realm.model;

import com.did.gatransport.store.model.User;

import io.realm.RealmObject;

public class UserRealm extends RealmObject implements User {

    private String name;
    private String token;
    private String phoneId;
    private String cardId;
    private String cardType;
    private String profileType;
    private String userId;
    private String paySolutionType;
    private String profileExpiration;

    @Override
    public void setName(String name) {
        this.name = name;
    }

    @Override
    public String getName() {
        return name;
    }

    @Override
    public void setToken(String token) {
        this.token = token;
    }

    @Override
    public String getToken() {
        return token;
    }

    @Override
    public void setPhoneId(String phoneId) {
        this.phoneId = phoneId;
    }

    @Override
    public String getPhoneId() {
        return phoneId;
    }

    @Override
    public void setCardId(String cardId) {
        this.cardId = cardId;
    }

    @Override
    public String getCardId() {
        return cardId;
    }

    @Override
    public void setCardType(String type) {
        this.cardType = type;
    }

    @Override
    public String getCardType() {
        return cardType;
    }

    @Override
    public void setProfileType(String type) {
        this.profileType = type;
    }

    @Override
    public String getProfileType() {
        return profileType;
    }

    @Override
    public void setUserId(String userId) {
        this.userId = userId;
    }

    @Override
    public String getUserId() {
        return this.userId;
    }

    @Override
    public String getPaySolutionType() {
        return paySolutionType;
    }

    @Override
    public void setPaySolutionType(String paySolutionType) {
        this.paySolutionType = paySolutionType;
    }

    @Override
    public String getProfileExpiration() {
        return profileExpiration;
    }

    @Override
    public void setProfileExpiration(String profileExpiration) {
        this.profileExpiration = profileExpiration;
    }
}
