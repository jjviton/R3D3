package com.did.gatransport.controller;

import android.content.Context;
import android.content.ContextWrapper;
import android.content.SharedPreferences;

import com.google.gson.Gson;

import java.net.URL;

public final class PreferencesController {
    private static final String PREFERENCES_NAME = "GaTransportPreferences";
    private static final Gson GSON = new Gson();

    private static final String REALM_KEY = "RealmKey";
    private static final String KEY_LOCK_CARD = "LOCK_CARD";
    private static final String KEY_VIBRATE_ENABLED = "VIBRATE_ENABLED";
    private static final String KEY_RING_NOTIFICATION_ENABLED = "RING_NOTIFICATION_ENABLED";
    private static final String KEY_USER_NAME = "USER_NAME";
    private static final String KEY_HOST_URL = "HOST_URL";
    private static final String KEY_SYNCJOBSERVICE_CLASSNAME = "SYNCJOBSERVICE_CLASSNAME";

    private final SharedPreferences preferences;
    private static PreferencesController preferencesController;

    public static PreferencesController getInstance(ContextWrapper context) {
        if (preferencesController == null)
            preferencesController = new PreferencesController(context);

        return preferencesController;
    }

    private PreferencesController(ContextWrapper context) {
        preferences = context.getSharedPreferences(PREFERENCES_NAME, Context.MODE_PRIVATE);
    }

    public void setRealmKey(String realmKey) {
        SharedPreferences.Editor editor = preferences.edit();
        editor.putString(REALM_KEY, realmKey);
        editor.apply();
    }

    public String getRealmKey() {
        return preferences.getString(REALM_KEY, null);
    }

    public boolean isLogged() {
        return preferences.getString(KEY_USER_NAME, null) != null;
    }

    public void setUserName(String userName) {
        SharedPreferences.Editor editor = preferences.edit();
        editor.putString(KEY_USER_NAME, userName);
        editor.apply();
    }

    public void removePreferences() {
        SharedPreferences.Editor editor = preferences.edit();
        editor.putString(KEY_USER_NAME, null);
//        editor.putString(REALM_KEY, ServicesSettings.REALM_KEY_NOT_FOUND);
        editor.putBoolean(KEY_LOCK_CARD, false);
//        editor.putBoolean(KEY_VIBRATE_ENABLED, false);
//        editor.putBoolean(KEY_RING_NOTIFICATION_ENABLED, false);
//        editor.putString(KEY_SYNCJOBSERVICE_CLASSNAME, null);
        editor.apply();
    }

    public void setLockedCard(boolean locked) {
        SharedPreferences.Editor editor = preferences.edit();
        editor.putBoolean(KEY_LOCK_CARD, locked);
        editor.apply();
    }

    public boolean isLockedCard() {
        return preferences.getBoolean(KEY_LOCK_CARD, false);
    }

    public void setHostUrl(URL hostUrl) {
        SharedPreferences.Editor editor = preferences.edit();
        editor.putString(KEY_HOST_URL, hostUrl.toString());
        editor.apply();
    }

    public URL getHostUrl() {
        String host = preferences.getString(KEY_HOST_URL, "");
        URL hostUrl = null;
        try {
            hostUrl = new URL(host);
        } catch (Exception e) {
            CoreController.getLogger().logError("PreferencesController::getHostUrl", "Error recovering HOST", e);
        }
        return hostUrl;
    }

    public void setVibrateEnabled(boolean vibrateEnabled) {
        SharedPreferences.Editor editor = preferences.edit();
        editor.putBoolean(KEY_VIBRATE_ENABLED, vibrateEnabled);
        editor.apply();
    }

    public boolean isVibrateEnabled() {
        return preferences.getBoolean(KEY_VIBRATE_ENABLED, false);
    }

    public void setRingNotificationEnabled(boolean ringNotificationEnabled) {
        SharedPreferences.Editor editor = preferences.edit();
        editor.putBoolean(KEY_RING_NOTIFICATION_ENABLED, ringNotificationEnabled);
        editor.apply();
    }

    public boolean isRingNotificationEnabled() {
        return preferences.getBoolean(KEY_RING_NOTIFICATION_ENABLED, false);
    }

    public String getSyncJobServiceClassName() {
        return preferences.getString(KEY_SYNCJOBSERVICE_CLASSNAME, "");
    }

    public void setSyncJobServiceClassName(String syncJobServiceClassName) {
        SharedPreferences.Editor editor = preferences.edit();
        editor.putString(KEY_SYNCJOBSERVICE_CLASSNAME, syncJobServiceClassName);
        editor.apply();
    }

}
