package com.did.gatransport.interfaces;

import com.did.gatransport.model.Error;

public interface CustomRequestListener<R, E extends Error> {

    void onSuccess(R response);

    void onFailure(E error);
}
