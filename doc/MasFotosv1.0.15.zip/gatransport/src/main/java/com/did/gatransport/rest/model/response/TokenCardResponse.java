package com.did.gatransport.rest.model.response;

import com.google.gson.annotations.SerializedName;

import java.util.ArrayList;

public final class TokenCardResponse extends BaseResponse {

    @SerializedName("TokenCard_list")
    private ArrayList<TokenCard> tokenCards;

    public TokenCardResponse() {
    }

    public ArrayList<TokenCard> getTokenCards() {
        return tokenCards;
    }

    public void setTokenCards(ArrayList<TokenCard> tokenCards) {
        this.tokenCards = tokenCards;
    }
}
